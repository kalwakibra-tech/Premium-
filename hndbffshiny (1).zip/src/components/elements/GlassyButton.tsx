import React from 'react';

interface GlassyButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'light' | 'primary' | 'subtle' | 'iris';
  size?: 'sm' | 'md' | 'lg';
  icon?: React.ReactNode;
  children: React.ReactNode;
}

export const GlassyButton: React.FC<GlassyButtonProps> = ({
  variant = 'light',
  size = 'md',
  icon,
  children,
  className = '',
  disabled,
  ...props
}) => {
  const sizeStyles = {
    sm: 'text-xs py-1.5 px-3.5 gap-1.5',
    md: 'text-sm py-2 px-5 gap-2',
    lg: 'text-base py-3 px-7 gap-2.5',
  };

  const variantStyles = {
    light:
      'bg-white/80 hover:bg-white text-[#0a0d12] border border-white/90 shadow-[0_2px_8px_rgba(0,105,224,0.06)] hover:shadow-[0_6px_20px_rgba(0,105,224,0.12)]',
    primary:
      'bg-[#181d27] hover:bg-[#0a0d12] text-white border border-[#181d27] shadow-[0_1px_2px_rgba(10,13,18,0.8),0_0_0_1px_#0a0d12] hover:shadow-[0_4px_16px_rgba(10,13,18,0.35)]',
    subtle:
      'bg-[#fafdff]/90 hover:bg-white text-[#535862] hover:text-[#0a0d12] border border-[#dbeafe]/70 hover:border-[#93c5fd]',
    iris:
      'bg-[#0069e0] hover:bg-[#0058be] text-white border border-transparent shadow-[0_2px_10px_rgba(0,105,224,0.25)] hover:shadow-[0_4px_16px_rgba(0,105,224,0.35)]',
  };

  return (
    <button
      disabled={disabled}
      className={`relative inline-flex items-center justify-center font-medium tracking-tight rounded-full transition-all duration-200 active:scale-95 overflow-hidden select-none disabled:opacity-50 disabled:pointer-events-none backdrop-blur-md group ${sizeStyles[size]} ${variantStyles[variant]} ${className}`}
      {...props}
    >
      {/* Light sheen animation across surface on hover */}
      <span className="absolute inset-0 w-1/2 h-full bg-gradient-to-r from-transparent via-white/35 to-transparent -skew-x-12 -translate-x-full group-hover:translate-x-[300%] transition-transform duration-700 pointer-events-none" />

      {icon && <span className="shrink-0 transition-transform duration-200 group-hover:scale-110">{icon}</span>}
      <span className="relative z-10">{children}</span>
    </button>
  );
};
