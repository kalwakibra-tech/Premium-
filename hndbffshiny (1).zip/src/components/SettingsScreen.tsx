import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { ItemDefinition } from '../types/index.ts';
import {
  Plus,
  Trash2,
  Edit2,
  Save,
  Check,
  RefreshCw,
  Download,
  Percent,
  Sliders,
  ShieldCheck,
  X,
} from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton.tsx';

export const SettingsScreen: React.FC = () => {
  const { state, updateSettings, resetToFreshState } = useApp();

  const [items, setItems] = useState<ItemDefinition[]>(state.settings.items || []);
  const [newItemName, setNewItemName] = useState('');
  const [newItemPrice, setNewItemPrice] = useState('');

  const [discountType, setDiscountType] = useState<'Percentage' | 'Taka'>('Percentage');
  const [upcomingDays, setUpcomingDays] = useState(state.settings.upcomingDeliveryDays || 3);
  const [ribbonValues, setRibbonValues] = useState<string[]>(state.settings.ribbonValues || ['0', '3', '4', '6']);
  const [newRibbonVal, setNewRibbonVal] = useState('');
  const [showAddRibbon, setShowAddRibbon] = useState(false);

  // Shop info
  const [shopName, setShopName] = useState(state.settings.invoiceShopName || 'Raymond');
  const [shopPhone, setShopPhone] = useState(state.settings.invoiceShopPhone || '01711-000000');
  const [shopAddress, setShopAddress] = useState(
    state.settings.invoiceShopAddress || 'BAF Base Tailor Market, Dhaka Cantonment'
  );

  const [toastMessage, setToastMessage] = useState('');

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim() || !newItemPrice.trim()) return;

    const priceNum = Number(newItemPrice.replace(/[^\d]/g, '')) || 0;
    const newItem: ItemDefinition = {
      id: `item-${Date.now()}-${Math.random()}`,
      name: newItemName.trim(),
      price: priceNum,
    };
    const updated = [...items, newItem];
    setItems(updated);
    updateSettings({ items: updated });
    setNewItemName('');
    setNewItemPrice('');
    setToastMessage(`Item "${newItemName}" added`);
    setTimeout(() => setToastMessage(''), 3000);
  };

  const handleRemoveItem = (index: number) => {
    const updated = items.filter((_, i) => i !== index);
    setItems(updated);
    updateSettings({ items: updated });
  };

  const handleUpcomingDaysChange = (delta: number) => {
    const next = Math.max(1, Math.min(14, upcomingDays + delta));
    setUpcomingDays(next);
    updateSettings({ upcomingDeliveryDays: next });
  };

  const handleAddRibbon = () => {
    if (!newRibbonVal.trim()) return;
    if (!ribbonValues.includes(newRibbonVal.trim())) {
      const updated = [...ribbonValues, newRibbonVal.trim()].sort((a, b) => Number(a) - Number(b));
      setRibbonValues(updated);
      updateSettings({ ribbonValues: updated });
    }
    setNewRibbonVal('');
    setShowAddRibbon(false);
  };

  const handleRemoveRibbon = (val: string) => {
    if (ribbonValues.length <= 1) return;
    const updated = ribbonValues.filter((r) => r !== val);
    setRibbonValues(updated);
    updateSettings({ ribbonValues: updated });
  };

  const handleSaveShopProfile = () => {
    updateSettings({
      invoiceShopName: shopName,
      invoiceShopPhone: shopPhone,
      invoiceShopAddress: shopAddress,
    });
    setToastMessage('Workshop profile saved');
    setTimeout(() => setToastMessage(''), 3000);
  };

  const handleExportData = () => {
    const dataStr = JSON.stringify(state, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `raymond-tailor-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full max-w-[1280px] mx-auto pb-24 font-sans">
      {/* Page Header */}
      <div className="py-5">
        <h1 className="text-[40px] font-semibold tracking-[-0.03em] text-[#1d1d1f] leading-[1.1]">
          Settings
        </h1>
        <div className="text-[#6e6e73] text-[16px] mt-1.5">
          Prices, discount, ribbon and delivery days for every new order.
        </div>
      </div>

      {toastMessage && (
        <div className="mb-4 p-3 rounded-[14px] bg-[#e3f4e8] text-[#1e7b43] text-xs font-semibold flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* =========================================================================
          DESKTOP SETTINGS (Exact Loop 1 & 2 layout - HTML lines 84-87)
         ========================================================================= */}
      <div className="hidden md:grid grid-cols-[1fr_360px] gap-5 items-start">
        {/* Left Column: Items & Prices */}
        <div className="darzi-pn">
          <div className="flex justify-between items-center mb-3.5">
            <b className="font-semibold text-[21px] text-[#1d1d1f]">Items &amp; Prices</b>
            <span className="text-[#6e6e73] text-xs">{items.length} items</span>
          </div>

          {/* Add Item Tray */}
          <form onSubmit={handleAddItem} className="darzi-tray flex gap-2.5 items-end mb-3">
            <div className="flex-1">
              <div className="text-[12px] text-[#6e6e73] mb-1">Item name</div>
              <input
                type="text"
                placeholder="e.g. Safari"
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
                className="darzi-in"
              />
            </div>
            <div className="w-[140px]">
              <div className="text-[12px] text-[#6e6e73] mb-1">Price</div>
              <input
                type="number"
                placeholder="৳"
                value={newItemPrice}
                onChange={(e) => setNewItemPrice(e.target.value)}
                className="darzi-in"
              />
            </div>
            <button type="submit" className="darzi-btn h-11">
              <Plus className="w-4 h-4" />
              Add item
            </button>
          </form>

          {/* Column Header */}
          <div className="grid grid-cols-[1fr_100px_90px] items-center px-4 h-10 bg-[#f5f5f7] rounded-[12px] text-xs font-semibold text-[#333] mb-1">
            <div>Item</div>
            <div className="text-right">Price</div>
            <div />
          </div>

          {/* Items List */}
          <div className="divide-y divide-[#f0f0f0]">
            {items.map((it, idx) => (
              <div
                key={it.name + idx}
                className="grid grid-cols-[1fr_100px_90px] items-center px-4 h-14 text-sm"
              >
                <div className="font-semibold text-[#1d1d1f]">{it.name}</div>
                <div className="font-semibold text-[#1d1d1f] text-right tabular-nums">
                  ৳{it.price.toLocaleString()}
                </div>
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => handleRemoveItem(idx)}
                    className="w-8 h-8 rounded-full bg-[#f5f5f7] hover:bg-[#fce9e9] text-[#6e6e73] hover:text-[#c62828] flex items-center justify-center transition-colors cursor-pointer"
                    title="Delete item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="text-[#6e6e73] text-xs pt-3 mt-3 border-t border-[#f0f0f0]">
            Changing or removing an item never changes orders that already exist.
          </div>
        </div>

        {/* Right Column: Settings Controls */}
        <div className="grid gap-5">
          {/* Default Discount Type */}
          <div className="darzi-pn">
            <b className="font-semibold text-[21px] text-[#1d1d1f]">Default discount type</b>
            <div className="text-[#6e6e73] text-xs mt-1 mb-3.5">
              The starting choice on every new order.
            </div>
            <div className="darzi-seg bg-[#f5f5f7] w-fit">
              <button
                onClick={() => setDiscountType('Percentage')}
                className={discountType === 'Percentage' ? 'on' : ''}
              >
                Percentage
              </button>
              <button
                onClick={() => setDiscountType('Taka')}
                className={discountType === 'Taka' ? 'on' : ''}
              >
                Taka
              </button>
            </div>
          </div>

          {/* Upcoming Delivery Days */}
          <div className="darzi-pn">
            <b className="font-semibold text-[21px] text-[#1d1d1f]">Upcoming delivery days</b>
            <div className="text-[#6e6e73] text-xs mt-1 mb-3.5">
              Orders due from today up to this many days ahead count as upcoming.
            </div>
            <div className="darzi-seg bg-[#f5f5f7] w-fit items-center gap-1.5 p-1">
              <button
                onClick={() => handleUpcomingDaysChange(-1)}
                className="w-10 h-10 rounded-full bg-white flex items-center justify-center font-bold text-base text-[#1d1d1f] hover:bg-[#ebebed]"
              >
                −
              </button>
              <span className="text-[26px] font-semibold px-4 text-[#1d1d1f] tabular-nums">
                {upcomingDays}
              </span>
              <button
                onClick={() => handleUpcomingDaysChange(1)}
                className="w-10 h-10 rounded-full bg-white flex items-center justify-center font-bold text-base text-[#1d1d1f] hover:bg-[#ebebed]"
              >
                +
              </button>
            </div>
          </div>

          {/* Ribbon Values */}
          <div className="darzi-pn">
            <b className="font-semibold text-[21px] text-[#1d1d1f]">Ribbon values</b>
            <div className="text-[#6e6e73] text-xs mt-1 mb-3.5">
              The numbers in the Ribbon dropdown.
            </div>
            <div className="flex gap-2 flex-wrap items-center">
              {ribbonValues.map((val) => (
                <span key={val} className="darzi-chip gap-2 text-sm font-semibold">
                  {val}
                  <button
                    onClick={() => handleRemoveRibbon(val)}
                    className="text-[#6e6e73] hover:text-[#c62828]"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </span>
              ))}

              {showAddRibbon ? (
                <div className="flex gap-1 items-center">
                  <input
                    type="text"
                    placeholder="Val"
                    value={newRibbonVal}
                    onChange={(e) => setNewRibbonVal(e.target.value)}
                    className="w-16 h-10 px-2 rounded-full border border-[#e0e0e0] text-center text-xs outline-none"
                  />
                  <button
                    onClick={handleAddRibbon}
                    className="darzi-btn darzi-btn-sm"
                  >
                    Add
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowAddRibbon(true)}
                  className="darzi-chip bg-[#f5f5f7] border-none text-[#1d1d1f] font-semibold"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add value
                </button>
              )}
            </div>
          </div>

          {/* Studio Profile & Database Backup */}
          <div className="darzi-pn space-y-3">
            <b className="font-semibold text-[21px] text-[#1d1d1f] block">Workshop Profile</b>
            <div>
              <label className="text-xs text-[#6e6e73]">Shop Name</label>
              <input
                type="text"
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                className="darzi-in mt-1 font-semibold"
              />
            </div>
            <div>
              <label className="text-xs text-[#6e6e73]">Contact Phone</label>
              <input
                type="text"
                value={shopPhone}
                onChange={(e) => setShopPhone(e.target.value)}
                className="darzi-in mt-1"
              />
            </div>
            <div>
              <label className="text-xs text-[#6e6e73]">Cantonment Address</label>
              <input
                type="text"
                value={shopAddress}
                onChange={(e) => setShopAddress(e.target.value)}
                className="darzi-in mt-1 text-xs"
              />
            </div>
            <button
              onClick={handleSaveShopProfile}
              className="darzi-btn darzi-btn-sm w-full mt-2"
            >
              Save Profile
            </button>

            <div className="pt-3 border-t border-[#f0f0f0] flex flex-col gap-2">
              <button
                onClick={handleExportData}
                className="darzi-btn darzi-btn-tb darzi-btn-sm w-full"
              >
                <Download className="w-3.5 h-3.5" />
                Backup / Export JSON
              </button>
              <button
                onClick={() => {
                  if (confirm('Reset to fresh state? This clears demo orders.')) {
                    resetToFreshState();
                  }
                }}
                className="darzi-btn darzi-btn-tb darzi-btn-sm w-full text-[#c62828] hover:bg-[#fce9e9]"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Reset To Fresh State
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          MOBILE SETTINGS (Exact Loop 1 & 2 Mobile layout - HTML lines 12-15)
         ========================================================================= */}
      <div className="md:hidden">
        {/* Dark Summary Card */}
        <div className="darzi-dark h-[200px] p-5 rounded-[28px] relative overflow-hidden">
          <span className="darzi-st bg-white/14 text-white">
            {discountType}
          </span>
          <div className="absolute left-5 bottom-8">
            <div className="text-[#ccc] text-sm">Items &amp; prices</div>
            <div className="text-[44px] font-semibold text-white leading-none mt-1">
              {items.length} items
            </div>
          </div>
          <span className="darzi-st absolute right-5 bottom-8 bg-white/14 text-white text-xs">
            Ribbon {ribbonValues.join(' · ')}
          </span>
        </div>

        {/* 3 Action Tiles */}
        <div className="flex gap-2.5 mt-3">
          <div
            onClick={() => {
              const name = prompt('New Item Name:');
              const price = prompt('Price in Taka:');
              if (name && price) {
                const newItem: ItemDefinition = {
                  id: `item-${Date.now()}-${Math.random()}`,
                  name: name.trim(),
                  price: Number(price) || 0,
                };
                const updated = [...items, newItem];
                setItems(updated);
                updateSettings({ items: updated });
              }
            }}
            className="darzi-pn flex-1 rounded-[28px] py-4 text-center font-semibold text-xs cursor-pointer active:scale-95"
          >
            <div className="grid place-items-center mb-1.5">
              <Plus className="w-4 h-4 text-[#0066cc]" />
            </div>
            Add item
          </div>
          <div
            onClick={() => setDiscountType((d) => (d === 'Percentage' ? 'Taka' : 'Percentage'))}
            className="darzi-pn flex-1 rounded-[28px] py-4 text-center font-semibold text-xs cursor-pointer active:scale-95"
          >
            <div className="grid place-items-center mb-1.5">
              <Percent className="w-4 h-4 text-[#0066cc]" />
            </div>
            Discount
          </div>
          <div
            onClick={() => {
              const val = prompt('Enter new Ribbon number:');
              if (val) {
                const updated = [...ribbonValues, val.trim()].sort((a, b) => Number(a) - Number(b));
                setRibbonValues(updated);
                updateSettings({ ribbonValues: updated });
              }
            }}
            className="darzi-pn flex-1 rounded-[28px] py-4 text-center font-semibold text-xs cursor-pointer active:scale-95"
          >
            <div className="grid place-items-center mb-1.5">
              <Sliders className="w-4 h-4 text-[#0066cc]" />
            </div>
            Ribbon
          </div>
        </div>

        {/* Upcoming delivery days stepper card */}
        <div className="darzi-pn mt-3 rounded-[28px] p-4 px-5 flex justify-between items-center">
          <div>
            <b className="font-semibold text-base text-[#1d1d1f]">Upcoming delivery days</b>
            <div className="text-[#6e6e73] text-xs mt-0.5">Counts orders due in the next days</div>
          </div>
          <div className="darzi-seg bg-[#f5f5f7] items-center gap-1.5 p-1">
            <button
              onClick={() => handleUpcomingDaysChange(-1)}
              className="w-10 h-10 rounded-full bg-white flex items-center justify-center font-bold text-sm text-[#1d1d1f]"
            >
              −
            </button>
            <span className="text-[24px] font-semibold px-3 text-[#1d1d1f] tabular-nums">
              {upcomingDays}
            </span>
            <button
              onClick={() => handleUpcomingDaysChange(1)}
              className="w-10 h-10 rounded-full bg-white flex items-center justify-center font-bold text-sm text-[#1d1d1f]"
            >
              +
            </button>
          </div>
        </div>

        {/* Prices List */}
        <div className="flex justify-between items-center mt-5 mb-2.5 px-1">
          <b className="font-semibold text-[20px] text-[#1d1d1f]">Prices</b>
          <span className="text-[#6e6e73] text-xs">{items.length} items</span>
        </div>
        <div className="darzi-pn p-1 px-4 rounded-[28px] divide-y divide-[#f0f0f0]">
          {items.map((it) => (
            <div key={it.name} className="flex justify-between py-4 text-sm font-semibold text-[#1d1d1f]">
              <span>{it.name}</span>
              <span className="tabular-nums">৳{it.price.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
