import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext.tsx';
import { ArrowLeft, Search, Truck, X, Check } from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

function getDeliveryDiffDays(deliveryDateStr: string | undefined, today: string) {
  if (!deliveryDateStr) return null;
  const dDate = new Date(deliveryDateStr).getTime();
  const tDate = new Date(today).getTime();
  return Math.round((dDate - tDate) / (1000 * 3600 * 24));
}

interface DeliveryScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const DeliveryScreen: React.FC<DeliveryScreenProps> = ({ onNavigate }) => {
  const { state, updateOfficerOrderStatus, updateAirmanOrderStatus } = useApp();

  const [activeTab, setActiveTab] = useState<'Officer' | 'Airman'>('Officer');
  const [searchQuery, setSearchQuery] = useState('');
  const [toast, setToast] = useState<{ message: string; undoAction?: () => void } | null>(null);

  const todayStr = new Date().toISOString().slice(0, 10);

  // Undelivered Officer Orders
  const undeliveredOfficerOrders = useMemo(() => {
    return state.officerOrders.filter((o) => o.status !== 'Delivered');
  }, [state.officerOrders]);

  // Undelivered Airman Orders
  const undeliveredAirmanOrders = useMemo(() => {
    return state.airmanOrders.filter((o) => o.status !== 'Delivered');
  }, [state.airmanOrders]);

  const currentList = activeTab === 'Officer' ? undeliveredOfficerOrders : undeliveredAirmanOrders;

  const filteredOrders = useMemo(() => {
    if (!searchQuery.trim()) return currentList;
    const q = searchQuery.toLowerCase().trim();
    return currentList.filter((order) => {
      const name = (order.customerName || '').toLowerCase();
      const phone = (order.customerPhone || '').toLowerCase();
      const bd = (order.customerBdNumber || '').toLowerCase();
      const num = String(order.orderNumber);
      return name.includes(q) || phone.includes(q) || bd.includes(q) || num.includes(q);
    });
  }, [currentList, searchQuery]);

  const handleDeliver = (orderNumber: number) => {
    if (activeTab === 'Officer') {
      const target = state.officerOrders.find((o) => o.orderNumber === orderNumber);
      const prevStatus = target?.status || 'Pending';
      updateOfficerOrderStatus(orderNumber, 'Delivered');
      setToast({
        message: `Order #${orderNumber} delivered`,
        undoAction: () => {
          updateOfficerOrderStatus(orderNumber, prevStatus);
          setToast(null);
        },
      });
    } else {
      const target = state.airmanOrders.find((o) => o.orderNumber === orderNumber);
      const prevStatus = target?.status || 'Pending';
      updateAirmanOrderStatus(orderNumber, 'Delivered');
      setToast({
        message: `Airman order #${orderNumber} delivered`,
        undoAction: () => {
          updateAirmanOrderStatus(orderNumber, prevStatus);
          setToast(null);
        },
      });
    }

    setTimeout(() => {
      setToast((cur) => (cur?.message.includes(String(orderNumber)) ? null : cur));
    }, 4000);
  };

  return (
    <div className="w-full max-w-[1280px] mx-auto pb-24 font-sans">
      {/* Back Link */}
      <div className="pt-2 pb-2">
        <button
          onClick={() => onNavigate('orders')}
          className="inline-flex items-center gap-1.5 text-[#0066cc] font-semibold text-sm hover:underline cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Orders
        </button>
      </div>

      {/* Header with Title and Right Dark Card */}
      <div className="flex justify-between items-end pb-5 pt-2">
        <div>
          <h1 className="text-[40px] font-semibold tracking-[-0.03em] text-[#1d1d1f] leading-[1.1]">
            Delivery
          </h1>
          <div className="text-[#6e6e73] text-[16px] mt-1.5">
            Pending and Cutting Slip – Done orders. Tap Deliver when the customer collects.
          </div>
        </div>

        {/* Right Dark Graphite Card: Waiting for delivery */}
        <div className="darzi-dark p-4 px-6 rounded-[20px] hidden sm:block shrink-0">
          <div className="text-[#ccc] text-xs font-semibold">Waiting for delivery</div>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className="text-[32px] font-semibold text-white leading-none tabular-nums">
              {currentList.length}
            </span>
            <span className="text-[#ccc] text-xs">orders</span>
          </div>
        </div>
      </div>

      {/* Tabs (Officer vs Airman) */}
      <div className="darzi-seg w-fit mb-4 bg-white">
        <button
          onClick={() => setActiveTab('Officer')}
          className={activeTab === 'Officer' ? 'on' : ''}
        >
          Officer orders ({undeliveredOfficerOrders.length})
        </button>
        <button
          onClick={() => setActiveTab('Airman')}
          className={activeTab === 'Airman' ? 'on' : ''}
        >
          Airman orders ({undeliveredAirmanOrders.length})
        </button>
      </div>

      {/* Search Chip */}
      <div className="darzi-chip w-full text-[#6e6e73] mb-4 h-11 focus-within:border-[#0071e3] transition-colors">
        <Search className="w-4 h-4 text-[#6e6e73] shrink-0" />
        <input
          type="text"
          placeholder="Search name, phone, BD number or order number"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-transparent border-none outline-none text-[13px] text-[#1d1d1f] placeholder:text-[#6e6e73]"
        />
        {searchQuery && (
          <button onClick={() => setSearchQuery('')}>
            <X className="w-4 h-4 text-[#6e6e73]" />
          </button>
        )}
      </div>

      {/* Orders Table Panel */}
      <div className="darzi-pn p-4">
        {filteredOrders.length > 0 ? (
          <>
            {/* Header */}
            <div className="hidden sm:grid grid-cols-[1fr_160px_140px_130px] items-center px-4 h-10 bg-[#f5f5f7] rounded-[12px] text-xs font-semibold text-[#333] mb-1">
              <div>Order</div>
              <div>Delivery date</div>
              <div>Due</div>
              <div className="text-right">Action</div>
            </div>

            {/* Rows */}
            <div className="divide-y divide-[#f0f0f0]">
              {filteredOrders.map((order) => {
                const due = Number((order as any).due) || 0;
                const dDate = 'deliveryDate' in order ? order.deliveryDate : (order as any).deliveryDate || (order as any).deliveredDate;
                const diff = getDeliveryDiffDays(dDate, todayStr);
                const isToday = diff === 0;

                return (
                  <div
                    key={order.orderNumber}
                    className="grid grid-cols-1 sm:grid-cols-[1fr_160px_140px_130px] items-center px-4 py-3 sm:py-0 sm:h-[68px] text-xs hover:bg-[#fafafb] transition-colors gap-2 sm:gap-0"
                  >
                    {/* Order icon + Customer */}
                    <div className="flex items-center gap-3 min-w-0 pr-2">
                      <div className="darzi-ico relative text-xs">
                        #{order.orderNumber}
                        <i
                          className={`darzi-dot absolute -right-0.5 -bottom-0.5 border-2 border-white ${
                            order.status === 'Pending' ? 'darzi-dot-o' : 'darzi-dot-p'
                          }`}
                        />
                      </div>
                      <div className="min-w-0">
                        <div className="font-semibold text-[14px] text-[#1d1d1f] truncate">
                          {order.customerName}
                        </div>
                        <div className="text-[12px] text-[#6e6e73] truncate">
                          {activeTab} · {order.customerBdNumber}
                        </div>
                      </div>
                    </div>

                    {/* Delivery Date */}
                    <div>
                      {isToday ? (
                        <span>
                          <span className="darzi-tag bg-[rgba(240,86,31,0.1)] text-[#c2410c] mr-1.5">
                            Today
                          </span>
                          {dDate}
                        </span>
                      ) : (
                        <span className="text-[#6e6e73]">{dDate || 'Not set'}</span>
                      )}
                    </div>

                    {/* Due */}
                    <div className="font-semibold text-[14px] text-[#c62828] tabular-nums">
                      ৳{due.toLocaleString()} <span className="text-[#6e6e73] font-normal text-xs">due</span>
                    </div>

                    {/* Deliver Button */}
                    <div className="text-right">
                      <button
                        onClick={() => handleDeliver(order.orderNumber)}
                        className="darzi-btn darzi-btn-sm"
                      >
                        <Truck className="w-3.5 h-3.5" />
                        Deliver
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        ) : (
          /* Empty State (Exact Loop 2 Empty State) */
          <div className="py-16 text-center">
            <div className="w-14 h-14 rounded-full bg-[#f5f5f7] flex items-center justify-center mx-auto mb-3.5 text-[#6e6e73]">
              <Truck className="w-6 h-6" />
            </div>
            <div className="font-semibold text-[17px] text-[#1d1d1f]">
              Nothing waiting for delivery.
            </div>
            <div className="text-xs text-[#6e6e73] mt-1">
              All active orders have been handed over to customers.
            </div>
          </div>
        )}

        <div className="text-[#6e6e73] text-xs pt-4 px-4 border-t border-[#f0f0f0] mt-3">
          Same as changing the status on the order. Airman orders and Officer orders are separated by tab above.
        </div>
      </div>

      {/* Floating Glass Toast Notification (With Undo) */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 h-[56px] rounded-full darzi-glass flex items-center gap-5 px-6 font-semibold text-sm text-[#1d1d1f] shadow-[0_8px_32px_rgba(0,0,0,0.12)]"
          >
            <span>{toast.message}</span>
            {toast.undoAction && (
              <button
                onClick={toast.undoAction}
                className="text-[#0066cc] hover:underline font-semibold cursor-pointer"
              >
                Undo
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
