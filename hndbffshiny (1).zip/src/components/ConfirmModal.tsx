import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, Trash2, CheckCircle2, ShieldAlert } from 'lucide-react';

interface ConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  confirmVariant?: 'danger' | 'primary' | 'success';
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  title,
  message,
  confirmLabel = 'Continue',
  cancelLabel = 'Cancel',
  confirmVariant = 'primary',
  onConfirm,
  onCancel,
}) => {
  const getIconAndStyle = () => {
    switch (confirmVariant) {
      case 'danger':
        return {
          icon: <Trash2 className="w-6 h-6 text-rose-600" />,
          glow: 'bg-rose-500/15 border-rose-500/30 text-rose-600',
          btnClass:
            'bg-gradient-to-b from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white border border-rose-500/80 shadow-[0_2px_8px_rgba(225,29,72,0.35),inset_0_1px_0_rgba(255,255,255,0.2)]',
        };
      case 'success':
        return {
          icon: <CheckCircle2 className="w-6 h-6 text-emerald-600" />,
          glow: 'bg-emerald-500/15 border-emerald-500/30 text-emerald-600',
          btnClass:
            'bg-gradient-to-b from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white border border-emerald-500/80 shadow-[0_2px_8px_rgba(16,185,129,0.35),inset_0_1px_0_rgba(255,255,255,0.2)]',
        };
      default:
        return {
          icon: <ShieldAlert className="w-6 h-6 text-neutral-800" />,
          glow: 'bg-neutral-500/15 border-neutral-500/30 text-neutral-800',
          btnClass:
            'bg-gradient-to-b from-neutral-800 to-neutral-900 hover:from-neutral-700 hover:to-neutral-800 text-white border border-neutral-700 shadow-[0_2px_8px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.2)]',
        };
    }
  };

  const styleConfig = getIconAndStyle();

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Apple glass blur backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onCancel}
            className="fixed inset-0 bg-black/45 backdrop-blur-md"
            aria-hidden="true"
          />

          {/* Apple glass card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 12 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="relative z-10 w-full max-w-md bg-white/90 backdrop-blur-2xl rounded-2xl p-6 sm:p-7 border border-white/60 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.3),0_0_1px_1px_rgba(255,255,255,0.8)_inset]"
            role="dialog"
            aria-modal="true"
          >
            <div className="flex items-start gap-4">
              <div
                className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 border ${styleConfig.glow}`}
              >
                {styleConfig.icon}
              </div>

              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-bold text-neutral-900 tracking-tight leading-snug">
                  {title}
                </h3>
                <p className="text-sm text-neutral-600 mt-1.5 leading-relaxed">
                  {message}
                </p>
              </div>
            </div>

            {/* High-contrast Action Buttons with tactile hierarchy */}
            <div className="flex items-center justify-end gap-3 mt-7 pt-4 border-t border-neutral-200/60">
              <button
                type="button"
                onClick={onCancel}
                className="min-h-[40px] px-4 rounded-xl border border-neutral-300 bg-white hover:bg-neutral-50 active:bg-neutral-100 text-sm font-semibold text-neutral-700 shadow-xs transition-all active:translate-y-px cursor-pointer"
              >
                {cancelLabel}
              </button>

              <button
                type="button"
                onClick={onConfirm}
                className={`min-h-[40px] px-5 rounded-xl text-sm font-semibold transition-all active:translate-y-px cursor-pointer ${styleConfig.btnClass}`}
              >
                {confirmLabel}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
