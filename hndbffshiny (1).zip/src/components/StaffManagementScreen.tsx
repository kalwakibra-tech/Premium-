import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { StaffWorker } from '../types/index.ts';
import { MONTH_METADATA, MonthMeta } from '../utils/starterData.ts';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { PolarisBadge } from './polaris/PolarisBadge.tsx';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  Check,
  X,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  ChevronRight,
  Folder,
  Globe,
  Snowflake,
  Heart,
  Sprout,
  CloudRain,
  Flower2,
  Sun,
  CloudLightning,
  Umbrella,
  Wheat,
  Moon,
  Wind,
  Gift,
  AlertTriangle,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface StaffManagementScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

// Icon mapper for month symbols
const MonthIconComponent: React.FC<{ symbol: string; className?: string; style?: React.CSSProperties }> = ({
  symbol,
  className,
  style,
}) => {
  switch (symbol) {
    case 'Snowflake':
      return <Snowflake className={className} style={style} />;
    case 'Heart':
      return <Heart className={className} style={style} />;
    case 'Sprout':
      return <Sprout className={className} style={style} />;
    case 'CloudRain':
      return <CloudRain className={className} style={style} />;
    case 'Flower2':
      return <Flower2 className={className} style={style} />;
    case 'Sun':
      return <Sun className={className} style={style} />;
    case 'CloudLightning':
      return <CloudLightning className={className} style={style} />;
    case 'Umbrella':
      return <Umbrella className={className} style={style} />;
    case 'Wheat':
      return <Wheat className={className} style={style} />;
    case 'Moon':
      return <Moon className={className} style={style} />;
    case 'Wind':
      return <Wind className={className} style={style} />;
    case 'Gift':
      return <Gift className={className} style={style} />;
    default:
      return <Folder className={className} style={style} />;
  }
};

export const StaffManagementScreen: React.FC<StaffManagementScreenProps> = ({ onNavigate }) => {
  const { state, addWorker, updateWorker, deleteWorker } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [showInactive, setShowInactive] = useState(false);
  const [lang, setLang] = useState<'EN' | 'BN'>('EN');

  // Expanded worker IDs (to show Month Folders)
  const [expandedWorkerId, setExpandedWorkerId] = useState<string | null>(null);

  // Year switcher per worker (workerId -> year)
  const currentYear = new Date().getFullYear();
  const [selectedYears, setSelectedYears] = useState<Record<string, number>>({});

  // Add worker form state
  const [isAdding, setIsAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [newBanglaName, setNewBanglaName] = useState('');
  const [addError, setAddError] = useState('');

  // Edit worker state
  const [editingWorkerId, setEditingWorkerId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editBanglaName, setEditBanglaName] = useState('');
  const [editActive, setEditActive] = useState(true);
  const [editError, setEditError] = useState('');

  // Delete worker modal
  const [deleteTarget, setDeleteTarget] = useState<StaffWorker | null>(null);
  const [deleteErrorMessage, setDeleteErrorMessage] = useState('');

  const filteredWorkers = useMemo(() => {
    return state.workers
      .filter((w) => {
        if (!showInactive && !w.active) return false;
        if (!searchQuery.trim()) return true;
        const q = searchQuery.toLowerCase().trim();
        return (
          w.name.toLowerCase().includes(q) ||
          (w.banglaName || '').toLowerCase().includes(q)
        );
      })
      .sort((a, b) => a.serialNumber - b.serialNumber);
  }, [state.workers, showInactive, searchQuery]);

  const activeWorkerCount = state.workers.filter((w) => w.active).length;

  const getWorkerYear = (workerId: string) => {
    return selectedYears[workerId] || currentYear;
  };

  const setWorkerYear = (workerId: string, yr: number) => {
    setSelectedYears((prev) => ({ ...prev, [workerId]: yr }));
  };

  const handleSaveNewWorker = () => {
    setAddError('');
    if (!newName.trim()) {
      setAddError('Worker name is required.');
      return;
    }

    const res = addWorker(newName.trim(), newBanglaName.trim());
    if (!res.success) {
      setAddError(res.error || 'Failed to add worker.');
      return;
    }

    setNewName('');
    setNewBanglaName('');
    setIsAdding(false);
  };

  const handleStartEdit = (e: React.MouseEvent, worker: StaffWorker) => {
    e.stopPropagation();
    setEditingWorkerId(worker.id);
    setEditName(worker.name);
    setEditBanglaName(worker.banglaName || '');
    setEditActive(worker.active);
    setEditError('');
  };

  const handleSaveEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!editingWorkerId) return;
    if (!editName.trim()) {
      setEditError('Worker name cannot be empty.');
      return;
    }

    const res = updateWorker(editingWorkerId, {
      name: editName.trim(),
      banglaName: editBanglaName.trim(),
      active: editActive,
    });

    if (!res.success) {
      setEditError(res.error || 'Failed to update worker.');
      return;
    }

    setEditingWorkerId(null);
  };

  const handleDeleteClick = (e: React.MouseEvent, worker: StaffWorker) => {
    e.stopPropagation();
    const hasRows = state.workerRows.some((r) => r.workerId === worker.id);
    if (hasRows) {
      setDeleteErrorMessage(
        `Cannot delete worker "${worker.name}" because they have saved work entries. Remove all work entries before deleting.`
      );
      return;
    }
    setDeleteTarget(worker);
  };

  const handleConfirmDelete = () => {
    if (deleteTarget) {
      deleteWorker(deleteTarget.id);
      setDeleteTarget(null);
    }
  };

  const toggleWorkerExpand = (workerId: string) => {
    setExpandedWorkerId((prev) => (prev === workerId ? null : workerId));
  };

  return (
    <PolarisPage
      title={lang === 'BN' ? 'কারিগরবৃন্দ (Workers)' : 'Workers'}
      subtitle={
        lang === 'BN'
          ? 'কারিগরদের মাসিক কাজের হিসাব, খোরচ ও লেজার খাতা'
          : 'Tailoring staff sheets, work records, and month-wise entries'
      }
      badge={
        <PolarisBadge tone="info">
          {activeWorkerCount} {lang === 'BN' ? 'জন' : 'workers'}
        </PolarisBadge>
      }
      secondaryActions={[
        {
          label: lang === 'EN' ? 'বাংলা' : 'English',
          onClick: () => setLang(lang === 'EN' ? 'BN' : 'EN'),
          icon: <Globe className="w-3.5 h-3.5 text-[#005BD3]" />,
        },
      ]}
      primaryAction={{
        label: lang === 'BN' ? 'নতুন কারিগর' : 'Add Worker',
        onClick: () => {
          setIsAdding(true);
          setAddError('');
        },
        icon: <Plus className="w-3.5 h-3.5" />,
      }}
      fullWidth={true}
    >
      {/* Controls Card: Search & Inactive Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#8A8A8A]" />
          <input
            type="text"
            placeholder={lang === 'BN' ? 'নাম দিয়ে খুঁজুন...' : 'Search by name...'}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-7 pl-8 pr-3 text-[12px] bg-white border border-[#E3E3E3] rounded-lg focus:outline-none focus:border-[#303030] text-[#303030]"
          />
        </div>

        <label className="flex items-center space-x-2 text-[12px] font-[450] text-[#616161] cursor-pointer select-none">
          <input
            type="checkbox"
            checked={showInactive}
            onChange={(e) => setShowInactive(e.target.checked)}
            className="rounded border-[#8A8A8A] text-[#303030] focus:ring-[#005BD3]"
          />
          <span>{lang === 'BN' ? 'নিষ্ক্রিয় কারিগর দেখান' : 'Show inactive workers'}</span>
        </label>
      </div>

      {/* Add Worker Inline Card */}
      {isAdding && (
        <PolarisCard title={lang === 'BN' ? 'নতুন কারিগর যুক্ত করুন' : 'Add New Worker'}>
          <div className="space-y-3">
            {addError && (
              <div className="p-2.5 bg-[#FEE9E8] text-[#8E0B21] text-[12px] font-medium rounded-lg">
                {addError}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[12px] font-[550] text-[#303030] mb-1">
                  Name (English) <span className="text-[#8E0B21]">*</span>
                </label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. Rashid Ahmed"
                  className="w-full h-8 px-3 text-[13px] bg-white border border-[#E3E3E3] rounded-lg focus:outline-none focus:border-[#303030]"
                />
              </div>
              <div>
                <label className="block text-[12px] font-[550] text-[#303030] mb-1">Bangla Name</label>
                <input
                  type="text"
                  value={newBanglaName}
                  onChange={(e) => setNewBanglaName(e.target.value)}
                  placeholder="e.g. রশীদ আহমেদ"
                  className="w-full h-8 px-3 text-[13px] bg-white border border-[#E3E3E3] rounded-lg focus:outline-none focus:border-[#303030]"
                />
              </div>
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setIsAdding(false)}
                className="h-7 px-3 rounded-lg bg-white border border-[#E3E3E3] text-[#303030] text-[13px] font-[550]"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveNewWorker}
                className="h-7 px-3 rounded-lg bg-[#303030] hover:bg-[#1A1A1A] text-white text-[13px] font-[550]"
              >
                Save Worker
              </button>
            </div>
          </div>
        </PolarisCard>
      )}

      {/* Workers List Card (Polaris Card with 12 Month Folders) */}
      <PolarisCard
        title={lang === 'BN' ? 'কারিগর তালিকা' : 'Workers List'}
        subtitle={
          lang === 'BN' ? 'ফোল্ডারে ক্লিক করে মাস খুলুন' : 'Tap a worker to expand month folders'
        }
        flush={true}
      >
        {filteredWorkers.length === 0 ? (
          <div className="p-12 text-center text-[#616161]">
            <p className="text-[13px]">No workers found matching your search.</p>
          </div>
        ) : (
          <div className="divide-y divide-[#E3E3E3]">
            {filteredWorkers.map((worker) => {
              const isEditing = editingWorkerId === worker.id;
              const isExpanded = expandedWorkerId === worker.id;
              const workerYear = getWorkerYear(worker.id);

              if (isEditing) {
                return (
                  <div key={worker.id} className="p-4 bg-[#F7F7F7] space-y-3">
                    {editError && (
                      <div className="p-2 bg-[#FEE9E8] text-[#8E0B21] text-[12px] font-medium rounded-lg">
                        {editError}
                      </div>
                    )}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
                      <div>
                        <label className="block text-[12px] font-[550] text-[#303030] mb-1">
                          Name (English)
                        </label>
                        <input
                          type="text"
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="w-full h-8 px-3 text-[13px] bg-white border border-[#E3E3E3] rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-[12px] font-[550] text-[#303030] mb-1">Bangla Name</label>
                        <input
                          type="text"
                          value={editBanglaName}
                          onChange={(e) => setEditBanglaName(e.target.value)}
                          className="w-full h-8 px-3 text-[13px] bg-white border border-[#E3E3E3] rounded-lg"
                        />
                      </div>
                      <div className="flex items-center space-x-3">
                        <label className="flex items-center space-x-2 text-[12px] font-[450] text-[#303030] cursor-pointer">
                          <input
                            type="checkbox"
                            checked={editActive}
                            onChange={(e) => setEditActive(e.target.checked)}
                            className="rounded border-[#8A8A8A] text-[#303030]"
                          />
                          <span>Active</span>
                        </label>

                        <div className="flex items-center space-x-1.5 ml-auto">
                          <button
                            onClick={() => setEditingWorkerId(null)}
                            className="h-7 px-2.5 rounded-lg bg-white border border-[#E3E3E3] text-[#616161]"
                          >
                            <X className="w-4 h-4" />
                          </button>
                          <button
                            onClick={handleSaveEdit}
                            className="h-7 px-2.5 rounded-lg bg-[#303030] text-white"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              }

              return (
                <div key={worker.id} className="transition-all duration-200">
                  {/* Worker Row Profile Card */}
                  <div
                    onClick={() => toggleWorkerExpand(worker.id)}
                    className="p-4 sm:p-5 hover:bg-blue-50/20 cursor-pointer flex items-center justify-between transition-all group"
                  >
                    <div className="flex items-center space-x-3.5">
                      {/* Gradient Avatar */}
                      <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-slate-900 via-indigo-900 to-blue-700 text-white flex items-center justify-center text-sm font-black shrink-0 shadow-md shadow-blue-900/20 border border-white/20">
                        {worker.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="font-black text-gray-950 text-base group-hover:text-blue-700 transition-colors">
                            {worker.name}
                          </h3>
                          {worker.banglaName && (
                            <span className="text-sm text-gray-500 font-semibold">
                              ({worker.banglaName})
                            </span>
                          )}
                          <span className="text-xs font-mono font-bold text-gray-700 bg-gray-100 px-2 py-0.5 rounded-md">
                            #{worker.serialNumber}
                          </span>
                          {worker.active ? (
                            <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                              <span>Active</span>
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-gray-100 text-gray-500">
                              Inactive
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-gray-500 mt-1">
                          Click to expand monthly accounts & hishab folders
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1.5">
                      <button
                        onClick={(e) => handleStartEdit(e, worker)}
                        className="p-2 text-gray-500 hover:text-blue-700 hover:bg-blue-50 rounded-xl transition-colors"
                        title="Edit Worker Profile"
                        aria-label={`Edit worker ${worker.name}`}
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={(e) => handleDeleteClick(e, worker)}
                        className="p-2 text-gray-500 hover:text-red-700 hover:bg-red-50 rounded-xl transition-colors"
                        title="Delete Worker"
                        aria-label={`Delete worker ${worker.name}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                      <div className={`p-2 rounded-xl text-gray-400 group-hover:text-gray-900 transition-transform duration-200 ${isExpanded ? 'rotate-180 text-blue-700' : ''}`}>
                        <ChevronDown className="w-5 h-5" />
                      </div>
                    </div>
                  </div>

                  {/* Expanded 12 Month Folders with Apple Inbuilt Gradients */}
                  {isExpanded && (
                    <div className="p-5 sm:p-6 bg-gradient-to-b from-gray-50/80 to-slate-100/50 border-t border-gray-200/90 space-y-4">
                      {/* Segmented Year Switcher */}
                      <div className="flex items-center justify-between max-w-xs mx-auto py-1 px-2 bg-white/90 backdrop-blur-md border border-gray-200 rounded-2xl shadow-sm">
                        <button
                          type="button"
                          onClick={() => setWorkerYear(worker.id, workerYear - 1)}
                          className="p-1.5 rounded-xl text-gray-600 hover:text-gray-950 hover:bg-gray-100 transition-colors"
                          aria-label="Previous year"
                        >
                          <ChevronLeft className="w-4 h-4 stroke-[2.5]" />
                        </button>
                        <span className="text-base font-black text-gray-950 font-mono tracking-wide">
                          {workerYear} Fiscal Ledger
                        </span>
                        <button
                          type="button"
                          onClick={() => setWorkerYear(worker.id, workerYear + 1)}
                          className="p-1.5 rounded-xl text-gray-600 hover:text-gray-950 hover:bg-gray-100 transition-colors"
                          aria-label="Next year"
                        >
                          <ChevronRight className="w-4 h-4 stroke-[2.5]" />
                        </button>
                      </div>

                      {/* 12 Month Folders Grid with Inbuilt Gradients */}
                      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                        {MONTH_METADATA.map((meta: MonthMeta) => {
                          const monthStr = `${workerYear}-${meta.numStr}`;

                          const monthRows = state.workerRows.filter((r) => {
                            if (r.workerId !== worker.id) return false;
                            const rMonth = (r.date || '').slice(0, 7);
                            const kMonth = (r.khorochDate || r.date || '').slice(0, 7);
                            return rMonth === monthStr || kMonth === monthStr;
                          });

                          let totalTaka = 0;
                          let validRowsCount = 0;

                          monthRows.forEach((r) => {
                            const rMonth = (r.date || '').slice(0, 7);
                            if (rMonth === monthStr && r.item && r.quantity > 0) {
                              totalTaka += Number(r.totalTaka) || 0;
                              validRowsCount += 1;
                            }
                          });

                          const isDecember = meta.numStr === '12';

                          return (
                            <div
                              key={meta.numStr}
                              onClick={() =>
                                onNavigate('worker-page', {
                                  workerId: worker.id,
                                  month: monthStr,
                                })
                              }
                              className={`p-4 rounded-2xl border-2 cursor-pointer shadow-sm hover:shadow-md transition-all duration-200 flex flex-col justify-between group active:scale-98 ${
                                isDecember
                                  ? 'bg-gradient-to-br from-rose-50/90 via-red-50/50 to-white border-red-300 hover:border-red-500 shadow-rose-500/10'
                                  : 'bg-white hover:border-blue-400 border-gray-200/90'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-2">
                                  <div
                                    className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 shadow-2xs transition-transform group-hover:scale-105 ${
                                      isDecember
                                        ? 'bg-gradient-to-tr from-red-600 to-rose-500 text-white shadow-red-500/30'
                                        : 'text-white'
                                    }`}
                                    style={!isDecember ? {
                                      backgroundColor: meta.strong,
                                    } : undefined}
                                  >
                                    <MonthIconComponent symbol={meta.symbol} className="w-4 h-4 stroke-[2.2]" />
                                  </div>
                                  <div>
                                    <span className="font-black text-gray-950 text-sm block leading-tight">
                                      {lang === 'BN' ? meta.banglaName : meta.name}
                                    </span>
                                    <span className="text-[11px] font-mono text-gray-600 block">
                                      Month {meta.numStr}
                                    </span>
                                  </div>
                                </div>
                              </div>

                              <div className="mt-3.5 pt-2.5 border-t border-gray-100 flex items-center justify-between text-xs">
                                <span className="text-gray-500 font-medium">
                                  {validRowsCount} {lang === 'BN' ? 'কাজ' : 'items'}
                                </span>
                                <span className={`font-black font-mono text-sm tabular-nums ${
                                  totalTaka > 0 ? (isDecember ? 'text-red-700' : 'text-blue-700') : 'text-gray-400'
                                }`}>
                                  ৳{totalTaka.toLocaleString()}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </PolarisCard>

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-2xs animate-in fade-in">
          <div
            className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-[#E3E3E3]"
            style={{ borderRadius: 'var(--radius-lg)' }}
          >
            <div className="h-12 px-4 bg-[#F1F1F1] border-b border-[#E3E3E3] flex items-center justify-between">
              <h3 className="text-[14px] font-[650] text-[#1A1A1A]">Delete Worker?</h3>
              <button
                onClick={() => setDeleteTarget(null)}
                className="p-1 rounded text-[#616161] hover:text-[#1A1A1A]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-2 text-[13px] text-[#616161]">
              <p>
                Are you sure you want to delete worker <strong>{deleteTarget.name}</strong>?
              </p>
            </div>
            <div className="px-4 py-3 bg-[#FAFAFA] border-t border-[#E3E3E3] flex items-center justify-end space-x-2">
              <button
                onClick={() => setDeleteTarget(null)}
                className="h-7 px-3 rounded-lg bg-white border border-[#E3E3E3] text-[#303030] text-[13px] font-[550]"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                className="h-7 px-3 rounded-lg bg-[#8E0B21] hover:bg-[#72091A] text-white text-[13px] font-[550]"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Blocked Delete Modal */}
      {deleteErrorMessage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-2xs animate-in fade-in">
          <div
            className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-[#E3E3E3]"
            style={{ borderRadius: 'var(--radius-lg)' }}
          >
            <div className="h-12 px-4 bg-[#F1F1F1] border-b border-[#E3E3E3] flex items-center justify-between">
              <h3 className="text-[14px] font-[650] text-[#8E0B21] flex items-center space-x-1.5">
                <AlertTriangle className="w-4 h-4" />
                <span>Cannot Delete Worker</span>
              </h3>
              <button
                onClick={() => setDeleteErrorMessage('')}
                className="p-1 rounded text-[#616161] hover:text-[#1A1A1A]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 text-[13px] text-[#616161] leading-relaxed">
              {deleteErrorMessage}
            </div>
            <div className="px-4 py-3 bg-[#FAFAFA] border-t border-[#E3E3E3] flex justify-end">
              <button
                onClick={() => setDeleteErrorMessage('')}
                className="h-7 px-3 rounded-lg bg-[#303030] text-white text-[13px] font-[550]"
              >
                Understood
              </button>
            </div>
          </div>
        </div>
      )}
    </PolarisPage>
  );
};
