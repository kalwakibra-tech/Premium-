import React from 'react';
import { OrderStatus } from '../types/index.ts';

interface StatusBadgeProps {
  status: OrderStatus;
  onChange?: (newStatus: OrderStatus) => void;
  interactive?: boolean;
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  onChange,
  interactive = false,
  className = '',
}) => {
  const getStatusStyles = (st: OrderStatus) => {
    switch (st) {
      case 'Pending':
        return 'bg-[#FFEA8A] text-[#5E4200]';
      case 'Cutting Slip – Done':
        return 'bg-[#C4E4F9] text-[#00527C]';
      case 'Delivered':
        return 'bg-[#AFFEBF] text-[#0C5132]';
      default:
        return 'bg-[#E3E3E3] text-[#4A4A4A]';
    }
  };

  const renderStatusDot = (st: OrderStatus) => {
    switch (st) {
      case 'Pending':
        return <span className="w-1.5 h-1.5 rounded-full bg-[#B58A00] mr-1.5 shrink-0" />;
      case 'Cutting Slip – Done':
        return <span className="w-1.5 h-1.5 rounded-full bg-[#00527C] mr-1.5 shrink-0" />;
      case 'Delivered':
        return <span className="w-1.5 h-1.5 rounded-full bg-[#0C5132] mr-1.5 shrink-0" />;
      default:
        return null;
    }
  };

  if (!interactive || !onChange) {
    return (
      <span
        className={`inline-flex items-center h-[20px] px-2 rounded-[8px] text-[12px] leading-4 font-[550] whitespace-nowrap ${getStatusStyles(
          status
        )} ${className}`}
        style={{ borderRadius: 'var(--radius-sm)' }}
      >
        {renderStatusDot(status)}
        {status}
      </span>
    );
  }

  return (
    <div className={`relative inline-flex items-center ${className}`}>
      <select
        value={status}
        onChange={(e) => {
          e.stopPropagation();
          onChange(e.target.value as OrderStatus);
        }}
        onClick={(e) => e.stopPropagation()}
        aria-label="Order status"
        className={`h-[20px] text-[12px] font-[550] rounded-[8px] pl-2 pr-4 cursor-pointer outline-none transition-colors border-0 ${getStatusStyles(
          status
        )}`}
        style={{ borderRadius: 'var(--radius-sm)' }}
      >
        <option value="Pending" className="bg-white text-[#5E4200]">
          Pending
        </option>
        <option value="Cutting Slip – Done" className="bg-white text-[#00527C]">
          Cutting Slip – Done
        </option>
        <option value="Delivered" className="bg-white text-[#0C5132]">
          Delivered
        </option>
      </select>
    </div>
  );
};
