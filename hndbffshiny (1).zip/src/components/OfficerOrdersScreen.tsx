import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext.tsx';
import { OfficerOrder, OrderStatus } from '../types/index.ts';
import { formatDate, isOrderUpcoming } from '../utils/logic.ts';
import {
  Plus,
  Search,
  Truck,
  Edit2,
  Trash2,
  Scissors,
  Printer,
  ChevronDown,
  X,
  Check,
  LayoutGrid,
  List,
  Eye,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface OfficerOrdersScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const OfficerOrdersScreen: React.FC<OfficerOrdersScreenProps> = ({ onNavigate }) => {
  const { state, updateOfficerOrderStatus, deleteOfficerOrder, recordOfficerPayment } = useApp();

  const [activeTab, setActiveTab] = useState<'All' | OrderStatus>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  const [activeCardFilter, setActiveCardFilter] = useState<'upcoming' | 'due' | null>(null);

  // Selected Order for Right Preview Panel
  const [selectedOrderNumber, setSelectedOrderNumber] = useState<number | null>(null);

  // Status Dropdown open state
  const [openStatusDropdownOrderNum, setOpenStatusDropdownOrderNum] = useState<number | null>(null);

  // Pay Confirmation Dialog
  const [payTargetOrder, setPayTargetOrder] = useState<OfficerOrder | null>(null);

  // Two-step Delete Dialog
  const [deleteTargetOrder, setDeleteTargetOrder] = useState<OfficerOrder | null>(null);
  const [deleteStep, setDeleteStep] = useState<1 | 2>(1);

  // Toast notification with undo
  const [toast, setToast] = useState<{ message: string; undoAction?: () => void } | null>(null);

  const todayStr = formatDate();
  const upcomingDays = state.settings.upcomingDeliveryDays || 3;

  // Upcoming to deliver
  const upcomingOrders = useMemo(() => {
    return state.officerOrders.filter((o) =>
      isOrderUpcoming(o.deliveryDate, o.status === 'Delivered', todayStr, upcomingDays)
    );
  }, [state.officerOrders, todayStr, upcomingDays]);

  // Due after delivery orders
  const dueOrders = useMemo(() => {
    return state.officerOrders.filter((o) => o.status === 'Delivered' && o.due > 0);
  }, [state.officerOrders]);

  const totalDueAmount = useMemo(() => {
    return dueOrders.reduce((sum, o) => sum + (Number(o.due) || 0), 0);
  }, [dueOrders]);

  // Tab counts
  const tabCounts = useMemo(() => {
    return {
      All: state.officerOrders.length,
      Pending: state.officerOrders.filter((o) => o.status === 'Pending').length,
      'Cutting Slip – Done': state.officerOrders.filter((o) => o.status === 'Cutting Slip – Done').length,
      Delivered: state.officerOrders.filter((o) => o.status === 'Delivered').length,
    };
  }, [state.officerOrders]);

  // Filtered and sorted orders
  const filteredOrders = useMemo(() => {
    return state.officerOrders
      .filter((order) => {
        // Tab filter
        if (activeTab !== 'All' && order.status !== activeTab) return false;

        // Card filter
        if (activeCardFilter === 'upcoming') {
          if (!isOrderUpcoming(order.deliveryDate, order.status === 'Delivered', todayStr, upcomingDays)) {
            return false;
          }
        } else if (activeCardFilter === 'due') {
          if (!(order.status === 'Delivered' && order.due > 0)) {
            return false;
          }
        }

        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchesName = (order.customerName || '').toLowerCase().includes(q);
          const matchesPhone = (order.customerPhone || '').toLowerCase().includes(q);
          const matchesBd = (order.customerBdNumber || '').toLowerCase().includes(q);
          const matchesOrderNum = String(order.orderNumber).includes(q) || `#${order.orderNumber}`.includes(q);
          if (!matchesName && !matchesPhone && !matchesBd && !matchesOrderNum) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortOrder === 'newest') {
          return b.orderNumber - a.orderNumber;
        } else {
          return a.orderNumber - b.orderNumber;
        }
      });
  }, [state.officerOrders, activeTab, activeCardFilter, searchQuery, sortOrder, todayStr, upcomingDays]);

  // Active selected order for preview panel
  const selectedOrder = useMemo(() => {
    if (filteredOrders.length === 0) return null;
    if (selectedOrderNumber) {
      const found = filteredOrders.find((o) => o.orderNumber === selectedOrderNumber);
      if (found) return found;
    }
    return filteredOrders[0];
  }, [filteredOrders, selectedOrderNumber]);

  const handleStatusChange = (order: OfficerOrder, newStatus: OrderStatus) => {
    const oldStatus = order.status;
    updateOfficerOrderStatus(order.orderNumber, newStatus);
    setOpenStatusDropdownOrderNum(null);
    setToast({
      message: `Order #${order.orderNumber} is now ${newStatus}`,
      undoAction: () => {
        updateOfficerOrderStatus(order.orderNumber, oldStatus);
        setToast(null);
      },
    });
    setTimeout(() => {
      setToast((cur) => (cur?.message.includes(String(order.orderNumber)) ? null : cur));
    }, 4000);
  };

  const handlePay = (order: OfficerOrder) => {
    setPayTargetOrder(order);
  };

  const confirmPay = () => {
    if (payTargetOrder) {
      recordOfficerPayment(payTargetOrder.orderNumber, payTargetOrder.due);
      setToast({
        message: `Received ৳${payTargetOrder.due.toLocaleString()} from ${payTargetOrder.customerName}`,
      });
      setPayTargetOrder(null);
      setTimeout(() => setToast(null), 3500);
    }
  };

  const handleDelete = (order: OfficerOrder) => {
    setDeleteTargetOrder(order);
    setDeleteStep(1);
  };

  const confirmDeleteStep1 = () => setDeleteStep(2);

  const confirmDeleteStep2 = () => {
    if (deleteTargetOrder) {
      deleteOfficerOrder(deleteTargetOrder.orderNumber);
      setToast({
        message: `Order #${deleteTargetOrder.orderNumber} deleted`,
      });
      setDeleteTargetOrder(null);
      setDeleteStep(1);
      setTimeout(() => setToast(null), 3500);
    }
  };

  return (
    <div className="w-full max-w-[1340px] mx-auto pb-16 font-sans">
      {/* =========================================================================
          DESKTOP VIEW (Exact Loop 1 & 2 layout)
         ========================================================================= */}
      <div className="hidden md:block">
        {/* Page Header */}
        <div className="flex justify-between items-end py-5">
          <div>
            <h1 className="text-[40px] font-semibold tracking-[-0.03em] text-[#1d1d1f] leading-[1.1]">
              Orders
            </h1>
            <div className="text-[#6e6e73] text-[16px] mt-1.5">
              Every Officer order, from first fitting to final due.
            </div>
          </div>
          <div className="flex items-center gap-2.5">
            {/* View Mode Toggle (Grid vs Table) */}
            <div className="darzi-seg">
              <button
                onClick={() => setViewMode('table')}
                className={viewMode === 'table' ? 'on' : ''}
                title="Table view"
              >
                <List className="w-3.5 h-3.5 inline mr-1" />
                Table
              </button>
              <button
                onClick={() => setViewMode('grid')}
                className={viewMode === 'grid' ? 'on' : ''}
                title="Grid view"
              >
                <LayoutGrid className="w-3.5 h-3.5 inline mr-1" />
                Grid
              </button>
            </div>

            <button
              onClick={() => onNavigate('delivery')}
              className="darzi-btn darzi-btn-gh"
            >
              <Truck className="w-4 h-4" />
              Delivery
            </button>
            <button
              onClick={() => onNavigate('new-officer-order')}
              className="darzi-btn"
            >
              <Plus className="w-4 h-4" />
              New order
            </button>
          </div>
        </div>

        {/* Top 2 Cards: Left Tray "Upcoming to deliver", Right Dark "Due after delivery" */}
        <div className="darzi-pn grid grid-cols-2 gap-4 p-4 mb-5">
          {/* Upcoming to deliver Tray */}
          <div
            onClick={() => setActiveCardFilter((prev) => (prev === 'upcoming' ? null : 'upcoming'))}
            className={`darzi-tray p-5 rounded-[18px] cursor-pointer transition-all ${
              activeCardFilter === 'upcoming' ? 'ring-2 ring-[#0071e3] bg-white' : 'hover:bg-[#ebebed]'
            }`}
          >
            <div className="font-semibold text-[#6e6e73] text-sm">Upcoming to deliver</div>
            <div className="my-2.5 flex items-baseline gap-2">
              <span className="text-[40px] font-semibold tracking-[-0.04em] text-[#1d1d1f] leading-none tabular-nums">
                {upcomingOrders.length}
              </span>
              <span className="text-[#6e6e73] text-sm">orders · next {upcomingDays} days</span>
            </div>
            <div className="grid gap-2">
              {upcomingOrders.slice(0, 2).map((order) => (
                <div
                  key={order.orderNumber}
                  className="bg-white rounded-[14px] p-2.5 px-3.5 flex justify-between items-center shadow-xs"
                >
                  <div>
                    <div className="font-semibold text-[13px] text-[#1d1d1f]">{order.customerName}</div>
                    <div className="text-[11px] text-[#6e6e73]">
                      #{order.orderNumber} · {order.status}
                    </div>
                  </div>
                  <b className="font-semibold text-xs text-[#1d1d1f]">{order.deliveryDate || 'Not set'}</b>
                </div>
              ))}
              {upcomingOrders.length === 0 && (
                <div className="text-xs text-[#6e6e73] italic py-2">No upcoming orders due in the next {upcomingDays} days.</div>
              )}
            </div>
          </div>

          {/* Due after delivery Dark Graphite Card with Specular Sheen */}
          <div
            onClick={() => setActiveCardFilter((prev) => (prev === 'due' ? null : 'due'))}
            className={`darzi-dark p-5 rounded-[18px] cursor-pointer transition-all ${
              activeCardFilter === 'due' ? 'ring-2 ring-white/50' : ''
            }`}
          >
            <div className="font-semibold text-[#ccc] text-sm">Due after delivery</div>
            <div className="my-2.5 flex items-baseline gap-2">
              <span className="text-[40px] font-semibold tracking-[-0.04em] text-white leading-none tabular-nums">
                ৳{totalDueAmount.toLocaleString()}
              </span>
              <span className="text-[#ccc] text-sm">{dueOrders.length} orders</span>
            </div>
            <div className="grid gap-2">
              {dueOrders.slice(0, 2).map((order) => (
                <div
                  key={order.orderNumber}
                  className="bg-white/10 rounded-[14px] p-2.5 px-3.5 flex justify-between items-center"
                >
                  <div>
                    <div className="font-semibold text-[13px] text-white">{order.customerName}</div>
                    <div className="text-[11px] text-[#ccc]">
                      #{order.orderNumber} · ৳{order.due.toLocaleString()} due
                    </div>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handlePay(order);
                    }}
                    className="darzi-btn darzi-btn-sm"
                  >
                    Pay ৳{order.due.toLocaleString()}
                  </button>
                </div>
              ))}
              {dueOrders.length === 0 && (
                <div className="text-xs text-[#ccc] italic py-2">All delivered orders are fully settled.</div>
              )}
            </div>
          </div>
        </div>

        {/* Filter Pills Bar */}
        <div className="flex gap-2.5 items-center my-4">
          <button
            onClick={() => {
              setActiveTab('All');
              setActiveCardFilter(null);
            }}
            className={`darzi-chip ${activeTab === 'All' && !activeCardFilter ? 'darzi-chip-on' : ''}`}
          >
            All <span className="text-[#6e6e73] font-normal">{tabCounts.All}</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('Pending');
              setActiveCardFilter(null);
            }}
            className={`darzi-chip ${activeTab === 'Pending' ? 'darzi-chip-on' : ''}`}
          >
            Pending <span className="text-[#6e6e73] font-normal">{tabCounts.Pending}</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('Cutting Slip – Done');
              setActiveCardFilter(null);
            }}
            className={`darzi-chip ${activeTab === 'Cutting Slip – Done' ? 'darzi-chip-on' : ''}`}
          >
            Cutting Slip – Done{' '}
            <span className="text-[#6e6e73] font-normal">{tabCounts['Cutting Slip – Done']}</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('Delivered');
              setActiveCardFilter(null);
            }}
            className={`darzi-chip ${activeTab === 'Delivered' ? 'darzi-chip-on' : ''}`}
          >
            Delivered <span className="text-[#6e6e73] font-normal">{tabCounts.Delivered}</span>
          </button>

          {/* Active Card Filter Chip */}
          {activeCardFilter && (
            <button
              onClick={() => setActiveCardFilter(null)}
              className="darzi-chip darzi-chip-f"
            >
              Filter: {activeCardFilter === 'upcoming' ? 'Upcoming' : 'Due'}
              <X className="w-3.5 h-3.5 ml-1" />
            </button>
          )}

          {/* Search Chip */}
          <div className="darzi-chip flex-1 text-[#6e6e73] focus-within:border-[#0071e3] transition-colors">
            <Search className="w-4 h-4 text-[#6e6e73] shrink-0" />
            <input
              type="text"
              placeholder="Search name, phone, BD number or order number"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent border-none outline-none text-[13px] text-[#1d1d1f] placeholder:text-[#6e6e73]"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="p-0.5 text-[#6e6e73] hover:text-[#1d1d1f]">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Sort Dropdown Chip */}
          <button
            onClick={() => setSortOrder((prev) => (prev === 'newest' ? 'oldest' : 'newest'))}
            className="darzi-chip"
          >
            Sort <b className="font-semibold text-[#1d1d1f]">{sortOrder === 'newest' ? 'Newest first' : 'Oldest first'}</b>
            <ChevronDown className="w-3.5 h-3.5 text-[#6e6e73]" />
          </button>
        </div>

        {/* =====================================================================
            VIEW MODE: TABLE (Loop 1 & 2 Desktop Split)
           ===================================================================== */}
        {viewMode === 'table' ? (
          <div className="grid grid-cols-[1fr_360px] gap-5 items-start">
            {/* Orders Table Panel */}
            <div className="darzi-pn p-4">
              <div className="flex justify-between items-center px-4 pt-1 pb-3">
                <b className="font-semibold text-[20px] text-[#1d1d1f]">All orders</b>
                <span className="text-[#6e6e73] text-[12px]">
                  Showing {filteredOrders.length} of {state.officerOrders.length} · tap a row for details
                </span>
              </div>

              {/* Table Column Headers */}
              <div className="grid grid-cols-[190px_160px_58px_58px_62px_62px_62px_1fr] items-center px-4 h-10 bg-[#f5f5f7] rounded-[12px] text-[12px] font-semibold text-[#333] mb-1">
                <div>Order</div>
                <div>Status</div>
                <div>Ordered</div>
                <div>Delivery</div>
                <div>Total</div>
                <div>Advance</div>
                <div>Due</div>
                <div>Paid</div>
              </div>

              {/* Table Rows */}
              <div className="divide-y divide-[#f0f0f0]">
                {filteredOrders.map((order) => {
                  const isSelected = selectedOrder?.orderNumber === order.orderNumber;
                  const total = Number(order.totalAmount) || 0;
                  const adv = Number(order.advance) || 0;
                  const due = Number(order.due) || 0;
                  const paid = total - due;
                  const paidPct = total > 0 ? Math.min(100, Math.round((paid / total) * 100)) : 100;

                  return (
                    <div
                      key={order.orderNumber}
                      onClick={() => setSelectedOrderNumber(order.orderNumber)}
                      className={`grid grid-cols-[190px_160px_58px_58px_62px_62px_62px_1fr] items-center px-4 h-[68px] text-[13px] cursor-pointer transition-colors ${
                        isSelected ? 'bg-[#f0f0f0] rounded-[14px]' : 'hover:bg-[#fafafb]'
                      }`}
                    >
                      {/* Order info */}
                      <div className="flex items-center gap-2.5 min-w-0 pr-2">
                        <div className="darzi-ico text-[10px]">
                          #{order.orderNumber}
                        </div>
                        <div className="min-w-0">
                          <div className="font-semibold text-[13px] text-[#1d1d1f] truncate">
                            {order.customerName}
                          </div>
                          <div className="text-[11px] text-[#6e6e73] truncate">
                            Officer · {order.customerBdNumber}
                          </div>
                        </div>
                      </div>

                      {/* Status Dropdown */}
                      <div className="relative" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() =>
                            setOpenStatusDropdownOrderNum((cur) =>
                              cur === order.orderNumber ? null : order.orderNumber
                            )
                          }
                          className="darzi-st"
                        >
                          <i
                            className={`darzi-dot ${
                              order.status === 'Pending'
                                ? 'darzi-dot-o'
                                : order.status === 'Cutting Slip – Done'
                                ? 'darzi-dot-p'
                                : 'darzi-dot-g'
                            }`}
                          />
                          <span className="truncate max-w-[90px]">{order.status}</span>
                          <ChevronDown className="w-3 h-3 text-[#6e6e73]" />
                        </button>

                        {/* Status Dropdown Menu */}
                        {openStatusDropdownOrderNum === order.orderNumber && (
                          <div className="absolute top-10 left-0 z-30 bg-white rounded-[16px] p-1.5 shadow-[0_8px_32px_rgba(0,0,0,0.12)] border border-[#e0e0e0] w-[190px]">
                            {(['Pending', 'Cutting Slip – Done', 'Delivered'] as OrderStatus[]).map((st) => (
                              <button
                                key={st}
                                onClick={() => handleStatusChange(order, st)}
                                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-[10px] font-semibold text-xs text-left cursor-pointer transition-colors ${
                                  order.status === st ? 'bg-[#f5f5f7] text-[#1d1d1f]' : 'text-[#6e6e73] hover:bg-[#f5f5f7]'
                                }`}
                              >
                                <i
                                  className={`darzi-dot ${
                                    st === 'Pending'
                                      ? 'darzi-dot-o'
                                      : st === 'Cutting Slip – Done'
                                      ? 'darzi-dot-p'
                                      : 'darzi-dot-g'
                                  }`}
                                />
                                <span>{st}</span>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Ordered date */}
                      <div className="text-[#6e6e73] text-[12px] truncate">
                        {order.orderDate?.slice(5) || '—'}
                      </div>

                      {/* Delivery date */}
                      <div className="text-[#6e6e73] text-[12px] truncate">
                        {order.deliveryDate?.slice(5) || 'Not set'}
                      </div>

                      {/* Total */}
                      <div className="font-semibold text-[#1d1d1f] tabular-nums">
                        ৳{total.toLocaleString()}
                      </div>

                      {/* Advance */}
                      <div className="text-[#6e6e73] tabular-nums">
                        ৳{adv.toLocaleString()}
                      </div>

                      {/* Due */}
                      <div className={`tabular-nums font-semibold ${due > 0 ? 'text-[#c62828]' : 'text-[#1e7b43]'}`}>
                        ৳{due.toLocaleString()}
                      </div>

                      {/* Paid Progress Bar */}
                      <div>
                        <div className="darzi-bar w-[76px]">
                          <i style={{ width: `${paidPct}%` }} />
                        </div>
                        <div className="text-[10px] text-[#6e6e73] mt-1 tabular-nums">
                          {paidPct >= 100 ? 'Fully paid' : `${paidPct}% paid`}
                        </div>
                      </div>
                    </div>
                  );
                })}

                {filteredOrders.length === 0 && (
                  <div className="py-12 text-center text-[#6e6e73]">
                    <div className="darzi-ico mx-auto mb-3 w-12 h-12 text-sm">#0</div>
                    <div className="font-semibold text-[17px] text-[#1d1d1f]">No orders found</div>
                    <div className="text-xs text-[#6e6e73] mt-1 mb-4">Try clearing your filters or create a new order.</div>
                    <button
                      onClick={() => onNavigate('new-officer-order')}
                      className="darzi-btn darzi-btn-sm"
                    >
                      New order
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Selected Order Detail Preview Panel (Right Side) */}
            {selectedOrder ? (
              <div className="darzi-pn sticky top-20">
                {/* Header with bespoke # Icon */}
                <div className="flex gap-3.5 items-center">
                  <div className="darzi-ico w-14 h-14 rounded-[16px] text-sm">
                    #{selectedOrder.orderNumber}
                  </div>
                  <div className="min-w-0">
                    <div className="font-semibold text-[22px] tracking-[-0.02em] text-[#1d1d1f] truncate">
                      {selectedOrder.customerName}
                    </div>
                    <div className="text-[#6e6e73] text-xs">
                      Officer · {selectedOrder.customerBdNumber}
                    </div>
                  </div>
                </div>

                {/* 3-Step Progress Bar */}
                <div className="flex gap-1.5 my-4">
                  <i
                    className={`flex-1 h-1 rounded-full ${
                      selectedOrder.status === 'Pending' ||
                      selectedOrder.status === 'Cutting Slip – Done' ||
                      selectedOrder.status === 'Delivered'
                        ? 'bg-[#1d1d1f]'
                        : 'bg-[#e0e0e0]'
                    }`}
                  />
                  <i
                    className={`flex-1 h-1 rounded-full ${
                      selectedOrder.status === 'Cutting Slip – Done' || selectedOrder.status === 'Delivered'
                        ? 'bg-[#1d1d1f]'
                        : 'bg-[#e0e0e0]'
                    }`}
                  />
                  <i
                    className={`flex-1 h-1 rounded-full ${
                      selectedOrder.status === 'Delivered' ? 'bg-[#1d1d1f]' : 'bg-[#e0e0e0]'
                    }`}
                  />
                </div>
                <div className="flex gap-1 text-[11px] font-semibold text-[#6e6e73]">
                  <span className="flex-1 text-[#1d1d1f]">Pending</span>
                  <span className={`flex-1 ${selectedOrder.status !== 'Pending' ? 'text-[#1d1d1f]' : ''}`}>
                    Cutting Slip
                  </span>
                  <span className={`flex-1 text-right ${selectedOrder.status === 'Delivered' ? 'text-[#1d1d1f]' : ''}`}>
                    Delivered
                  </span>
                </div>

                {/* Dates Tray */}
                <div className="grid grid-cols-2 gap-2.5 my-4">
                  <div>
                    <div className="text-[#6e6e73] text-[12px]">Order date</div>
                    <div className="font-semibold text-xs text-[#1d1d1f]">{selectedOrder.orderDate || '—'}</div>
                  </div>
                  <div>
                    <div className="text-[#6e6e73] text-[12px]">Delivery date</div>
                    <div className="font-semibold text-xs text-[#1d1d1f]">
                      {selectedOrder.deliveryDate || 'Not set'}
                    </div>
                  </div>
                </div>

                {/* Due Big Number */}
                <div className="text-[#6e6e73] text-[12px]">Due</div>
                <div
                  className={`text-[46px] font-semibold tracking-[-0.04em] my-1 mb-4 leading-none tabular-nums ${
                    selectedOrder.due > 0 ? 'text-[#c62828]' : 'text-[#1e7b43]'
                  }`}
                >
                  ৳{selectedOrder.due.toLocaleString()}
                </div>

                {/* Paid Progress Tray */}
                <div className="darzi-tray p-3.5">
                  <div className="darzi-bar">
                    <i
                      style={{
                        width: `${
                          selectedOrder.totalAmount > 0
                            ? Math.min(
                                100,
                                Math.round(
                                  ((selectedOrder.totalAmount - selectedOrder.due) / selectedOrder.totalAmount) *
                                    100
                                )
                              )
                            : 100
                        }%`,
                      }}
                    />
                  </div>
                  <div className="text-[12px] text-[#6e6e73] my-2 tabular-nums">
                    {selectedOrder.totalAmount > 0
                      ? `${Math.round(
                          ((selectedOrder.totalAmount - selectedOrder.due) / selectedOrder.totalAmount) * 100
                        )}% paid`
                      : 'Fully paid'}
                  </div>
                  <div className="grid grid-cols-2 pt-1 border-t border-[#e8e8ed]">
                    <div>
                      <div className="text-[#6e6e73] text-[11px]">Total</div>
                      <div className="font-semibold text-xs text-[#1d1d1f] tabular-nums">
                        ৳{selectedOrder.totalAmount.toLocaleString()}
                      </div>
                    </div>
                    <div>
                      <div className="text-[#6e6e73] text-[11px]">Advance</div>
                      <div className="font-semibold text-xs text-[#1d1d1f] tabular-nums">
                        ৳{selectedOrder.advance.toLocaleString()}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="grid gap-2 mt-4">
                  {selectedOrder.due > 0 && selectedOrder.status === 'Delivered' && (
                    <button
                      onClick={() => handlePay(selectedOrder)}
                      className="darzi-btn w-full"
                    >
                      Pay ৳{selectedOrder.due.toLocaleString()}
                    </button>
                  )}
                  <div className="flex gap-2">
                    <button
                      onClick={() =>
                        onNavigate('order-details', {
                          orderNumber: selectedOrder.orderNumber,
                          category: 'Officer',
                        })
                      }
                      className="darzi-btn darzi-btn-tb flex-1 h-10 text-xs"
                    >
                      <Eye className="w-3.5 h-3.5" /> Details
                    </button>
                    <button
                      onClick={() =>
                        onNavigate('edit-officer-order', {
                          orderNumber: selectedOrder.orderNumber,
                        })
                      }
                      className="darzi-btn darzi-btn-tb flex-1 h-10 text-xs"
                    >
                      <Edit2 className="w-3.5 h-3.5" /> Edit
                    </button>
                    <button
                      onClick={() =>
                        onNavigate('print-slip', {
                          orderNumber: selectedOrder.orderNumber,
                          category: 'Officer',
                        })
                      }
                      className="darzi-btn darzi-btn-tb px-3 h-10"
                      title="Print Slip"
                    >
                      <Scissors className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(selectedOrder)}
                      className="darzi-btn darzi-btn-tb px-3 h-10 text-[#c62828] hover:bg-[#fce9e9]"
                      title="Delete Order"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        ) : (
          /* =====================================================================
              VIEW MODE: GRID (Option added by user with exact Darzi cards)
             ===================================================================== */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredOrders.map((order) => {
              const total = Number(order.totalAmount) || 0;
              const due = Number(order.due) || 0;
              const paid = total - due;
              const paidPct = total > 0 ? Math.min(100, Math.round((paid / total) * 100)) : 100;

              return (
                <div
                  key={order.orderNumber}
                  onClick={() =>
                    onNavigate('order-details', {
                      orderNumber: order.orderNumber,
                      category: 'Officer',
                    })
                  }
                  className="darzi-pn p-5 cursor-pointer hover:shadow-[0_4px_20px_rgba(0,0,0,0.06)] transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center gap-2.5">
                        <div className="darzi-ico text-xs">#{order.orderNumber}</div>
                        <div>
                          <div className="font-semibold text-[15px] text-[#1d1d1f]">{order.customerName}</div>
                          <div className="text-[11px] text-[#6e6e73]">Officer · {order.customerBdNumber}</div>
                        </div>
                      </div>
                      <span className="darzi-st">
                        <i
                          className={`darzi-dot ${
                            order.status === 'Pending'
                              ? 'darzi-dot-o'
                              : order.status === 'Cutting Slip – Done'
                              ? 'darzi-dot-p'
                              : 'darzi-dot-g'
                          }`}
                        />
                        {order.status}
                      </span>
                    </div>

                    <div className="darzi-tray p-3 my-3 grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-[#6e6e73]">Ordered: </span>
                        <b className="text-[#1d1d1f]">{order.orderDate || '—'}</b>
                      </div>
                      <div>
                        <span className="text-[#6e6e73]">Delivery: </span>
                        <b className="text-[#1d1d1f]">{order.deliveryDate || 'Not set'}</b>
                      </div>
                    </div>

                    {/* Items preview */}
                    <div className="text-xs text-[#6e6e73] mb-3">
                      {order.items.map((it) => `${it.name} (×${it.quantity})`).join(', ')}
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-baseline mb-2">
                      <span className="text-xs text-[#6e6e73]">Due:</span>
                      <span className={`text-[20px] font-semibold tabular-nums ${due > 0 ? 'text-[#c62828]' : 'text-[#1e7b43]'}`}>
                        ৳{due.toLocaleString()}
                      </span>
                    </div>
                    <div className="darzi-bar mb-1">
                      <i style={{ width: `${paidPct}%` }} />
                    </div>
                    <div className="flex justify-between text-[11px] text-[#6e6e73]">
                      <span>Total ৳{total.toLocaleString()}</span>
                      <span>{paidPct}% paid</span>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2 mt-4 pt-3 border-t border-[#f0f0f0]">
                      {due > 0 && order.status === 'Delivered' && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handlePay(order);
                          }}
                          className="darzi-btn darzi-btn-sm flex-1"
                        >
                          Pay
                        </button>
                      )}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onNavigate('edit-officer-order', { orderNumber: order.orderNumber });
                        }}
                        className="darzi-btn darzi-btn-tb darzi-btn-sm flex-1"
                      >
                        Edit
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(order);
                        }}
                        className="darzi-btn darzi-btn-tb darzi-btn-sm text-[#c62828] px-2.5"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* =========================================================================
          MOBILE VARIANT (Exact Loop 1 PDF page 6)
          - Centered huge due number
          - 3 Action cards: New order, Delivery, Search
          - Dark banner: S/L Rashedul Karim is due today
          - Filter chips horizontal scroll
          - Order list with rounded # badges and status dots
         ========================================================================= */}
      <div className="md:hidden">
        {/* Mobile Header Title */}
        <div className="h-14 flex items-center justify-center relative border-b border-[#e8e8ed] bg-[#f5f5f7]">
          <b className="font-semibold text-[17px] text-[#1d1d1f]">Orders</b>
        </div>

        <div className="p-4">
          {/* Centered Large Due Number */}
          <div className="text-center">
            <div className="text-[#6e6e73] text-[15px]">Due after delivery</div>
            <div className="text-[76px] font-semibold tracking-[-0.04em] text-[#1d1d1f] my-1 leading-none tabular-nums">
              <span className="text-[#6e6e73] text-[36px] align-top mr-1 font-normal">৳</span>
              {totalDueAmount.toLocaleString()}
            </div>
            <div className="flex justify-center gap-2 mt-2">
              <span className="darzi-tag bg-[#fce9e9] text-[#c62828]">
                {dueOrders.length} orders
              </span>
              <span className="darzi-tag bg-[rgba(240,86,31,0.1)] text-[#c2410c]">
                {upcomingOrders.length} to deliver in 3 days
              </span>
            </div>
          </div>

          {/* 3 Action Tiles */}
          <div className="flex gap-2.5 mt-5">
            <div
              onClick={() => onNavigate('new-officer-order')}
              className="darzi-pn flex-1 rounded-[32px] py-5 text-center font-semibold text-[15px] cursor-pointer hover:bg-white/90 active:scale-95 transition-transform"
            >
              <div className="grid place-items-center mb-2">
                <Plus className="w-5 h-5 text-[#0066cc]" />
              </div>
              New order
            </div>
            <div
              onClick={() => onNavigate('delivery')}
              className="darzi-pn flex-1 rounded-[32px] py-5 text-center font-semibold text-[15px] cursor-pointer hover:bg-white/90 active:scale-95 transition-transform"
            >
              <div className="grid place-items-center mb-2">
                <Truck className="w-5 h-5 text-[#0066cc]" />
              </div>
              Delivery
            </div>
            <div
              onClick={() => {
                const el = document.getElementById('mobile-search-input');
                el?.focus();
              }}
              className="darzi-pn flex-1 rounded-[32px] py-5 text-center font-semibold text-[15px] cursor-pointer hover:bg-white/90 active:scale-95 transition-transform"
            >
              <div className="grid place-items-center mb-2">
                <Search className="w-5 h-5 text-[#0066cc]" />
              </div>
              Search
            </div>
          </div>

          {/* Dark Graphite Banner: Upcoming Due Notice */}
          {upcomingOrders.length > 0 && (
            <div
              onClick={() => onNavigate('delivery')}
              className="darzi-dark mt-3.5 p-4 rounded-[28px] flex items-center gap-3.5 cursor-pointer"
            >
              <div className="w-11 h-11 rounded-full bg-white/12 flex items-center justify-center shrink-0">
                <Truck className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-[15px] text-white truncate">
                  {upcomingOrders[0].customerName} is due soon
                </div>
                <div className="text-[#ccc] text-xs truncate">
                  Order #{upcomingOrders[0].orderNumber} · {upcomingOrders[0].status}
                </div>
                <div className="text-[#2997ff] text-xs font-semibold mt-1">
                  Open Delivery ›
                </div>
              </div>
            </div>
          )}

          {/* Search Box on mobile */}
          <div className="mt-4">
            <div className="darzi-chip w-full text-[#6e6e73] h-11">
              <Search className="w-4 h-4 text-[#6e6e73] shrink-0" />
              <input
                id="mobile-search-input"
                type="text"
                placeholder="Search name, phone, BD number..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-transparent border-none outline-none text-[13px] text-[#1d1d1f]"
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery('')}>
                  <X className="w-4 h-4 text-[#6e6e73]" />
                </button>
              )}
            </div>
          </div>

          {/* Filter Chips Horizontal Row */}
          <div className="flex gap-2 mt-3 overflow-x-auto no-scrollbar -mr-4 pr-4">
            <button
              onClick={() => setActiveTab('All')}
              className={`darzi-chip shrink-0 ${activeTab === 'All' ? 'darzi-chip-on' : ''}`}
            >
              All <span className="text-[#6e6e73] font-normal">{tabCounts.All}</span>
            </button>
            <button
              onClick={() => setActiveTab('Pending')}
              className={`darzi-chip shrink-0 ${activeTab === 'Pending' ? 'darzi-chip-on' : ''}`}
            >
              Pending <span className="text-[#6e6e73] font-normal">{tabCounts.Pending}</span>
            </button>
            <button
              onClick={() => setActiveTab('Cutting Slip – Done')}
              className={`darzi-chip shrink-0 ${activeTab === 'Cutting Slip – Done' ? 'darzi-chip-on' : ''}`}
            >
              Cutting Slip – Done{' '}
              <span className="text-[#6e6e73] font-normal">{tabCounts['Cutting Slip – Done']}</span>
            </button>
            <button
              onClick={() => setActiveTab('Delivered')}
              className={`darzi-chip shrink-0 ${activeTab === 'Delivered' ? 'darzi-chip-on' : ''}`}
            >
              Delivered <span className="text-[#6e6e73] font-normal">{tabCounts.Delivered}</span>
            </button>
          </div>

          {/* Orders Section Header */}
          <div className="flex justify-between items-center mt-5 mb-2.5 px-1">
            <b className="font-semibold text-[22px] text-[#1d1d1f]">Newest</b>
            <span className="text-[#6e6e73] text-xs">{filteredOrders.length} orders</span>
          </div>

          {/* Mobile Orders List */}
          <div className="darzi-pn p-1 px-4 rounded-[32px]">
            {filteredOrders.map((order) => {
              const due = Number(order.due) || 0;
              return (
                <div
                  key={order.orderNumber}
                  onClick={() =>
                    onNavigate('order-details', {
                      orderNumber: order.orderNumber,
                      category: 'Officer',
                    })
                  }
                  className="flex items-center gap-3.5 py-3.5 px-1 border-b border-[#f0f0f0] last:border-0 cursor-pointer active:bg-black/5"
                >
                  <div className="darzi-ico w-14 h-14 rounded-[18px] text-xs">
                    #{order.orderNumber}
                    <i
                      className={`darzi-dot absolute -right-0.5 -bottom-0.5 border-2 border-white w-3 h-3 ${
                        order.status === 'Pending'
                          ? 'darzi-dot-o'
                          : order.status === 'Cutting Slip – Done'
                          ? 'darzi-dot-p'
                          : 'darzi-dot-g'
                      }`}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-[17px] text-[#1d1d1f] truncate">
                      {order.customerName}
                    </div>
                    <div className="text-[#6e6e73] text-xs truncate">
                      #{order.orderNumber} · Delivery {order.deliveryDate || 'Not set'}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className={`font-semibold text-[17px] tabular-nums ${due > 0 ? 'text-[#c62828]' : 'text-[#1e7b43]'}`}>
                      ৳{due.toLocaleString()}
                    </div>
                    <div className="text-[#6e6e73] text-[13px]">{order.status}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* =========================================================================
          FLOATING GLASS TOAST NOTIFICATION (With Undo)
         ========================================================================= */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 h-[52px] rounded-full darzi-glass flex items-center gap-5 px-6 font-semibold text-sm text-[#1d1d1f] shadow-[0_8px_32px_rgba(0,0,0,0.12)]"
          >
            <span>{toast.message}</span>
            {toast.undoAction && (
              <button
                onClick={toast.undoAction}
                className="text-[#0066cc] hover:underline font-semibold cursor-pointer"
              >
                Undo
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* =========================================================================
          PAY CONFIRMATION DIALOG (Exact Loop 2 Modal)
         ========================================================================= */}
      <AnimatePresence>
        {payTargetOrder && (
          <div className="darzi-scrim flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="darzi-dlg max-w-[360px] w-full"
            >
              <div className="w-10 h-10 rounded-full bg-[#f5f5f7] font-semibold text-[20px] flex items-center justify-center text-[#1d1d1f] mb-3">
                ৳
              </div>
              <div className="font-semibold text-[17px] text-[#1d1d1f] leading-[1.25] my-2">
                Receive ৳{payTargetOrder.due.toLocaleString()} from {payTargetOrder.customerName} for order #{payTargetOrder.orderNumber}?
              </div>
              <div className="text-xs text-[#6e6e73] mb-4">
                Cash received. This clears the whole due.
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setPayTargetOrder(null)}
                  className="darzi-btn darzi-btn-tb flex-1 h-10 text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmPay}
                  className="darzi-btn flex-1 h-10 text-xs"
                >
                  Received
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* =========================================================================
          TWO-STEP DELETE DIALOG (Exact Loop 1 Modal)
         ========================================================================= */}
      <AnimatePresence>
        {deleteTargetOrder && (
          <div className="darzi-scrim flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="darzi-dlg max-w-[360px] w-full"
            >
              <div className="flex justify-between items-center mb-3">
                <div className="w-10 h-10 rounded-full bg-[#fce9e9] text-[#c62828] flex items-center justify-center">
                  <Trash2 className="w-4 h-4" />
                </div>
                <span className="text-[#6e6e73] text-xs">
                  Step {deleteStep} of 2
                </span>
              </div>

              {deleteStep === 1 ? (
                <>
                  <div className="font-semibold text-[17px] text-[#1d1d1f] leading-[1.25] my-2">
                    Delete order #{deleteTargetOrder.orderNumber} for {deleteTargetOrder.customerName}?
                  </div>
                  <div className="text-xs text-[#6e6e73] mb-4">
                    The customer and their other orders stay.
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setDeleteTargetOrder(null)}
                      className="darzi-btn darzi-btn-tb flex-1 h-10 text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={confirmDeleteStep1}
                      className="darzi-btn flex-1 h-10 text-xs"
                    >
                      Continue
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <div className="font-semibold text-[17px] text-[#1d1d1f] leading-[1.25] my-2">
                    This cannot be undone. Delete permanently?
                  </div>
                  <div className="text-xs text-[#6e6e73] mb-4">
                    The order record will be permanently deleted from the database.
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setDeleteTargetOrder(null)}
                      className="darzi-btn darzi-btn-tb flex-1 h-10 text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={confirmDeleteStep2}
                      className="darzi-btn flex-1 h-10 text-xs !bg-[#c62828]"
                    >
                      Delete
                    </button>
                  </div>
                </>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
