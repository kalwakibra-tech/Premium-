import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext.tsx';
import { OfficerOrder } from '../types/index.ts';
import { formatDate } from '../utils/logic.ts';
import {
  Scissors,
  Truck,
  Plus,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Clock,
  ArrowRight,
  TrendingUp,
  X,
  Plane,
  ClipboardList,
  Check,
  ChevronRight,
  Package,
  CircleDollarSign,
  PieChart as PieIcon,
  UserCheck,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';

interface DashboardScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({ onNavigate }) => {
  const { state, recordOfficerPayment } = useApp();

  const [activeBarTooltip, setActiveBarTooltip] = useState<{ month: string; orders: number; revenue: number } | null>(null);
  const [payTargetOrder, setPayTargetOrder] = useState<OfficerOrder | null>(null);
  const [payAmountInput, setPayAmountInput] = useState<string>('');
  const [toastMessage, setToastMessage] = useState<string>('');

  const todayStr = formatDate();
  const upcomingDays = state.settings.upcomingDeliveryDays || 3;

  // Active orders in pipeline (Not yet delivered)
  const activeOfficerOrders = useMemo(() => {
    return state.officerOrders.filter((o) => o.status !== 'Delivered');
  }, [state.officerOrders]);

  const activeAirmanOrders = useMemo(() => {
    return state.airmanOrders.filter((o) => o.status !== 'Delivered');
  }, [state.airmanOrders]);

  const totalActivePipeline = activeOfficerOrders.length + activeAirmanOrders.length;

  // Delivered counts (from reference Screenshot_20261027-110413_6ad4853a.png)
  const deliveredOfficerOrders = useMemo(() => {
    return state.officerOrders.filter((o) => o.status === 'Delivered');
  }, [state.officerOrders]);

  const deliveredAirmanOrders = useMemo(() => {
    return state.airmanOrders.filter((o) => o.status === 'Delivered');
  }, [state.airmanOrders]);

  const totalDeliveredCount = deliveredOfficerOrders.length + deliveredAirmanOrders.length;

  // Pending Cutting Slips
  const cuttingSlipNeededOfficer = useMemo(() => {
    return state.officerOrders.filter((o) => o.status === 'Pending');
  }, [state.officerOrders]);

  // Upcoming deliveries (Next 3 days)
  const upcomingDeliveries = useMemo(() => {
    return state.officerOrders.filter((o) => {
      if (o.status === 'Delivered') return false;
      if (!o.deliveryDate) return false;
      const d = new Date(o.deliveryDate).getTime();
      const t = new Date(todayStr).getTime();
      const diff = Math.round((d - t) / (1000 * 3600 * 24));
      return diff >= 0 && diff <= upcomingDays;
    });
  }, [state.officerOrders, todayStr, upcomingDays]);

  // Total Outstanding Due (safely summed with discount)
  const totalOutstandingDue = useMemo(() => {
    return state.officerOrders.reduce((sum, o) => sum + (Number(o.due) || 0), 0);
  }, [state.officerOrders]);

  const ordersWithDueCount = useMemo(() => {
    return state.officerOrders.filter((o) => (Number(o.due) || 0) > 0).length;
  }, [state.officerOrders]);

  // Total Revenue Billed (Accounting for discounts)
  const totalRevenueBilled = useMemo(() => {
    return state.officerOrders.reduce(
      (sum, o) => sum + Math.max(0, (Number(o.totalAmount) || 0) - (Number(o.discountAmount) || 0)),
      0
    );
  }, [state.officerOrders]);

  // =========================================================================
  // ORDER STATUS DONUT DATA (Inspired by Screenshot_20261027-110416_d3d647ca.png)
  // Segments: Pending (amber), Delivered (green), Due (red)
  // =========================================================================
  const statusDonutData = useMemo(() => {
    const pending = cuttingSlipNeededOfficer.length;
    const delivered = totalDeliveredCount;
    const due = ordersWithDueCount;
    const total = pending + delivered + due;

    if (total === 0) {
      return {
        pendingCount: 0,
        deliveredCount: 0,
        dueCount: 0,
        total: 0,
        pendingPct: 0,
        deliveredPct: 0,
        duePct: 0,
      };
    }

    return {
      pendingCount: pending,
      deliveredCount: delivered,
      dueCount: due,
      total,
      pendingPct: Number(((pending / total) * 100).toFixed(1)),
      deliveredPct: Number(((delivered / total) * 100).toFixed(1)),
      duePct: Number(((due / total) * 100).toFixed(1)),
    };
  }, [cuttingSlipNeededOfficer.length, totalDeliveredCount, ordersWithDueCount]);

  // =========================================================================
  // ORDERS & REVENUE DUAL BAR CHART DATA
  // Aggregated purely from genuine officer orders in state
  // =========================================================================
  const monthlyChartData = useMemo(() => {
    const now = new Date();
    const months: string[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const mStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      months.push(mStr);
    }

    return months.map((m) => {
      let ordersVal = 0;
      let revVal = 0;

      state.officerOrders.forEach((o) => {
        const orderMonth = (o.orderDate || '').slice(0, 7);
        if (orderMonth === m) {
          const net = Math.max(0, (Number(o.totalAmount) || 0) - (Number(o.discountAmount) || 0));
          ordersVal += net;
          if (o.status === 'Delivered') {
            revVal += Math.max(0, net - (Number(o.due) || 0));
          }
        }
      });

      return {
        month: m,
        orders: ordersVal,
        revenue: revVal,
      };
    });
  }, [state.officerOrders]);

  // Recent Orders list (Inspired by Screenshot_20261027-110419_e892b366.png)
  const recentOrders = useMemo(() => {
    return [...state.officerOrders]
      .sort((a, b) => b.orderNumber - a.orderNumber)
      .slice(0, 6);
  }, [state.officerOrders]);

  const handlePaySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payTargetOrder) return;
    const amount = parseFloat(payAmountInput);
    if (isNaN(amount) || amount <= 0) return;

    recordOfficerPayment(payTargetOrder.orderNumber, amount);
    setToastMessage(`Payment of ৳${amount.toLocaleString('en-IN')} recorded for Order #${payTargetOrder.orderNumber}`);
    setPayTargetOrder(null);
    setPayAmountInput('');
    setTimeout(() => setToastMessage(''), 3500);
  };

  return (
    <PolarisPage
      title="Dashboard"
      subtitle="BAF Raymond Tailors workshop velocity, cutting slips & financials"
      primaryAction={{
        label: '+ Officer Order',
        onClick: () => onNavigate('new-officer-order'),
      }}
      secondaryActions={[
        {
          label: '+ Airman Order',
          onClick: () => onNavigate('new-airman-order'),
        },
      ]}
    >
      <div className="space-y-4 pb-16">
        {/* Prominent Operational Quick Actions Bar */}
        <div className="flex flex-wrap items-center gap-2.5 bg-white p-3 rounded-xl border border-[#E3E3E3] shadow-xs">
          <div className="text-xs font-bold text-[#1A1A1A] mr-1 hidden sm:block">
            Quick Actions:
          </div>

          {/* Prominent High-Contrast Upcoming Deliveries Button */}
          <motion.button
            whileHover={{ scale: 1.02, y: -1 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onNavigate('delivery')}
            className="h-9 px-3.5 rounded-lg bg-[#FAFAFA] hover:bg-[#F3F3F3] active:bg-[#EBEBEB] text-[#1A1A1A] border border-[#D8D8D8] font-semibold text-xs shadow-xs inline-flex items-center gap-2 cursor-pointer transition-all"
          >
            <Truck className="w-3.5 h-3.5 text-[#D97706]" />
            <span>Upcoming Deliveries</span>
            <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-[#FFF4E5] text-[#B45309] leading-none border border-[#FDE68A]">
              {upcomingDeliveries.length}
            </span>
          </motion.button>

          {/* Prominent High-Contrast Pending Cutting Slips Button */}
          <motion.button
            whileHover={{ scale: 1.02, y: -1 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onNavigate('orders')}
            className="h-9 px-3.5 rounded-lg bg-[#FAFAFA] hover:bg-[#F3F3F3] active:bg-[#EBEBEB] text-[#1A1A1A] border border-[#D8D8D8] font-semibold text-xs shadow-xs inline-flex items-center gap-2 cursor-pointer transition-all"
          >
            <Scissors className="w-3.5 h-3.5 text-[#2563EB]" />
            <span>Pending Cutting Slips</span>
            <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-[#E8F0FE] text-[#1D4ED8] leading-none border border-[#BFDBFE]">
              {cuttingSlipNeededOfficer.length}
            </span>
          </motion.button>

          {/* Delivery Screen Direct Jump */}
          <motion.button
            whileHover={{ scale: 1.02, y: -1 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onNavigate('delivery')}
            className="h-9 px-3 rounded-lg bg-[#FAFAFA] hover:bg-[#F3F3F3] text-[#616161] hover:text-[#1A1A1A] border border-[#E3E3E3] font-medium text-xs shadow-xs inline-flex items-center gap-1.5 cursor-pointer transition-all ml-auto"
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-[#008060]" />
            <span>Deliveries</span>
          </motion.button>
        </div>
        {/* Toast Notification Banner */}
        <AnimatePresence>
          {toastMessage && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              className="p-3 rounded-xl bg-white border border-[#E3E3E3] text-[#1A1A1A] flex items-center justify-between shadow-sm"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-md bg-[#008060] text-white flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </div>
                <span className="text-xs font-semibold">{toastMessage}</span>
              </div>
              <button
                onClick={() => setToastMessage('')}
                className="p-1 hover:bg-[#F1F1F1] rounded text-[#616161] transition-colors"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* =========================================================================
            METRIC CARDS (Polaris Layout Matching Screenshot_20261027-110413_6ad4853a.png)
           ========================================================================= */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {/* Card 1: Delivered Orders (Green Badge with Checkmark) */}
          <motion.div
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onNavigate('delivery')}
            className="bg-white rounded-xl p-4 border border-[#E3E3E3] shadow-xs hover:border-[#CCCCCC] transition-all cursor-pointer flex flex-col justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#E8F7F0] text-[#008060] flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-5 h-5 stroke-[2.2]" />
              </div>
              <div className="min-w-0">
                <span className="text-xs font-medium text-[#616161] block truncate">
                  Delivered Orders
                </span>
                <div className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] tabular-nums tracking-tight">
                  {totalDeliveredCount}
                </div>
              </div>
            </div>
            <div className="mt-3 pt-2 border-t border-[#F1F1F1] flex items-center justify-between text-[11px] text-[#008060] font-semibold">
              <span>Completed Units</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </motion.div>

          {/* Card 2: Upcoming Deliveries (Amber Badge with Truck) */}
          <motion.div
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onNavigate('delivery')}
            className="bg-white rounded-xl p-4 border border-[#E3E3E3] shadow-xs hover:border-[#CCCCCC] transition-all cursor-pointer flex flex-col justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#FFF4E5] text-[#D97706] flex items-center justify-center shrink-0">
                <Truck className="w-5 h-5 stroke-[2.2]" />
              </div>
              <div className="min-w-0">
                <span className="text-xs font-medium text-[#616161] block truncate">
                  Upcoming Deliveries
                </span>
                <div className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] tabular-nums tracking-tight">
                  {upcomingDeliveries.length}
                </div>
              </div>
            </div>
            <div className="mt-3 pt-2 border-t border-[#F1F1F1] flex items-center justify-between text-[11px] text-[#D97706] font-semibold">
              <span>Next {upcomingDays} Days</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </motion.div>

          {/* Card 3: Pending Cutting Slips (Blue Badge with Scissors) */}
          <motion.div
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onNavigate('orders')}
            className="bg-white rounded-xl p-4 border border-[#E3E3E3] shadow-xs hover:border-[#CCCCCC] transition-all cursor-pointer flex flex-col justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#E8F0FE] text-[#2563EB] flex items-center justify-center shrink-0">
                <Scissors className="w-5 h-5 stroke-[2.2]" />
              </div>
              <div className="min-w-0">
                <span className="text-xs font-medium text-[#616161] block truncate">
                  Pending Cutting
                </span>
                <div className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] tabular-nums tracking-tight">
                  {cuttingSlipNeededOfficer.length}
                </div>
              </div>
            </div>
            <div className="mt-3 pt-2 border-t border-[#F1F1F1] flex items-center justify-between text-[11px] text-[#2563EB] font-semibold">
              <span>Awaiting Pattern Draft</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </motion.div>

          {/* Card 4: Outstanding Due Balance (Red/Rose Badge) */}
          <motion.div
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onNavigate('delivery')}
            className="bg-white rounded-xl p-4 border border-[#E3E3E3] shadow-xs hover:border-[#CCCCCC] transition-all cursor-pointer flex flex-col justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#FEE9E8] text-[#8E0B21] flex items-center justify-center shrink-0">
                <CircleDollarSign className="w-5 h-5 stroke-[2.2]" />
              </div>
              <div className="min-w-0">
                <span className="text-xs font-medium text-[#616161] block truncate">
                  Outstanding Due
                </span>
                <div className="text-xl sm:text-2xl font-extrabold text-[#1A1A1A] tabular-nums tracking-tight truncate">
                  ৳{totalOutstandingDue.toLocaleString('en-IN')}
                </div>
              </div>
            </div>
            <div className="mt-3 pt-2 border-t border-[#F1F1F1] flex items-center justify-between text-[11px] text-[#8E0B21] font-semibold">
              <span>{ordersWithDueCount} Orders Pending</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </motion.div>
        </div>

        {/* =========================================================================
            CHARTS ROW:
            Left: Orders & Revenue Dual Bar Chart (Screenshot_20261027-110413_6ad4853a.png)
            Right: Order Status Donut Chart (Screenshot_20261027-110416_d3d647ca.png)
           ========================================================================= */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Chart 1 (2 cols): Orders & Revenue Dual Bar Chart */}
          <div className="lg:col-span-2 bg-white rounded-xl border border-[#E3E3E3] p-4 sm:p-5 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-[#2563EB]" />
                  <h3 className="text-sm font-bold text-[#1A1A1A] tracking-tight">
                    Orders & Revenue
                  </h3>
                </div>
                <div className="flex items-center gap-3 text-xs font-medium">
                  <span className="flex items-center gap-1.5 text-[#616161]">
                    <span className="w-2.5 h-2.5 rounded-xs bg-[#2563EB] inline-block" />
                    Orders (৳)
                  </span>
                  <span className="flex items-center gap-1.5 text-[#616161]">
                    <span className="w-2.5 h-2.5 rounded-xs bg-[#10B981] inline-block" />
                    Delivered (৳)
                  </span>
                </div>
              </div>

              {/* Interactive SVG Dual-Bar Chart matching Screenshot 3 */}
              <div className="relative w-full h-56 mt-1">
                <svg viewBox="0 0 540 210" className="w-full h-full overflow-visible select-none">
                  {/* Horizontal grid lines & Y-Axis labels */}
                  {[
                    { y: 15, label: '220000' },
                    { y: 60, label: '165000' },
                    { y: 105, label: '110000' },
                    { y: 150, label: '55000' },
                    { y: 195, label: '0' },
                  ].map((grid, idx) => (
                    <g key={idx}>
                      <line
                        x1="65"
                        y1={grid.y}
                        x2="520"
                        y2={grid.y}
                        stroke="#EEEEEE"
                        strokeWidth="1"
                        strokeDasharray={idx < 4 ? '3 3' : 'none'}
                      />
                      <text
                        x="55"
                        y={grid.y + 4}
                        textAnchor="end"
                        fill="#8A8A8A"
                        fontSize="11"
                        fontFamily="ui-sans-serif, system-ui"
                      >
                        {grid.label}
                      </text>
                    </g>
                  ))}

                  {/* Y-Axis vertical solid line */}
                  <line x1="65" y1="15" x2="65" y2="195" stroke="#8A8A8A" strokeWidth="1.2" />

                  {/* Bars per month */}
                  {monthlyChartData.map((d, i) => {
                    const xGroup = 90 + i * 72;
                    const maxVal = 220000;
                    const ordersHeight = d.orders > 0 ? Math.max(6, (d.orders / maxVal) * 180) : 0;
                    const revHeight = d.revenue > 0 ? Math.max(6, (d.revenue / maxVal) * 180) : 0;

                    const ordersY = 195 - ordersHeight;
                    const revY = 195 - revHeight;

                    return (
                      <g key={d.month} className="cursor-pointer group">
                        {/* Hover hit area */}
                        <rect
                          x={xGroup - 14}
                          y="15"
                          width="46"
                          height="180"
                          fill="transparent"
                          className="hover:fill-blue-500/5 transition-colors"
                          onMouseEnter={() => (d.orders > 0 || d.revenue > 0 ? setActiveBarTooltip(d) : null)}
                          onClick={() => (d.orders > 0 || d.revenue > 0 ? setActiveBarTooltip(d) : null)}
                        />

                        {/* Blue Bar (Orders value) */}
                        {ordersHeight > 0 && (
                          <rect
                            x={xGroup - 10}
                            y={ordersY}
                            width="13"
                            height={ordersHeight}
                            rx="3"
                            fill="#2563EB"
                            className="transition-all duration-200 group-hover:fill-[#1D4ED8]"
                          />
                        )}

                        {/* Green Bar (Delivered / Revenue value) */}
                        {revHeight > 0 && (
                          <rect
                            x={xGroup + 7}
                            y={revY}
                            width="13"
                            height={revHeight}
                            rx="3"
                            fill="#10B981"
                            className="transition-all duration-200 group-hover:fill-[#059669]"
                          />
                        )}

                        {/* X-Axis month label */}
                        {i % 2 === 0 && (
                          <text
                            x={xGroup + 5}
                            y="208"
                            textAnchor="middle"
                            fill="#616161"
                            fontSize="10"
                            fontWeight="500"
                          >
                            {d.month}
                          </text>
                        )}
                      </g>
                    );
                  })}
                </svg>

                {/* Empty State Overlay when no orders recorded */}
                {state.officerOrders.length === 0 && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/75 pointer-events-none">
                    <span className="text-xs font-medium text-[#616161]">
                      No order volume recorded yet. Create an order to track velocity.
                    </span>
                  </div>
                )}

                {/* Tooltip on active bar */}
                {activeBarTooltip && (
                  <div className="absolute top-2 right-4 bg-[#1A1A1A] text-white p-2.5 rounded-lg shadow-md text-xs space-y-1 z-20 border border-[#333333]">
                    <div className="font-bold text-[#E3E3E3]">{activeBarTooltip.month}</div>
                    <div className="text-blue-300">Orders: ৳{activeBarTooltip.orders.toLocaleString('en-IN')}</div>
                    <div className="text-emerald-300">Delivered: ৳{activeBarTooltip.revenue.toLocaleString('en-IN')}</div>
                  </div>
                )}
              </div>
            </div>
            <p className="text-[11px] text-[#8A8A8A] mt-2 text-center">
              Monthly Velocity: BAF Order Book vs Completed Garment Delivery
            </p>
          </div>

          {/* Chart 2 (1 col): Order Status Donut Chart (Screenshot_20261027-110416_d3d647ca.png) */}
          <div className="bg-white rounded-xl border border-[#E3E3E3] p-4 sm:p-5 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-bold text-[#1A1A1A] tracking-tight">
                  Order Status
                </h3>
                <PieIcon className="w-4 h-4 text-[#5C5F62]" />
              </div>

              {/* SVG Donut Ring matching Screenshot 4 */}
              <div className="relative w-44 h-44 sm:w-48 sm:h-48 mx-auto my-3 flex items-center justify-center">
                <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90 transform overflow-visible">
                  {(() => {
                    const r = 36;
                    const c = 2 * Math.PI * r;

                    const pDelivered = (statusDonutData.deliveredPct / 100) * c;
                    const pPending = (statusDonutData.pendingPct / 100) * c;
                    const pDue = (statusDonutData.duePct / 100) * c;

                    const offsetDelivered = 0;
                    const offsetPending = -pDelivered;
                    const offsetDue = -(pDelivered + pPending);

                    return (
                      <>
                        {/* Background base track */}
                        <circle
                          cx="50"
                          cy="50"
                          r={r}
                          fill="transparent"
                          stroke="#EBEBEB"
                          strokeWidth="14"
                        />

                        {statusDonutData.total > 0 && (
                          <>
                            {/* Delivered Segment (Green) */}
                            <circle
                              cx="50"
                              cy="50"
                              r={r}
                              fill="transparent"
                              stroke="#10B981"
                              strokeWidth="14"
                              strokeDasharray={`${pDelivered} ${c - pDelivered}`}
                              strokeDashoffset={offsetDelivered}
                              className="transition-all duration-500 ease-out"
                            />

                            {/* Pending Segment (Amber) */}
                            <circle
                              cx="50"
                              cy="50"
                              r={r}
                              fill="transparent"
                              stroke="#F59E0B"
                              strokeWidth="14"
                              strokeDasharray={`${pPending} ${c - pPending}`}
                              strokeDashoffset={offsetPending}
                              className="transition-all duration-500 ease-out"
                            />

                            {/* Due Segment (Red) */}
                            <circle
                              cx="50"
                              cy="50"
                              r={r}
                              fill="transparent"
                              stroke="#EF4444"
                              strokeWidth="14"
                              strokeDasharray={`${pDue} ${c - pDue}`}
                              strokeDashoffset={offsetDue}
                              className="transition-all duration-500 ease-out"
                            />
                          </>
                        )}
                      </>
                    );
                  })()}
                </svg>

                {/* Center Donut Hole Text */}
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
                  <span className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] leading-none">
                    {statusDonutData.total}
                  </span>
                  <span className="text-[10px] font-semibold text-[#616161] uppercase tracking-wider mt-1">
                    Total Tracked
                  </span>
                </div>
              </div>

              {/* Donut Legend (Matching Screenshot 4: ■ Pending ■ Delivered ■ Due) */}
              <div className="flex items-center justify-center gap-4 text-xs font-medium pt-2 border-t border-[#F1F1F1]">
                <span className="flex items-center gap-1.5 text-[#303030]">
                  <span className="w-3 h-3 rounded-xs bg-[#F59E0B] inline-block shrink-0" />
                  <span>Pending</span>
                </span>
                <span className="flex items-center gap-1.5 text-[#303030]">
                  <span className="w-3 h-3 rounded-xs bg-[#10B981] inline-block shrink-0" />
                  <span>Delivered</span>
                </span>
                <span className="flex items-center gap-1.5 text-[#303030]">
                  <span className="w-3 h-3 rounded-xs bg-[#EF4444] inline-block shrink-0" />
                  <span>Due</span>
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* =========================================================================
            RECENT ORDERS TABLE (Matching Screenshot_20261027-110419_e892b366.png)
           ========================================================================= */}
        <div className="bg-white rounded-xl border border-[#E3E3E3] p-4 sm:p-5 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-[#F1F1F1]">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#2563EB]" />
              <h3 className="text-sm font-bold text-[#1A1A1A] tracking-tight">
                Recent Orders
              </h3>
            </div>
            <button
              onClick={() => onNavigate('orders')}
              className="text-xs font-semibold text-[#005BD3] hover:underline inline-flex items-center gap-1 cursor-pointer"
            >
              <span>View All</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Clean Responsive Table matching Screenshot 5 */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse mt-1">
              <thead>
                <tr className="border-b border-[#F1F1F1] text-xs font-semibold text-[#8A8A8A]">
                  <th className="py-2.5 px-3">#</th>
                  <th className="py-2.5 px-3">BD Number</th>
                  <th className="py-2.5 px-3">Order Date</th>
                  <th className="py-2.5 px-3 text-right">Tot Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F1F1F1] text-xs sm:text-sm">
                {recentOrders.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-xs text-[#616161]">
                      No uniform orders recorded yet. Click &quot;+ Officer Order&quot; above to create your first order.
                    </td>
                  </tr>
                ) : (
                  recentOrders.map((order) => (
                    <tr
                      key={order.id}
                      onClick={() => onNavigate('order-details', { orderNumber: order.orderNumber, category: 'Officer' })}
                      className="hover:bg-[#F9F9F9] transition-colors cursor-pointer group"
                    >
                      <td className="py-3 px-3 font-bold text-[#1A1A1A]">
                        #{order.orderNumber}
                      </td>
                      <td className="py-3 px-3 font-medium text-[#303030]">
                        <span className="font-mono">{order.customerBdNumber || '—'}</span>
                        {order.branch && (
                          <span className="ml-2 text-[10px] font-semibold px-1.5 py-0.5 rounded bg-[#F1F1F1] text-[#303030]">
                            {order.branch}
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-[#616161] font-mono text-xs">
                        {order.orderDate}
                      </td>
                      <td className="py-3 px-3 text-right font-bold text-[#1A1A1A] tabular-nums">
                        ৳{order.totalAmount?.toLocaleString('en-IN') || 0}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* =========================================================================
            GROUPED WORKSHOP ROSTER
           ========================================================================= */}
        <div className="bg-white rounded-xl border border-[#E3E3E3] p-4 sm:p-5 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-[#F1F1F1] mb-3">
            <div className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-[#5C5F62]" />
              <h3 className="text-sm font-bold text-[#1A1A1A]">
                Workshop Staff & Master Tailors
              </h3>
            </div>
            <button
              onClick={() => onNavigate('staff-management')}
              className="text-xs font-semibold text-[#005BD3] hover:underline cursor-pointer"
            >
              Manage Roster
            </button>
          </div>

          <div className="bg-[#FAFAFA] rounded-xl border border-[#E3E3E3] overflow-hidden divide-y divide-[#E3E3E3]">
            {state.workers.length === 0 ? (
              <div className="p-4 text-center text-xs text-[#616161]">
                No staff members registered. Click Manage Roster to add master tailors.
              </div>
            ) : (
              state.workers.slice(0, 4).map((w) => {
                const workerRowItems = state.workerRows.filter((r) => r.workerId === w.id);
                const itemsCount = workerRowItems.reduce((sum, r) => sum + (r.quantity || 0), 0);
                const totalWages = workerRowItems.reduce((sum, r) => sum + (r.totalTaka || 0), 0);

                return (
                  <motion.div
                    key={w.id}
                    whileTap={{ scale: 0.99 }}
                    onClick={() => onNavigate('worker-page', { workerId: w.id })}
                    className="p-3 sm:p-3.5 flex items-center justify-between hover:bg-[#F3F3F3] transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-[#1A1A1A] text-white font-bold text-xs flex items-center justify-center shadow-xs">
                        {w.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="text-xs sm:text-sm font-semibold text-[#1A1A1A]">{w.name}</div>
                        <div className="text-[11px] text-[#616161]">
                          {w.banglaName ? `${w.banglaName} · ` : ''}{itemsCount} items completed
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <span className="text-xs sm:text-sm font-bold text-[#1A1A1A] tabular-nums block">
                          ৳{totalWages.toLocaleString('en-IN')}
                        </span>
                        <span className="text-[10px] text-[#8A8A8A] uppercase">Earned</span>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-[#8A8A8A]" />
                    </div>
                  </motion.div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </PolarisPage>
  );
};
