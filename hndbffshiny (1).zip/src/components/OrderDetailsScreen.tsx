import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext.tsx';
import { OrderStatus } from '../types/index.ts';
import {
  Scissors,
  Printer,
  Edit2,
  Trash2,
  ArrowLeft,
  ChevronDown,
  X,
  Check,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface OrderDetailsScreenProps {
  orderNumber: number;
  category: 'Officer' | 'Airman';
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const OrderDetailsScreen: React.FC<OrderDetailsScreenProps> = ({
  orderNumber,
  category,
  onNavigate,
}) => {
  const {
    state,
    updateOfficerOrderStatus,
    updateAirmanOrderStatus,
    deleteOfficerOrder,
    deleteAirmanOrder,
    recordOfficerPayment,
  } = useApp();

  const isOfficer = category === 'Officer';
  const officerOrder = isOfficer ? state.officerOrders.find((o) => o.orderNumber === orderNumber) : null;
  const airmanOrder = !isOfficer ? state.airmanOrders.find((o) => o.orderNumber === orderNumber) : null;

  const order = isOfficer ? officerOrder : airmanOrder;

  // Pay Modal State
  const [payModalOpen, setPayModalOpen] = useState(false);

  // Status dropdown
  const [statusMenuOpen, setStatusMenuOpen] = useState(false);

  // Delete 2-step dialog
  const [deleteStep, setDeleteStep] = useState<0 | 1 | 2>(0);

  // Toast
  const [toastMessage, setToastMessage] = useState('');

  if (!order) {
    return (
      <div className="w-full max-w-[1280px] mx-auto py-12 px-4 text-center">
        <div className="darzi-pn p-8 max-w-md mx-auto">
          <div className="darzi-ico mx-auto mb-3 text-sm">#{orderNumber}</div>
          <h2 className="font-semibold text-lg text-[#1d1d1f] mb-1">Order Not Found</h2>
          <p className="text-xs text-[#6e6e73] mb-4">
            Order #{orderNumber} does not exist or was deleted.
          </p>
          <button
            onClick={() => onNavigate(isOfficer ? 'orders' : 'airman-orders')}
            className="darzi-btn darzi-btn-sm"
          >
            Back to Orders
          </button>
        </div>
      </div>
    );
  }

  const handleStatusChange = (newStatus: OrderStatus) => {
    if (isOfficer) {
      updateOfficerOrderStatus(orderNumber, newStatus);
    } else {
      updateAirmanOrderStatus(orderNumber, newStatus);
    }
    setStatusMenuOpen(false);
    setToastMessage(`Status updated to ${newStatus}`);
    setTimeout(() => setToastMessage(''), 3000);
  };

  const handleConfirmPay = () => {
    if (isOfficer && officerOrder) {
      recordOfficerPayment(orderNumber, officerOrder.due);
      setPayModalOpen(false);
      setToastMessage(`Payment of ৳${officerOrder.due.toLocaleString()} recorded`);
      setTimeout(() => setToastMessage(''), 3000);
    }
  };

  const handleConfirmDelete = () => {
    if (isOfficer) {
      deleteOfficerOrder(orderNumber);
      onNavigate('orders');
    } else {
      deleteAirmanOrder(orderNumber);
      onNavigate('airman-orders');
    }
  };

  const total = isOfficer && officerOrder ? Number(officerOrder.totalAmount) || 0 : 0;
  const advance = isOfficer && officerOrder ? Number(officerOrder.advance) || 0 : 0;
  const due = isOfficer && officerOrder ? Number(officerOrder.due) || 0 : 0;
  const discountAmt = isOfficer && officerOrder ? (officerOrder.discountAmount || 0) : 0;
  const payments = isOfficer && officerOrder ? (officerOrder.payments || []) : [];
  const receivedLater = payments.reduce((sum: number, p: any) => sum + (Number(p.amount) || 0), 0);
  const totalReceived = advance + receivedLater;
  const paidPct = total > 0 ? Math.min(100, Math.round((totalReceived / total) * 100)) : 100;
  const deliveryDateDisplay = isOfficer && officerOrder ? officerOrder.deliveryDate : (order as any).deliveryDate || (order as any).deliveredDate || 'Not set';

  return (
    <div className="w-full max-w-[1280px] mx-auto pb-24 font-sans">
      {/* Back Link */}
      <div className="pt-2 pb-3">
        <button
          onClick={() => onNavigate(isOfficer ? 'orders' : 'airman-orders')}
          className="inline-flex items-center gap-1.5 text-[#0066cc] font-semibold text-sm hover:underline cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Orders
        </button>
      </div>

      {/* =========================================================================
          DESKTOP DETAILS (Exact Loop 2 layout)
         ========================================================================= */}
      <div className="hidden md:grid grid-cols-[1fr_360px] gap-5 items-start">
        {/* Left Column */}
        <div className="grid gap-5">
          {/* Header Card with Bespoke Graphic */}
          <div className="darzi-pn flex gap-6 items-center">
            {/* Bespoke Tailor Tag Graphic */}
            <div className="w-[122px] h-[122px] rounded-[20px] bg-[#f5f5f7] flex items-center justify-center shrink-0">
              <div className="w-11 h-[62px] rounded-[8px] bg-[#1d1d1f] rotate-[8deg] relative shadow-xs">
                <i className="absolute top-2 left-4 w-2 h-2 rounded-full bg-white block" />
                <i className="absolute bottom-3 left-2 right-2 h-[3px] bg-[#f0561f] block" />
              </div>
            </div>

            <div className="min-w-0 flex-1">
              <div className="text-xs text-[#6e6e73]">Order #{order.orderNumber}</div>
              <h1 className="text-[34px] font-semibold tracking-[-0.03em] text-[#1d1d1f] my-1 truncate">
                {order.customerName}
              </h1>

              {/* Status & Tag strip */}
              <div className="flex gap-2.5 items-center flex-wrap my-2">
                <span className="darzi-tag bg-[#1d1d1f] text-white">
                  {category}
                </span>

                {/* Status Dropdown */}
                <div className="relative">
                  <button
                    onClick={() => setStatusMenuOpen(!statusMenuOpen)}
                    className="darzi-st cursor-pointer"
                  >
                    <i
                      className={`darzi-dot ${
                        order.status === 'Pending'
                          ? 'darzi-dot-o'
                          : order.status === 'Cutting Slip – Done'
                          ? 'darzi-dot-p'
                          : 'darzi-dot-g'
                      }`}
                    />
                    <span>{order.status}</span>
                    <ChevronDown className="w-3 h-3 text-[#6e6e73]" />
                  </button>

                  {statusMenuOpen && (
                    <div className="absolute top-10 left-0 z-30 bg-white rounded-[16px] p-1.5 shadow-[0_8px_32px_rgba(0,0,0,0.12)] border border-[#e0e0e0] w-[190px]">
                      {(['Pending', 'Cutting Slip – Done', 'Delivered'] as OrderStatus[]).map((st) => (
                        <button
                          key={st}
                          onClick={() => handleStatusChange(st)}
                          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-[10px] font-semibold text-xs text-left cursor-pointer transition-colors ${
                            order.status === st ? 'bg-[#f5f5f7] text-[#1d1d1f]' : 'text-[#6e6e73] hover:bg-[#f5f5f7]'
                          }`}
                        >
                          <i
                            className={`darzi-dot ${
                              st === 'Pending'
                                ? 'darzi-dot-o'
                                : st === 'Cutting Slip – Done'
                                ? 'darzi-dot-p'
                                : 'darzi-dot-g'
                            }`}
                          />
                          <span>{st}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <span className="text-xs text-[#6e6e73]">{order.customerBdNumber}</span>
              </div>

              {/* Action buttons */}
              <div className="flex gap-2.5 mt-4">
                <button
                  onClick={() =>
                    onNavigate(isOfficer ? 'edit-officer-order' : 'edit-airman-order', {
                      orderNumber: order.orderNumber,
                    })
                  }
                  className="darzi-btn darzi-btn-sm"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  Edit order
                </button>

                <button
                  onClick={() =>
                    onNavigate('print-slip', {
                      orderNumber: order.orderNumber,
                      category,
                    })
                  }
                  className="darzi-btn darzi-btn-tb darzi-btn-sm"
                >
                  <Scissors className="w-3.5 h-3.5" />
                  Cutting slip
                </button>

                {isOfficer && (
                  <button
                    onClick={() =>
                      onNavigate('print-invoice', {
                        orderNumber: order.orderNumber,
                        category: 'Officer',
                      })
                    }
                    className="darzi-btn darzi-btn-tb darzi-btn-sm"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    Invoice
                  </button>
                )}

                <button
                  onClick={() => setDeleteStep(1)}
                  className="w-8 h-8 rounded-full bg-[#f5f5f7] hover:bg-[#fce9e9] text-[#c62828] flex items-center justify-center transition-colors cursor-pointer"
                  title="Delete order"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Customer & Order Metadata Trays */}
          <div className="darzi-pn grid grid-cols-2 gap-3">
            <div className="darzi-tray p-4">
              <div className="font-semibold text-xs text-[#1d1d1f] mb-2.5">Customer</div>
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <div className="text-[11px] text-[#6e6e73]">Name</div>
                  <div className="font-semibold text-xs text-[#1d1d1f] truncate">{order.customerName}</div>
                </div>
                <div>
                  <div className="text-[11px] text-[#6e6e73]">Phone</div>
                  <div className="font-semibold text-xs text-[#1d1d1f]">
                    {order.customerPhone || 'Not added'}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-[#6e6e73]">BD Number</div>
                  <div className="font-semibold text-xs text-[#1d1d1f]">{order.customerBdNumber}</div>
                </div>
              </div>
            </div>

            <div className="darzi-tray p-4">
              <div className="font-semibold text-xs text-[#1d1d1f] mb-2.5">Order</div>
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <div className="text-[11px] text-[#6e6e73]">Order Date</div>
                  <div className="font-semibold text-xs text-[#1d1d1f]">{order.orderDate || '—'}</div>
                </div>
                <div>
                  <div className="text-[11px] text-[#6e6e73]">Delivery Date</div>
                  <div className="font-semibold text-xs text-[#1d1d1f]">{deliveryDateDisplay}</div>
                </div>
                <div>
                  <div className="text-[11px] text-[#6e6e73]">Delivered on</div>
                  <div className={`font-semibold text-xs ${order.status === 'Delivered' ? 'text-[#1e7b43]' : 'text-[#6e6e73]'}`}>
                    {order.status === 'Delivered' ? (order as any).deliveryDate || (order as any).deliveredDate || 'Completed' : 'Pending'}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-[#6e6e73]">Ribbon</div>
                  <div className="font-semibold text-xs text-[#1d1d1f]">{(order as any).ribbon || '0'}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Items Table */}
          <div className="darzi-pn">
            <div className="font-semibold text-[21px] text-[#1d1d1f] mb-3">Items</div>
            <div className="grid grid-cols-[1fr_60px_100px_110px] items-center px-4 h-10 bg-[#f5f5f7] rounded-[12px] text-xs font-semibold text-[#333] mb-1">
              <div>Item</div>
              <div>Qty</div>
              <div>Price</div>
              <div className="text-right">Line total</div>
            </div>
            <div className="divide-y divide-[#f0f0f0]">
              {order.items.map((item: any) => (
                <div
                  key={item.id}
                  className="grid grid-cols-[1fr_60px_100px_110px] items-center px-4 h-[52px] text-xs"
                >
                  <div className="font-semibold text-[#1d1d1f]">{item.name}</div>
                  <div className="text-[#6e6e73]">{item.quantity}</div>
                  <div className="text-[#6e6e73]">
                    {typeof item.price === 'number' ? `৳${item.price.toLocaleString()}` : item.ivNumber || '—'}
                  </div>
                  <div className="font-semibold text-[#1d1d1f] text-right tabular-nums">
                    {typeof item.lineTotal === 'number' ? `৳${item.lineTotal.toLocaleString()}` : '—'}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Payments Table */}
          <div className="darzi-pn">
            <div className="font-semibold text-[21px] text-[#1d1d1f] mb-3">Payments</div>
            <div className="grid grid-cols-[1fr_140px_110px] items-center px-4 h-10 bg-[#f5f5f7] rounded-[12px] text-xs font-semibold text-[#333] mb-1">
              <div>Payment</div>
              <div>Date</div>
              <div className="text-right">Amount</div>
            </div>
            <div className="divide-y divide-[#f0f0f0]">
              <div className="grid grid-cols-[1fr_140px_110px] items-center px-4 h-[52px] text-xs">
                <div className="font-semibold text-[#1d1d1f]">Advance</div>
                <div className="text-[#6e6e73]">{order.orderDate || '—'}</div>
                <div className="font-semibold text-[#1d1d1f] text-right tabular-nums">
                  ৳{advance.toLocaleString()}
                </div>
              </div>
              {payments.map((p: any, idx: number) => (
                <div
                  key={idx}
                  className="grid grid-cols-[1fr_140px_110px] items-center px-4 h-[52px] text-xs"
                >
                  <div className="font-semibold text-[#1d1d1f]">Payment #{idx + 1}</div>
                  <div className="text-[#6e6e73]">{p.date || '—'}</div>
                  <div className="font-semibold text-[#1d1d1f] text-right tabular-nums">
                    ৳{(Number(p.amount) || 0).toLocaleString()}
                  </div>
                </div>
              ))}
              <div className="grid grid-cols-[1fr_140px_110px] items-center px-4 h-[52px] text-xs font-semibold">
                <div className="text-[#1d1d1f]">Total received</div>
                <div />
                <div className="text-[#1d1d1f] text-right tabular-nums">
                  ৳{totalReceived.toLocaleString()}
                </div>
              </div>
            </div>
          </div>

          {/* Measurements and Notes */}
          <div className="darzi-pn">
            <div className="font-semibold text-[21px] text-[#1d1d1f] mb-3">Measurements and notes</div>
            <div className="grid grid-cols-2 gap-3">
              {/* Shirt */}
              <div className="darzi-tray p-4">
                <div className="font-semibold text-xs text-[#1d1d1f] mb-2.5">Shirt</div>
                <div className="grid grid-cols-3 gap-2.5">
                  {Object.entries((order as any).shirtMeasurements || {}).slice(0, 6).map(([k, v]) => (
                    <div key={k}>
                      <div className="text-[11px] text-[#6e6e73] capitalize">{k}</div>
                      <div className="font-semibold text-xs text-[#1d1d1f]">{String(v || '—')}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Pant */}
              <div className="darzi-tray p-4">
                <div className="font-semibold text-xs text-[#1d1d1f] mb-2.5">Pant</div>
                <div className="grid grid-cols-3 gap-2.5">
                  {Object.entries((order as any).pantMeasurements || {}).slice(0, 6).map(([k, v]) => (
                    <div key={k}>
                      <div className="text-[11px] text-[#6e6e73] capitalize">{k}</div>
                      <div className="font-semibold text-xs text-[#1d1d1f]">{String(v || '—')}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Payment & Due Card */}
        <div className="darzi-pn sticky top-20">
          <div className="flex justify-between items-center">
            <span className="text-xs text-[#6e6e73] font-medium">Due</span>
            <span
              className={`darzi-tag ${
                order.status === 'Delivered'
                  ? 'bg-[#e3f4e8] text-[#1e7b43]'
                  : 'bg-[rgba(240,86,31,0.1)] text-[#c2410c]'
              }`}
            >
              {order.status}
            </span>
          </div>

          <div
            className={`text-[64px] font-semibold tracking-[-0.04em] my-3 leading-none tabular-nums ${
              due > 0 ? 'text-[#c62828]' : 'text-[#1e7b43]'
            }`}
          >
            ৳{due.toLocaleString()}
          </div>

          <div className="darzi-bar">
            <i style={{ width: `${paidPct}%` }} />
          </div>
          <div className="text-xs text-[#6e6e73] my-2 mb-4 tabular-nums">
            {paidPct}% paid
          </div>

          <div className="darzi-tray p-3.5 space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-[#6e6e73]">Total</span>
              <b className="font-semibold text-[#1d1d1f] tabular-nums">৳{total.toLocaleString()}</b>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6e6e73]">Discount</span>
              <b className="font-semibold text-[#1d1d1f] tabular-nums">৳{discountAmt.toLocaleString()}</b>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6e6e73]">Advance</span>
              <b className="font-semibold text-[#1d1d1f] tabular-nums">৳{advance.toLocaleString()}</b>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6e6e73]">Received later</span>
              <b className="font-semibold text-[#1d1d1f] tabular-nums">৳{receivedLater.toLocaleString()}</b>
            </div>
          </div>

          {due > 0 && isOfficer && (
            <button
              onClick={() => setPayModalOpen(true)}
              className="darzi-btn w-full mt-4"
            >
              Pay ৳{due.toLocaleString()}
            </button>
          )}
        </div>
      </div>

      {/* =========================================================================
          MOBILE DETAILS (Exact Loop 2 Mobile layout - HTML lines 9-12)
         ========================================================================= */}
      <div className="md:hidden">
        {/* Mobile Header Bar */}
        <div className="h-14 flex items-center justify-center relative border-b border-[#e8e8ed] bg-[#f5f5f7]">
          <button
            onClick={() => onNavigate(isOfficer ? 'orders' : 'airman-orders')}
            className="absolute left-4 w-9 h-9 rounded-full darzi-glass flex items-center justify-center text-[#1d1d1f]"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <b className="font-semibold text-[17px] text-[#1d1d1f]">
            Order #{order.orderNumber}
          </b>
        </div>

        <div className="p-4 text-center">
          <div className="text-xs text-[#6e6e73]">Due</div>
          <div className="text-[72px] font-semibold tracking-[-0.04em] text-[#c62828] my-1 leading-none tabular-nums">
            <span className="text-[36px] align-top opacity-80 font-normal">৳</span>
            {due.toLocaleString()}
          </div>
          <div className="flex justify-center gap-2 mt-2">
            <span className="darzi-tag bg-[#e3f4e8] text-[#1e7b43]">
              {paidPct}% paid
            </span>
            <span className="darzi-tag bg-[rgba(240,86,31,0.1)] text-[#c2410c]">
              {order.status}
            </span>
          </div>

          {/* Dark Card with Customer & Status */}
          <div className="darzi-dark mt-4 p-5 text-left rounded-[28px] relative overflow-hidden">
            <span className="darzi-st bg-white/15 text-white">
              <i
                className={`darzi-dot ${
                  order.status === 'Pending'
                    ? 'darzi-dot-o'
                    : order.status === 'Cutting Slip – Done'
                    ? 'darzi-dot-p'
                    : 'darzi-dot-g'
                }`}
              />
              {order.status}
            </span>

            <div className="mt-4">
              <div className="text-[#ccc] text-xs">Officer · {order.customerBdNumber}</div>
              <div className="text-[24px] font-semibold text-white leading-tight mt-1">
                {order.customerName}
              </div>
            </div>

            {/* Circular Percentage Badge */}
            <div className="absolute right-5 top-12 w-14 h-14 rounded-full border-4 border-white flex items-center justify-center text-xs font-semibold text-white">
              {paidPct}%
            </div>

            {/* Measurement tick marks graphic */}
            <div className="flex gap-1.5 mt-6 pt-2 border-t border-white/10 opacity-60">
              {Array.from({ length: 16 }).map((_, i) => (
                <i key={i} className="flex-1 h-2 border-l border-white/40 block" />
              ))}
            </div>
          </div>

          {/* Items & Payments Details Accordion/Panel */}
          <div className="darzi-pn mt-4 rounded-[32px] p-4 text-left">
            <div className="flex justify-between items-baseline pb-2 border-b border-[#f0f0f0]">
              <b className="font-semibold text-base text-[#1d1d1f]">Items</b>
              <span className="text-xs text-[#6e6e73]">Total ৳{total.toLocaleString()}</span>
            </div>
            <div className="divide-y divide-[#f0f0f0]">
              {order.items.map((it: any) => (
                <div key={it.id} className="py-2.5 flex justify-between text-xs">
                  <div>
                    <div className="font-semibold text-[#1d1d1f]">{it.name}</div>
                    <div className="text-[#6e6e73]">
                      {it.quantity} {typeof it.price === 'number' ? `× ৳${it.price}` : ''}
                    </div>
                  </div>
                  <b className="font-semibold text-[#1d1d1f]">
                    {typeof it.lineTotal === 'number' ? `৳${it.lineTotal.toLocaleString()}` : it.ivNumber || '—'}
                  </b>
                </div>
              ))}
            </div>

            <div className="flex justify-between items-baseline pt-4 pb-2 border-b border-[#f0f0f0]">
              <b className="font-semibold text-base text-[#1d1d1f]">Payments</b>
              <span className="text-xs text-[#6e6e73]">Cash</span>
            </div>
            <div className="py-2.5 flex justify-between text-xs border-b border-[#f0f0f0]">
              <div>
                <div className="font-semibold text-[#1d1d1f]">Advance</div>
                <div className="text-[#6e6e73]">{order.orderDate}</div>
              </div>
              <b className="font-semibold text-[#1d1d1f]">৳{advance}</b>
            </div>
            <div className="py-2.5 flex justify-between text-xs font-semibold">
              <span>Total received</span>
              <span>৳{totalReceived}</span>
            </div>
          </div>

          {/* Sticky Mobile Action Dock */}
          <div className="fixed left-3 right-3 bottom-4 z-40 darzi-glass rounded-full p-2 h-[68px] flex items-center gap-2 shadow-[0_8px_32px_rgba(0,0,0,0.15)]">
            <button
              onClick={() => setDeleteStep(1)}
              className="w-12 h-12 rounded-full bg-white text-[#c62828] flex items-center justify-center shrink-0 shadow-xs"
              title="Delete"
            >
              <Trash2 className="w-5 h-5" />
            </button>
            <button
              onClick={() =>
                onNavigate(isOfficer ? 'edit-officer-order' : 'edit-airman-order', {
                  orderNumber: order.orderNumber,
                })
              }
              className="w-12 h-12 rounded-full bg-white text-[#1d1d1f] flex items-center justify-center shrink-0 shadow-xs"
              title="Edit"
            >
              <Edit2 className="w-5 h-5" />
            </button>
            {due > 0 && isOfficer ? (
              <button
                onClick={() => setPayModalOpen(true)}
                className="darzi-btn flex-1 h-12 text-sm"
              >
                Pay ৳{due.toLocaleString()}
              </button>
            ) : (
              <button
                onClick={() =>
                  onNavigate('print-slip', {
                    orderNumber: order.orderNumber,
                    category,
                  })
                }
                className="darzi-btn flex-1 h-12 text-sm"
              >
                Cutting slip
              </button>
            )}
          </div>
        </div>
      </div>

      {/* =========================================================================
          PAY CONFIRMATION DIALOG (Loop 2)
         ========================================================================= */}
      <AnimatePresence>
        {payModalOpen && (
          <div className="darzi-scrim flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="darzi-dlg max-w-[360px] w-full"
            >
              <div className="w-10 h-10 rounded-full bg-[#f5f5f7] font-semibold text-[20px] flex items-center justify-center text-[#1d1d1f] mb-3">
                ৳
              </div>
              <div className="font-semibold text-[17px] text-[#1d1d1f] leading-[1.25] my-2">
                Receive ৳{due.toLocaleString()} from {order.customerName} for order #{order.orderNumber}?
              </div>
              <div className="text-xs text-[#6e6e73] mb-4">
                Cash received. This clears the whole due.
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setPayModalOpen(false)}
                  className="darzi-btn darzi-btn-tb flex-1 h-10 text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmPay}
                  className="darzi-btn flex-1 h-10 text-xs"
                >
                  Received
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* =========================================================================
          TWO-STEP DELETE DIALOG
         ========================================================================= */}
      <AnimatePresence>
        {deleteStep > 0 && (
          <div className="darzi-scrim flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="darzi-dlg max-w-[360px] w-full"
            >
              <div className="flex justify-between items-center mb-3">
                <div className="w-10 h-10 rounded-full bg-[#fce9e9] text-[#c62828] flex items-center justify-center">
                  <Trash2 className="w-4 h-4" />
                </div>
                <span className="text-[#6e6e73] text-xs">
                  Step {deleteStep} of 2
                </span>
              </div>

              {deleteStep === 1 ? (
                <>
                  <div className="font-semibold text-[17px] text-[#1d1d1f] leading-[1.25] my-2">
                    Delete order #{order.orderNumber} for {order.customerName}?
                  </div>
                  <div className="text-xs text-[#6e6e73] mb-4">
                    The customer and their other orders stay.
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setDeleteStep(0)}
                      className="darzi-btn darzi-btn-tb flex-1 h-10 text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => setDeleteStep(2)}
                      className="darzi-btn flex-1 h-10 text-xs"
                    >
                      Continue
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <div className="font-semibold text-[17px] text-[#1d1d1f] leading-[1.25] my-2">
                    This cannot be undone. Delete permanently?
                  </div>
                  <div className="text-xs text-[#6e6e73] mb-4">
                    The order record will be permanently deleted from the database.
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setDeleteStep(0)}
                      className="darzi-btn darzi-btn-tb flex-1 h-10 text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleConfirmDelete}
                      className="darzi-btn flex-1 h-10 text-xs !bg-[#c62828]"
                    >
                      Delete
                    </button>
                  </div>
                </>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
