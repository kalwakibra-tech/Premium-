import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { Customer } from '../types/index.ts';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { PolarisTabs } from './polaris/PolarisTabs.tsx';
import {
  Plus,
  Search,
  History,
  Edit2,
  Trash2,
  X,
  AlertTriangle,
  AlertCircle,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface CustomersScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const CustomersScreen: React.FC<CustomersScreenProps> = ({ onNavigate }) => {
  const { state, addCustomer, updateCustomer, deleteCustomer } = useApp();

  const [activeTab, setActiveTab] = useState<'Officer' | 'Airman'>('Officer');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'newest' | 'name' | 'mostDue'>('newest');

  // Modals
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [newBdNumber, setNewBdNumber] = useState('');
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [modalError, setModalError] = useState('');

  const [editTarget, setEditTarget] = useState<Customer | null>(null);
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');

  const [deleteTarget, setDeleteTarget] = useState<Customer | null>(null);
  const [deleteBlockedMessage, setDeleteBlockedMessage] = useState('');

  // Calculate statistics per customer
  const customerStats = useMemo(() => {
    const stats: Record<string, { ordersCount: number; spent: number; due: number }> = {};

    for (const c of state.customers) {
      const key = `${c.category}-${c.bdNumber.trim().toUpperCase()}`;
      stats[key] = { ordersCount: 0, spent: 0, due: 0 };
    }

    // Officer orders
    for (const o of state.officerOrders) {
      const key = `Officer-${o.customerBdNumber.trim().toUpperCase()}`;
      if (!stats[key]) stats[key] = { ordersCount: 0, spent: 0, due: 0 };
      stats[key].ordersCount += 1;
      const spent = (Number(o.totalAmount) || 0) - (Number(o.discountAmount) || 0);
      stats[key].spent += spent;
      stats[key].due += Number(o.due) || 0;
    }

    // Airman orders
    for (const o of state.airmanOrders) {
      const key = `Airman-${o.customerBdNumber.trim().toUpperCase()}`;
      if (!stats[key]) stats[key] = { ordersCount: 0, spent: 0, due: 0 };
      stats[key].ordersCount += 1;
    }

    return stats;
  }, [state.customers, state.officerOrders, state.airmanOrders]);

  // Filtered and sorted customers
  const filteredCustomers = useMemo(() => {
    return state.customers
      .filter((c) => c.category === activeTab)
      .filter((c) => {
        if (!searchQuery.trim()) return true;
        const q = searchQuery.toLowerCase().trim();
        return (
          c.name.toLowerCase().includes(q) ||
          c.bdNumber.toLowerCase().includes(q) ||
          (c.phone || '').toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        const keyA = `${a.category}-${a.bdNumber.trim().toUpperCase()}`;
        const keyB = `${b.category}-${b.bdNumber.trim().toUpperCase()}`;
        const stA = customerStats[keyA] || { ordersCount: 0, spent: 0, due: 0 };
        const stB = customerStats[keyB] || { ordersCount: 0, spent: 0, due: 0 };

        if (sortOrder === 'mostDue') {
          return stB.due - stA.due;
        } else if (sortOrder === 'name') {
          return a.name.localeCompare(b.name);
        } else {
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        }
      });
  }, [state.customers, activeTab, searchQuery, sortOrder, customerStats]);

  const handleOpenAddModal = () => {
    setNewBdNumber('');
    setNewName('');
    setNewPhone('');
    setModalError('');
    setAddModalOpen(true);
  };

  const handleSaveNewCustomer = () => {
    setModalError('');
    const cleanBd = newBdNumber.trim();
    const cleanName = newName.trim();
    const cleanPhone = newPhone.trim();

    if (!cleanBd) {
      setModalError('BD Number is required.');
      return;
    }
    if (!cleanName) {
      setModalError('Customer Name is required.');
      return;
    }

    const res = addCustomer({
      category: activeTab,
      bdNumber: cleanBd,
      name: cleanName,
      phone: cleanPhone,
    });

    if (!res.success) {
      setModalError(res.error || 'Failed to add customer.');
      return;
    }

    setAddModalOpen(false);
  };

  const handleOpenEditModal = (c: Customer) => {
    setEditTarget(c);
    setEditName(c.name);
    setEditPhone(c.phone || '');
  };

  const handleSaveEditCustomer = () => {
    if (!editTarget) return;
    const cleanName = editName.trim();
    if (!cleanName) return;

    updateCustomer(editTarget.bdNumber, editTarget.category, {
      name: cleanName,
      phone: editPhone.trim(),
    });
    setEditTarget(null);
  };

  const handleDeleteClick = (c: Customer) => {
    const key = `${c.category}-${c.bdNumber.trim().toUpperCase()}`;
    const st = customerStats[key];
    if (st && st.ordersCount > 0) {
      setDeleteBlockedMessage(
        `Cannot delete ${c.category} customer with BD ${c.bdNumber} because they have ${st.ordersCount} existing orders.`
      );
      return;
    }
    setDeleteTarget(c);
  };

  const handleConfirmDelete = () => {
    if (deleteTarget) {
      deleteCustomer(deleteTarget.bdNumber, deleteTarget.category);
      setDeleteTarget(null);
    }
  };

  return (
    <PolarisPage
      title="Customers"
      subtitle="Registered Air Force customer records, measurements, and order histories"
      primaryAction={{
        label: 'Add Customer',
        onClick: handleOpenAddModal,
        icon: <Plus className="w-3.5 h-3.5" />,
      }}
      fullWidth={true}
    >
      <PolarisCard flush={true}>
        {/* Category Tabs & Search/Sort */}
        <PolarisTabs
          tabs={[
            {
              id: 'Officer',
              label: 'Officer Customers',
              count: state.customers.filter((c) => c.category === 'Officer').length,
            },
            {
              id: 'Airman',
              label: 'Airman Customers',
              count: state.customers.filter((c) => c.category === 'Airman').length,
            },
          ]}
          selectedTab={activeTab}
          onSelectTab={(tabId) => setActiveTab(tabId as any)}
          tools={
            <div className="flex items-center space-x-2">
              <div className="relative w-48 sm:w-60">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#8A8A8A]" />
                <input
                  type="text"
                  placeholder="Search name, phone, BD..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full h-7 pl-8 pr-6 text-[12px] bg-white border border-[#E3E3E3] rounded-lg focus:outline-none focus:border-[#303030] text-[#303030]"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-[#8A8A8A] hover:text-[#303030]"
                    aria-label="Clear filter"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>

              <select
                value={sortOrder}
                onChange={(e) => setSortOrder(e.target.value as any)}
                className="h-7 pl-2.5 pr-6 text-[12px] bg-white border border-[#E3E3E3] rounded-lg text-[#303030] focus:outline-none focus:border-[#303030] cursor-pointer"
                aria-label="Sort order"
              >
                <option value="newest">Recently added</option>
                <option value="name">Name (A-Z)</option>
                {activeTab === 'Officer' && <option value="mostDue">Highest due</option>}
              </select>
            </div>
          }
        />

        {/* Empty State */}
        {filteredCustomers.length === 0 ? (
          <div className="p-12 text-center text-[#616161]">
            <AlertCircle className="w-10 h-10 mx-auto text-[#8A8A8A] mb-2 opacity-50" />
            <h3 className="text-[14px] font-[650] text-[#1A1A1A]">No customers found</h3>
            <p className="text-[13px] text-[#616161] mt-1">
              {searchQuery
                ? 'No customers match your search criteria.'
                : `No registered ${activeTab} customers found.`}
            </p>
          </div>
        ) : (
          /* 54px Polaris IndexTable */
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-[13px]">
              <thead>
                <tr className="h-9 border-b border-[#E3E3E3] bg-white text-[12px] font-[450] text-[#616161]">
                  <th className="px-3 w-32 text-left">BD Number</th>
                  <th className="px-3 text-left">Customer Name</th>
                  <th className="px-3 text-left">Phone</th>
                  <th className="px-3 text-center">Orders</th>
                  {activeTab === 'Officer' && (
                    <>
                      <th className="px-3 text-right">Total Spent</th>
                      <th className="px-3 text-right">Current Due</th>
                    </>
                  )}
                  <th className="px-3 text-right w-36">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E3E3E3]">
                {filteredCustomers.map((c) => {
                  const key = `${c.category}-${c.bdNumber.trim().toUpperCase()}`;
                  const st = customerStats[key] || { ordersCount: 0, spent: 0, due: 0 };

                  return (
                    <tr
                      key={c.id}
                      onClick={() =>
                        onNavigate('customer-history', {
                          bdNumber: c.bdNumber,
                          category: c.category,
                        })
                      }
                      className="h-[54px] hover:bg-[#F7F7F7] cursor-pointer transition-colors"
                    >
                      <td className="px-3 font-[650] text-[#1A1A1A]">{c.bdNumber}</td>
                      <td className="px-3 font-[550] text-[#1A1A1A]">{c.name}</td>
                      <td className="px-3 text-[#616161]">{c.phone || '—'}</td>
                      <td className="px-3 text-center text-[#303030] tabular-nums font-[550]">
                        {st.ordersCount}
                      </td>
                      {activeTab === 'Officer' && (
                        <>
                          <td className="px-3 text-right text-[#1A1A1A] tabular-nums font-[550]">
                            ৳{st.spent.toLocaleString()}
                          </td>
                          <td
                            className={`px-3 text-right font-[650] tabular-nums ${
                              st.due > 0 ? 'text-[#8E0B21]' : 'text-[#616161]'
                            }`}
                          >
                            ৳{st.due.toLocaleString()}
                          </td>
                        </>
                      )}
                      <td className="px-3 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end space-x-1">
                          <button
                            onClick={() =>
                              onNavigate('customer-history', {
                                bdNumber: c.bdNumber,
                                category: c.category,
                              })
                            }
                            title="Order History"
                            className="p-1 text-[#616161] hover:text-[#005BD3] hover:bg-[#EBEBEB] rounded"
                            aria-label="View history"
                          >
                            <History className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleOpenEditModal(c)}
                            title="Edit"
                            className="p-1 text-[#616161] hover:text-[#005BD3] hover:bg-[#EBEBEB] rounded"
                            aria-label="Edit customer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteClick(c)}
                            title="Delete"
                            className="p-1 text-[#616161] hover:text-[#8E0B21] hover:bg-[#FEE9E8] rounded"
                            aria-label="Delete customer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </PolarisCard>

      {/* Add Customer Modal */}
      {addModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-2xs animate-in fade-in">
          <div
            className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-[#E3E3E3]"
            style={{ borderRadius: 'var(--radius-lg)' }}
          >
            <div className="h-12 px-4 bg-[#F1F1F1] border-b border-[#E3E3E3] flex items-center justify-between">
              <h3 className="text-[14px] font-[650] text-[#1A1A1A]">
                Add {activeTab} Customer
              </h3>
              <button
                onClick={() => setAddModalOpen(false)}
                className="p-1 rounded text-[#616161] hover:text-[#1A1A1A]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3 text-[13px]">
              {modalError && (
                <div className="p-2 bg-[#FEE9E8] text-[#8E0B21] text-[12px] font-medium rounded-lg">
                  {modalError}
                </div>
              )}
              <div>
                <label className="block text-[11px] text-[#616161] font-medium mb-1">
                  BD Number <span className="text-[#8E0B21]">*</span>
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={newBdNumber}
                  onChange={(e) => setNewBdNumber(e.target.value.replace(/\D/g, ''))}
                  placeholder="e.g. 10380"
                  className="w-full h-8 px-2.5 text-[13px] bg-white border border-[#E3E3E3] rounded-lg font-[550]"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[#616161] font-medium mb-1">
                  Customer Name <span className="text-[#8E0B21]">*</span>
                </label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. W/Cdr Masud"
                  className="w-full h-8 px-2.5 text-[13px] bg-white border border-[#E3E3E3] rounded-lg"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[#616161] font-medium mb-1">Phone Number</label>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="e.g. 01711000000"
                  className="w-full h-8 px-2.5 text-[13px] bg-white border border-[#E3E3E3] rounded-lg"
                />
              </div>
            </div>
            <div className="px-4 py-3 bg-[#FAFAFA] border-t border-[#E3E3E3] flex items-center justify-end space-x-2">
              <button
                onClick={() => setAddModalOpen(false)}
                className="h-7 px-3 rounded-lg bg-white border border-[#E3E3E3] text-[#303030] text-[13px] font-[550]"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveNewCustomer}
                className="h-7 px-3 rounded-lg bg-[#303030] hover:bg-[#1A1A1A] text-white text-[13px] font-[550]"
              >
                Save Customer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Customer Modal */}
      {editTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-2xs animate-in fade-in">
          <div
            className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-[#E3E3E3]"
            style={{ borderRadius: 'var(--radius-lg)' }}
          >
            <div className="h-12 px-4 bg-[#F1F1F1] border-b border-[#E3E3E3] flex items-center justify-between">
              <h3 className="text-[14px] font-[650] text-[#1A1A1A]">
                Edit Customer (BD: {editTarget.bdNumber})
              </h3>
              <button
                onClick={() => setEditTarget(null)}
                className="p-1 rounded text-[#616161] hover:text-[#1A1A1A]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3 text-[13px]">
              <div>
                <label className="block text-[11px] text-[#616161] font-medium mb-1">
                  Customer Name
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full h-8 px-2.5 text-[13px] bg-white border border-[#E3E3E3] rounded-lg"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[#616161] font-medium mb-1">Phone Number</label>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={editPhone}
                  onChange={(e) => setEditPhone(e.target.value.replace(/\D/g, ''))}
                  className="w-full h-8 px-2.5 text-[13px] bg-white border border-[#E3E3E3] rounded-lg"
                />
              </div>
            </div>
            <div className="px-4 py-3 bg-[#FAFAFA] border-t border-[#E3E3E3] flex items-center justify-end space-x-2">
              <button
                onClick={() => setEditTarget(null)}
                className="h-7 px-3 rounded-lg bg-white border border-[#E3E3E3] text-[#303030] text-[13px] font-[550]"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveEditCustomer}
                className="h-7 px-3 rounded-lg bg-[#303030] hover:bg-[#1A1A1A] text-white text-[13px] font-[550]"
              >
                Update Customer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-2xs animate-in fade-in">
          <div
            className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-[#E3E3E3]"
            style={{ borderRadius: 'var(--radius-lg)' }}
          >
            <div className="h-12 px-4 bg-[#F1F1F1] border-b border-[#E3E3E3] flex items-center justify-between">
              <h3 className="text-[14px] font-[650] text-[#1A1A1A]">Delete Customer?</h3>
              <button
                onClick={() => setDeleteTarget(null)}
                className="p-1 rounded text-[#616161] hover:text-[#1A1A1A]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 text-[13px] text-[#616161]">
              Are you sure you want to delete customer <strong>{deleteTarget.name}</strong> (BD:{' '}
              {deleteTarget.bdNumber})?
            </div>
            <div className="px-4 py-3 bg-[#FAFAFA] border-t border-[#E3E3E3] flex items-center justify-end space-x-2">
              <button
                onClick={() => setDeleteTarget(null)}
                className="h-7 px-3 rounded-lg bg-white border border-[#E3E3E3] text-[#303030] text-[13px] font-[550]"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                className="h-7 px-3 rounded-lg bg-[#8E0B21] hover:bg-[#72091A] text-white text-[13px] font-[550]"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Blocked Delete Modal */}
      {deleteBlockedMessage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-2xs animate-in fade-in">
          <div
            className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-[#E3E3E3]"
            style={{ borderRadius: 'var(--radius-lg)' }}
          >
            <div className="h-12 px-4 bg-[#F1F1F1] border-b border-[#E3E3E3] flex items-center justify-between">
              <h3 className="text-[14px] font-[650] text-[#8E0B21] flex items-center space-x-1.5">
                <AlertTriangle className="w-4 h-4" />
                <span>Cannot Delete Customer</span>
              </h3>
              <button
                onClick={() => setDeleteBlockedMessage('')}
                className="p-1 rounded text-[#616161] hover:text-[#1A1A1A]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 text-[13px] text-[#616161] leading-relaxed">
              {deleteBlockedMessage}
            </div>
            <div className="px-4 py-3 bg-[#FAFAFA] border-t border-[#E3E3E3] flex justify-end">
              <button
                onClick={() => setDeleteBlockedMessage('')}
                className="h-7 px-3 rounded-lg bg-[#303030] text-white text-[13px] font-[550]"
              >
                Understood
              </button>
            </div>
          </div>
        </div>
      )}
    </PolarisPage>
  );
};
