import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ScreenName } from '../Navbar.tsx';
import { TopBar } from './TopBar.tsx';
import { Sidebar } from './Sidebar.tsx';
import { GlobalSearchModal } from './GlobalSearchModal.tsx';
import { OfflineIndicator } from '../OfflineIndicator.tsx';
import {
  LayoutDashboard,
  ClipboardList,
  Plane,
  Truck,
  Plus,
  MoreHorizontal,
  FileText,
  Users,
  History,
  UserCheck,
  BarChart3,
  Settings,
  X,
  ChevronRight,
  Scissors,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext.tsx';

interface AppFrameProps {
  currentScreen: ScreenName;
  onNavigate: (screen: ScreenName, params?: any) => void;
  children: React.ReactNode;
}

export const AppFrame: React.FC<AppFrameProps> = ({
  currentScreen,
  onNavigate,
  children,
}) => {
  const { state } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [moreSheetOpen, setMoreSheetOpen] = useState(false);
  const [quickOrderSheetOpen, setQuickOrderSheetOpen] = useState(false);

  const isOfficerActive =
    currentScreen === 'orders' ||
    currentScreen === 'new-officer-order' ||
    currentScreen === 'edit-officer-order' ||
    currentScreen === 'order-details';

  const isAirmanActive =
    currentScreen === 'airman-orders' ||
    currentScreen === 'new-airman-order' ||
    currentScreen === 'edit-airman-order';

  const isDashboardActive = currentScreen === 'dashboard';
  const isDeliveryActive = currentScreen === 'delivery';

  const isMoreActive =
    currentScreen === 'customers' ||
    currentScreen === 'customer-history' ||
    currentScreen === 'drafts' ||
    currentScreen === 'staff-management' ||
    currentScreen === 'staff-summary' ||
    currentScreen === 'worker-page' ||
    currentScreen === 'worker-history' ||
    currentScreen === 'settings';

  const draftsCount = state.drafts.length;

  const handleMobileNav = (screen: ScreenName) => {
    onNavigate(screen);
    setMoreSheetOpen(false);
    setQuickOrderSheetOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#f5f5f7] flex flex-col font-sans selection:bg-[#0066cc] selection:text-white pb-24 md:pb-0 overflow-x-hidden darzi-canvas">
      {/* TopBar with brand chip and segment pills */}
      <TopBar
        onNavigate={onNavigate}
        onOpenSearch={() => setSearchModalOpen(true)}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
        currentScreen={currentScreen}
      />

      {/* Main Body */}
      <div className="flex-1 flex bg-[#f5f5f7] overflow-hidden min-h-0">
        {/* Persistent Desktop Sidebar (for other connected views: Customers, Staff, History) */}
        <Sidebar
          currentScreen={currentScreen}
          onNavigate={onNavigate}
          mobileMenuOpen={mobileMenuOpen}
          setMobileMenuOpen={setMobileMenuOpen}
        />

        {/* Main Canvas */}
        <main
          className="flex-1 overflow-y-auto min-w-0 bg-[#f5f5f7] p-3 sm:p-5 lg:p-7"
        >
          {children}
        </main>
      </div>

      {/* Global Search Modal (Cmd + K) */}
      <GlobalSearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onNavigate={onNavigate}
      />

      {/* Offline Status Pill */}
      <OfflineIndicator />

      {/* =========================================================================
          Qine Design FLOATING BOTTOM NAVIGATION DOCK (Mobile Only < 768px)
          Utilitarian Polaris Dark Theme matching Raymond Outfitter
         ========================================================================= */}
      <div className="md:hidden fixed bottom-4 inset-x-0 z-40 px-3 flex items-center justify-center pointer-events-none safe-area-bottom">
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Main Floating Island Dock */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="h-[52px] px-1.5 rounded-full bg-[#1A1A1A] text-white border border-[#333333] shadow-[0_12px_32px_rgba(0,0,0,0.4)] backdrop-blur-md flex items-center gap-1"
          >
            {/* Dashboard Tab */}
            <motion.button
              whileTap={{ scale: 0.94 }}
              onClick={() => handleMobileNav('dashboard')}
              className={`relative h-9 px-3 rounded-full flex items-center gap-1.5 transition-all text-xs cursor-pointer ${
                isDashboardActive
                  ? 'bg-[#FAFAFA] text-[#1A1A1A] font-semibold shadow-xs'
                  : 'text-[#B5B5B5] hover:text-white font-medium'
              }`}
            >
              <LayoutDashboard className="w-4 h-4 shrink-0" strokeWidth={isDashboardActive ? 2.2 : 1.6} />
              {isDashboardActive && <span className="leading-none text-[11px]">Dashboard</span>}
            </motion.button>

            {/* Officer Orders Tab */}
            <motion.button
              whileTap={{ scale: 0.94 }}
              onClick={() => handleMobileNav('orders')}
              className={`relative h-9 px-3 rounded-full flex items-center gap-1.5 transition-all text-xs cursor-pointer ${
                isOfficerActive
                  ? 'bg-[#FAFAFA] text-[#1A1A1A] font-semibold shadow-xs'
                  : 'text-[#B5B5B5] hover:text-white font-medium'
              }`}
            >
              <ClipboardList className="w-4 h-4 shrink-0" strokeWidth={isOfficerActive ? 2.2 : 1.6} />
              {isOfficerActive && <span className="leading-none text-[11px]">Officers</span>}
            </motion.button>

            {/* Airmen Orders Tab */}
            <motion.button
              whileTap={{ scale: 0.94 }}
              onClick={() => handleMobileNav('airman-orders')}
              className={`relative h-9 px-3 rounded-full flex items-center gap-1.5 transition-all text-xs cursor-pointer ${
                isAirmanActive
                  ? 'bg-[#FAFAFA] text-[#1A1A1A] font-semibold shadow-xs'
                  : 'text-[#B5B5B5] hover:text-white font-medium'
              }`}
            >
              <Plane className="w-4 h-4 shrink-0" strokeWidth={isAirmanActive ? 2.2 : 1.6} />
              {isAirmanActive && <span className="leading-none text-[11px]">Airmen</span>}
            </motion.button>

            {/* Delivery Tab */}
            <motion.button
              whileTap={{ scale: 0.94 }}
              onClick={() => handleMobileNav('delivery')}
              className={`relative h-9 px-3 rounded-full flex items-center gap-1.5 transition-all text-xs cursor-pointer ${
                isDeliveryActive
                  ? 'bg-[#FAFAFA] text-[#1A1A1A] font-semibold shadow-xs'
                  : 'text-[#B5B5B5] hover:text-white font-medium'
              }`}
            >
              <Truck className="w-4 h-4 shrink-0" strokeWidth={isDeliveryActive ? 2.2 : 1.6} />
              {isDeliveryActive && <span className="leading-none text-[11px]">Delivery</span>}
            </motion.button>

            {/* More / Menu Drawer Trigger */}
            <motion.button
              whileTap={{ scale: 0.94 }}
              onClick={() => setMoreSheetOpen(true)}
              className={`relative h-9 px-2.5 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                isMoreActive
                  ? 'bg-white/20 text-white font-semibold'
                  : 'text-[#B5B5B5] hover:text-white'
              }`}
              title="More Options"
            >
              <MoreHorizontal className="w-4 h-4" />
              {draftsCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#D72C35] rounded-full" />
              )}
            </motion.button>
          </motion.div>

          {/* Floating Action Button (+ New Order) - Brand Near-Black Theme */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.92 }}
            onClick={() => setQuickOrderSheetOpen(true)}
            className="w-[48px] h-[52px] rounded-full bg-[#1A1A1A] hover:bg-black text-white flex items-center justify-center shadow-[0_12px_28px_rgba(0,0,0,0.4)] border border-[#3E3E3E] cursor-pointer shrink-0 transition-transform"
            aria-label="Create New Order"
          >
            <Plus className="w-5 h-5 stroke-[2.4]" />
          </motion.button>
        </div>
      </div>

      {/* Quick Order Selection Sheet */}
      <AnimatePresence>
        {quickOrderSheetOpen && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setQuickOrderSheetOpen(false)}
              className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            />
            <motion.div
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 100, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 350 }}
              className="relative z-10 w-full max-w-sm bg-white rounded-t-2xl sm:rounded-2xl p-5 border border-[#E3E3E3] shadow-2xl safe-area-bottom"
            >
              <div className="w-10 h-1 bg-[#E3E3E3] rounded-full mx-auto mb-3 sm:hidden" />
              <div className="flex items-center justify-between pb-3 border-b border-[#E3E3E3] mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-[#1A1A1A] text-white flex items-center justify-center">
                    <Scissors className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-bold text-[#1A1A1A]">Create New Uniform Order</h3>
                </div>
                <button
                  onClick={() => setQuickOrderSheetOpen(false)}
                  className="p-1 rounded-md text-[#616161] hover:text-[#1A1A1A] hover:bg-[#F1F1F1]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2">
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleMobileNav('new-officer-order')}
                  className="w-full p-3.5 rounded-xl bg-[#1A1A1A] hover:bg-black text-white text-left flex items-center justify-between border border-[#303030] shadow-xs cursor-pointer transition-all"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-white">
                      <ClipboardList className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-white">Officer Order</div>
                      <div className="text-xs text-[#B5B5B5]">Commissioned Officer uniform & cutting slip</div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#B5B5B5]" />
                </motion.button>

                <motion.button
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleMobileNav('new-airman-order')}
                  className="w-full p-3.5 rounded-xl bg-white hover:bg-[#F7F7F7] text-[#1A1A1A] text-left flex items-center justify-between border border-[#E3E3E3] shadow-xs cursor-pointer transition-all"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#F1F1F1] flex items-center justify-center text-[#303030]">
                      <Plane className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[#1A1A1A]">Airman Order</div>
                      <div className="text-xs text-[#616161]">Non-commissioned airmen trade batch</div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#616161]" />
                </motion.button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* "More" Mobile Bottom Drawer (Unified Polaris Iconography) */}
      <AnimatePresence>
        {moreSheetOpen && (
          <div className="fixed inset-0 z-50 flex items-end justify-center">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMoreSheetOpen(false)}
              className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            />
            <motion.div
              initial={{ y: 200, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 200, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 350 }}
              className="relative z-10 w-full max-w-lg bg-white rounded-t-2xl p-4 sm:p-5 border-t border-[#E3E3E3] shadow-2xl safe-area-bottom max-h-[85vh] overflow-y-auto"
            >
              <div className="w-10 h-1 bg-[#E3E3E3] rounded-full mx-auto mb-3" />

              <div className="flex items-center justify-between pb-3 border-b border-[#E3E3E3] mb-3">
                <div>
                  <h3 className="text-sm font-bold text-[#1A1A1A]">Workshop Modules</h3>
                  <p className="text-xs text-[#616161]">Raymond BAF Tailor Studio</p>
                </div>
                <button
                  onClick={() => setMoreSheetOpen(false)}
                  className="p-1 rounded-md text-[#616161] hover:text-[#1A1A1A] hover:bg-[#F1F1F1]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Group 1: Workshop Operations (Unified Polaris Icons) */}
              <div className="mb-3.5">
                <span className="text-[11px] font-semibold text-[#616161] uppercase tracking-wider px-1 mb-1 block">
                  Orders & Records
                </span>
                <div className="bg-[#FAFAFA] rounded-xl border border-[#E3E3E3] overflow-hidden divide-y divide-[#E3E3E3]">
                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleMobileNav('drafts')}
                    className="w-full p-3 flex items-center justify-between text-left hover:bg-[#F3F3F3] transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-7 h-7 rounded-lg bg-[#EBEBEB] text-[#303030] flex items-center justify-center">
                        <FileText className="w-4 h-4" strokeWidth={1.75} />
                      </div>
                      <span className="text-xs font-medium text-[#303030]">Draft Orders</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {draftsCount > 0 && (
                        <span className="px-2 py-0.2 rounded-full text-[11px] font-bold bg-[#E3E3E3] text-[#303030]">
                          {draftsCount}
                        </span>
                      )}
                      <ChevronRight className="w-4 h-4 text-[#8A8A8A]" />
                    </div>
                  </motion.button>

                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleMobileNav('customers')}
                    className="w-full p-3 flex items-center justify-between text-left hover:bg-[#F3F3F3] transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-7 h-7 rounded-lg bg-[#EBEBEB] text-[#303030] flex items-center justify-center">
                        <Users className="w-4 h-4" strokeWidth={1.75} />
                      </div>
                      <span className="text-xs font-medium text-[#303030]">Customers Directory</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#8A8A8A]" />
                  </motion.button>

                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleMobileNav('customer-history')}
                    className="w-full p-3 flex items-center justify-between text-left hover:bg-[#F3F3F3] transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-7 h-7 rounded-lg bg-[#EBEBEB] text-[#303030] flex items-center justify-center">
                        <History className="w-4 h-4" strokeWidth={1.75} />
                      </div>
                      <span className="text-xs font-medium text-[#303030]">Customer History</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#8A8A8A]" />
                  </motion.button>
                </div>
              </div>

              {/* Group 2: Workshop Staff & Management */}
              <div className="mb-3.5">
                <span className="text-[11px] font-semibold text-[#616161] uppercase tracking-wider px-1 mb-1 block">
                  Staff & Production
                </span>
                <div className="bg-[#FAFAFA] rounded-xl border border-[#E3E3E3] overflow-hidden divide-y divide-[#E3E3E3]">
                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleMobileNav('staff-management')}
                    className="w-full p-3 flex items-center justify-between text-left hover:bg-[#F3F3F3] transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-7 h-7 rounded-lg bg-[#EBEBEB] text-[#303030] flex items-center justify-center">
                        <UserCheck className="w-4 h-4" strokeWidth={1.75} />
                      </div>
                      <span className="text-xs font-medium text-[#303030]">Staff Management</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#8A8A8A]" />
                  </motion.button>

                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleMobileNav('staff-summary')}
                    className="w-full p-3 flex items-center justify-between text-left hover:bg-[#F3F3F3] transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-7 h-7 rounded-lg bg-[#EBEBEB] text-[#303030] flex items-center justify-center">
                        <BarChart3 className="w-4 h-4" strokeWidth={1.75} />
                      </div>
                      <span className="text-xs font-medium text-[#303030]">Staff Monthly Summary</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#8A8A8A]" />
                  </motion.button>
                </div>
              </div>

              {/* Group 3: Settings */}
              <div>
                <div className="bg-[#FAFAFA] rounded-xl border border-[#E3E3E3] overflow-hidden">
                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleMobileNav('settings')}
                    className="w-full p-3 flex items-center justify-between text-left hover:bg-[#F3F3F3] transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-7 h-7 rounded-lg bg-[#EBEBEB] text-[#303030] flex items-center justify-center">
                        <Settings className="w-4 h-4" strokeWidth={1.75} />
                      </div>
                      <span className="text-xs font-medium text-[#303030]">Settings & Shop Preferences</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#8A8A8A]" />
                  </motion.button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
