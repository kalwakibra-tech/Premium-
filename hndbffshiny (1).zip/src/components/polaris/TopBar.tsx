import React from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { ScreenName } from '../Navbar.tsx';
import {
  Search,
  Bell,
  Menu,
  X,
  Truck,
  Plus,
  Scissors,
} from 'lucide-react';

interface TopBarProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
  onOpenSearch: () => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
  currentScreen?: ScreenName;
}

export const TopBar: React.FC<TopBarProps> = ({
  onNavigate,
  onOpenSearch,
  mobileMenuOpen,
  setMobileMenuOpen,
  currentScreen = 'orders',
}) => {
  const { state } = useApp();

  const upcomingCount = state.officerOrders.filter((o) => {
    if (o.status === 'Delivered') return false;
    if (!o.deliveryDate) return false;
    const diff = (new Date(o.deliveryDate).getTime() - new Date().getTime()) / (1000 * 3600 * 24);
    return diff >= 0 && diff <= (state.settings.upcomingDeliveryDays || 3);
  }).length;

  const dueCount = state.officerOrders.filter(
    (o) => o.status === 'Delivered' && o.due > 0
  ).length;

  const alertCount = upcomingCount + dueCount;

  const isOrders =
    currentScreen === 'orders' ||
    currentScreen === 'new-officer-order' ||
    currentScreen === 'edit-officer-order' ||
    currentScreen === 'order-details';

  const isAirman =
    currentScreen === 'airman-orders' ||
    currentScreen === 'new-airman-order' ||
    currentScreen === 'edit-airman-order';

  const isDelivery = currentScreen === 'delivery';
  const isDashboard = currentScreen === 'dashboard';
  const isSettings = currentScreen === 'settings';

  return (
    <header className="w-full bg-[#f5f5f7] border-b border-[#e8e8ed] px-4 md:px-7 py-2.5 flex items-center justify-between select-none print:hidden z-30 sticky top-0 transition-colors">
      {/* Left: Brand Chip (Darzi / Raymond) */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 rounded-full bg-white border border-[#e0e0e0] text-[#1d1d1f] hover:bg-[#f5f5f7] active:scale-95 transition-transform"
          aria-label="Toggle navigation menu"
        >
          {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
        </button>

        <div
          onClick={() => onNavigate('orders')}
          className="flex items-center gap-2.5 bg-white rounded-full py-1.5 pr-4 pl-1.5 cursor-pointer border border-[#e8e8ed] hover:border-[#d0d0d5] shadow-[0_1px_3px_rgba(0,0,0,0.04)] transition-all"
        >
          <div className="w-8 h-8 rounded-full bg-[#1d1d1f] text-white flex items-center justify-center font-semibold text-xs tracking-tight">
            R
          </div>
          <div className="leading-tight">
            <div className="font-semibold text-[13px] text-[#1d1d1f] tracking-tight">Raymond</div>
            <div className="text-[11px] text-[#6e6e73]">Tailor Shop Manager</div>
          </div>
        </div>
      </div>

      {/* Center: Connected Segment Pill Navigation (Desktop) */}
      <nav className="hidden md:flex items-center bg-white rounded-full p-1 border border-[#e8e8ed] shadow-[0_1px_2px_rgba(0,0,0,0.03)]">
        <button
          onClick={() => onNavigate('orders')}
          className={`px-4 py-1.5 rounded-full font-semibold text-[13px] transition-all cursor-pointer ${
            isOrders
              ? 'bg-[#1d1d1f] text-white shadow-xs'
              : 'text-[#6e6e73] hover:text-[#1d1d1f]'
          }`}
        >
          Orders
        </button>
        <button
          onClick={() => onNavigate('airman-orders')}
          className={`px-4 py-1.5 rounded-full font-semibold text-[13px] transition-all cursor-pointer ${
            isAirman
              ? 'bg-[#1d1d1f] text-white shadow-xs'
              : 'text-[#6e6e73] hover:text-[#1d1d1f]'
          }`}
        >
          Airman
        </button>
        <button
          onClick={() => onNavigate('delivery')}
          className={`px-4 py-1.5 rounded-full font-semibold text-[13px] transition-all cursor-pointer relative ${
            isDelivery
              ? 'bg-[#1d1d1f] text-white shadow-xs'
              : 'text-[#6e6e73] hover:text-[#1d1d1f]'
          }`}
        >
          Delivery
          {upcomingCount > 0 && (
            <span className="ml-1.5 px-1.5 py-0.2 rounded-full text-[10px] bg-[#f0561f] text-white font-bold">
              {upcomingCount}
            </span>
          )}
        </button>
        <button
          onClick={() => onNavigate('dashboard')}
          className={`px-4 py-1.5 rounded-full font-semibold text-[13px] transition-all cursor-pointer ${
            isDashboard
              ? 'bg-[#1d1d1f] text-white shadow-xs'
              : 'text-[#6e6e73] hover:text-[#1d1d1f]'
          }`}
        >
          Dashboard
        </button>
        <button
          onClick={() => onNavigate('settings')}
          className={`px-4 py-1.5 rounded-full font-semibold text-[13px] transition-all cursor-pointer ${
            isSettings
              ? 'bg-[#1d1d1f] text-white shadow-xs'
              : 'text-[#6e6e73] hover:text-[#1d1d1f]'
          }`}
        >
          Settings
        </button>
      </nav>

      {/* Right: Search Chip & Quick Action */}
      <div className="flex items-center gap-2">
        <button
          onClick={onOpenSearch}
          className="h-9 px-3 rounded-full bg-white border border-[#e0e0e0] hover:border-[#b5b5b5] text-[#6e6e73] hover:text-[#1d1d1f] flex items-center gap-2 text-xs transition-colors cursor-pointer"
          aria-label="Global search"
        >
          <Search className="w-3.5 h-3.5 text-[#6e6e73]" />
          <span className="hidden xl:inline text-xs">Search orders, BD...</span>
          <kbd className="hidden sm:inline-flex px-1.5 py-0.5 text-[10px] bg-[#f5f5f7] border border-[#e0e0e0] rounded-md font-mono text-[#6e6e73]">
            ⌘K
          </kbd>
        </button>

        <button
          onClick={() => onNavigate('new-officer-order')}
          className="darzi-btn darzi-btn-sm"
          title="Create New Order"
        >
          <Plus className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">New order</span>
        </button>
      </div>
    </header>
  );
};

