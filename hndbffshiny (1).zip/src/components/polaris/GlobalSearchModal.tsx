import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { ScreenName } from '../Navbar.tsx';
import {
  Search,
  X,
  ClipboardList,
  Plane,
  Users,
  UserCheck,
  ArrowRight,
} from 'lucide-react';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
}) => {
  const { state } = useApp();
  const [query, setQuery] = useState('');
  const [activeChip, setActiveChip] = useState<'All' | 'Orders' | 'Customers' | 'Staff'>('All');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
      setActiveChip('All');
    }
  }, [isOpen]);

  // Global Keyboard Listener for Cmd+K and ESC
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      } else if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const searchResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];

    const results: {
      id: string;
      title: string;
      subtitle: string;
      badge: string;
      category: 'Orders' | 'Customers' | 'Staff';
      action: () => void;
    }[] = [];

    // 1. Officer Orders
    if (activeChip === 'All' || activeChip === 'Orders') {
      state.officerOrders.forEach((o) => {
        const matchesNum = String(o.orderNumber).includes(q) || `#${o.orderNumber}`.includes(q);
        const matchesName = o.customerName.toLowerCase().includes(q);
        const matchesBd = o.customerBdNumber.toLowerCase().includes(q);
        const matchesPhone = (o.customerPhone || '').toLowerCase().includes(q);

        if (matchesNum || matchesName || matchesBd || matchesPhone) {
          results.push({
            id: `off-${o.id}`,
            title: `Order #${o.orderNumber} · ${o.customerName}`,
            subtitle: `BD: ${o.customerBdNumber} · Total ৳${o.totalAmount} · Status: ${o.status}`,
            badge: 'Officer',
            category: 'Orders',
            action: () => {
              onNavigate('order-details', { orderNumber: o.orderNumber, category: 'Officer' });
              onClose();
            },
          });
        }
      });

      // 2. Airman Orders
      state.airmanOrders.forEach((o) => {
        const matchesNum = String(o.orderNumber).includes(q) || `#${o.orderNumber}`.includes(q);
        const matchesName = o.customerName.toLowerCase().includes(q);
        const matchesBd = o.customerBdNumber.toLowerCase().includes(q);

        if (matchesNum || matchesName || matchesBd) {
          results.push({
            id: `air-${o.id}`,
            title: `Airman Order #${o.orderNumber} · ${o.customerName}`,
            subtitle: `BD: ${o.customerBdNumber} · Year: ${o.runningYear} · Status: ${o.status}`,
            badge: 'Airman',
            category: 'Orders',
            action: () => {
              onNavigate('order-details', { orderNumber: o.orderNumber, category: 'Airman' });
              onClose();
            },
          });
        }
      });
    }

    // 3. Customers
    if (activeChip === 'All' || activeChip === 'Customers') {
      state.customers.forEach((c) => {
        if (
          c.name.toLowerCase().includes(q) ||
          c.bdNumber.toLowerCase().includes(q) ||
          (c.phone && c.phone.includes(q))
        ) {
          results.push({
            id: `cust-${c.id}`,
            title: `${c.name} (${c.bdNumber})`,
            subtitle: `${c.category} Customer · Phone: ${c.phone || '—'}`,
            badge: c.category,
            category: 'Customers',
            action: () => {
              onNavigate('customer-history', { bdNumber: c.bdNumber, category: c.category });
              onClose();
            },
          });
        }
      });
    }

    // 4. Staff Workers
    if (activeChip === 'All' || activeChip === 'Staff') {
      state.workers.forEach((w) => {
        if (
          w.name.toLowerCase().includes(q) ||
          w.banglaName.toLowerCase().includes(q)
        ) {
          results.push({
            id: `worker-${w.id}`,
            title: `${w.name} (${w.banglaName})`,
            subtitle: `Tailor Staff Worker · Monthly Worksheets`,
            badge: 'Worker',
            category: 'Staff',
            action: () => {
              onNavigate('worker-page', { workerId: w.id });
              onClose();
            },
          });
        }
      });
    }

    return results.slice(0, 15);
  }, [query, activeChip, state, onNavigate, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 px-4">
      {/* Background scrim */}
      <div
        className="fixed inset-0 bg-black/40 backdrop-blur-2xs"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Polaris Floating Search Panel */}
      <div
        className="relative w-full max-w-[650px] bg-white rounded-2xl shadow-2xl border border-[#E3E3E3] overflow-hidden z-10 animate-in fade-in slide-in-from-top-4 duration-150 flex flex-col max-h-[80vh]"
        style={{ borderRadius: 'var(--radius-lg)' }}
      >
        {/* Search Input Row */}
        <div className="p-3 border-b border-[#E3E3E3] flex items-center space-x-2.5">
          <Search className="w-5 h-5 text-[#8A8A8A] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Search orders, customers, or tailors..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 text-[14px] text-[#303030] placeholder-[#8A8A8A] bg-transparent outline-none font-[450]"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-md text-[#8A8A8A] hover:text-[#303030] hover:bg-[#F3F3F3]"
              aria-label="Clear query"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <kbd className="px-1.5 py-0.5 rounded bg-[#F1F1F1] text-[#616161] text-[10px] font-medium border border-[#E3E3E3]">
            ESC
          </kbd>
        </div>

        {/* Scope Chips */}
        <div className="px-3 py-2 bg-[#FAFAFA] border-b border-[#E3E3E3] flex items-center space-x-1.5 overflow-x-auto text-xs">
          {(['All', 'Orders', 'Customers', 'Staff'] as const).map((chip) => {
            const isSelected = activeChip === chip;
            return (
              <button
                key={chip}
                onClick={() => setActiveChip(chip)}
                className={`h-7 px-3 rounded-lg text-xs font-[550] transition-colors ${
                  isSelected
                    ? 'bg-[#1A1A1A] text-white shadow-2xs'
                    : 'bg-[#E6E6E6] text-[#303030] hover:bg-[#DDD]'
                }`}
              >
                {chip}
              </button>
            );
          })}
        </div>

        {/* Results Area */}
        <div className="flex-1 overflow-y-auto divide-y divide-[#E3E3E3] max-h-[420px]">
          {query.trim() === '' ? (
            <div className="p-8 text-center text-[#8A8A8A] space-y-2">
              <Search className="w-8 h-8 mx-auto opacity-40 text-[#8A8A8A]" />
              <p className="text-xs font-medium">Find anything in Raymond Tailor Shop</p>
              <p className="text-[11px] text-[#A0A0A0]">
                Search by order #, BD number, customer phone, name, or staff member.
              </p>
            </div>
          ) : searchResults.length === 0 ? (
            <div className="p-8 text-center text-[#8A8A8A]">
              <p className="text-xs font-medium">No results found for "{query}"</p>
              <p className="text-[11px] text-[#A0A0A0] mt-1">Try another name, BD number, or order ID.</p>
            </div>
          ) : (
            searchResults.map((res) => (
              <div
                key={res.id}
                onClick={res.action}
                className="p-3 hover:bg-[#F7F7F7] cursor-pointer flex items-center justify-between group transition-colors"
              >
                <div className="flex items-center space-x-3 truncate">
                  <div className="w-8 h-8 rounded-lg bg-[#F1F1F1] text-[#303030] flex items-center justify-center shrink-0 border border-[#E3E3E3]">
                    {res.category === 'Orders' && <ClipboardList className="w-4 h-4" />}
                    {res.category === 'Customers' && <Users className="w-4 h-4" />}
                    {res.category === 'Staff' && <UserCheck className="w-4 h-4" />}
                  </div>
                  <div className="truncate">
                    <div className="text-[13px] font-[550] text-[#1A1A1A] truncate flex items-center space-x-2">
                      <span>{res.title}</span>
                      <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-[#EBEBEB] text-[#303030]">
                        {res.badge}
                      </span>
                    </div>
                    <div className="text-[11px] text-[#616161] truncate mt-0.5">
                      {res.subtitle}
                    </div>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-[#8A8A8A] opacity-0 group-hover:opacity-100 transition-opacity shrink-0 ml-2" />
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
