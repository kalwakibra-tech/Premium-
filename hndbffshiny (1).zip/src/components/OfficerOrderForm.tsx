import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  OfficerOrder,
  OfficerOrderItem,
  PantMeasurements,
  ShirtMeasurements,
  Customer,
} from '../types/index.ts';
import {
  INITIAL_PANT_MEASUREMENTS,
  INITIAL_SHIRT_MEASUREMENTS,
} from '../utils/starterData.ts';
import {
  calculateDiscount,
  calculateDue,
  formatDate,
  getBdDigits,
  getLatestMeasurementsForCustomer,
  normalizeBdNumber,
} from '../utils/logic.ts';
import {
  Plus,
  Trash2,
  Scissors,
  Check,
  X,
  ChevronDown,
  Search,
  Sparkles,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface OfficerOrderFormProps {
  orderNumber?: number; // defined if editing
  draftId?: string; // defined if opening draft
  onNavigate: (screen: ScreenName, params?: any) => void;
}

const LOCAL_DRAFT_KEY = 'officer_order_local_autosave';

export const OfficerOrderForm: React.FC<OfficerOrderFormProps> = ({
  orderNumber,
  draftId,
  onNavigate,
}) => {
  const { state, saveOfficerOrder, saveDraft, deleteDraft } = useApp();

  const isEdit = typeof orderNumber === 'number';
  const existingOrder = isEdit ? state.officerOrders.find((o) => o.orderNumber === orderNumber) : null;
  const existingDraft = draftId ? state.drafts.find((d) => d.id === draftId) : null;

  // Next order number
  const calculatedNextOrderNumber = useMemo(() => {
    if (isEdit && existingOrder) return existingOrder.orderNumber;
    return (
      state.officerOrders.reduce((max, o) => Math.max(max, Number(o.orderNumber) || 0), 0) + 1
    );
  }, [isEdit, existingOrder, state.officerOrders]);

  // Default first item
  const defaultFirstItem = useMemo(() => {
    const first = state.settings.items.find((i) => i.name !== 'MODC Uniform') || state.settings.items[0];
    return {
      id: `item-${Date.now()}-init`,
      name: first?.name || 'Battle Uniform',
      quantity: 1,
      price: first?.price || 800,
      lineTotal: first?.price || 800,
      rowType: 'Uniform',
    };
  }, [state.settings.items]);

  // Items State (including user's row type and quantity features)
  const [items, setItems] = useState<OfficerOrderItem[]>(() => [defaultFirstItem]);
  const [selectedItemName, setSelectedItemName] = useState('');
  const [newItemQty, setNewItemQty] = useState(1);
  const [newItemRowType, setNewItemRowType] = useState('Uniform');
  const [itemDropdownOpen, setItemDropdownOpen] = useState(false);
  const [itemSearchTerm, setItemSearchTerm] = useState('');

  // Measurements
  const [shirt, setShirt] = useState<ShirtMeasurements>(INITIAL_SHIRT_MEASUREMENTS);
  const [pant, setPant] = useState<PantMeasurements>(INITIAL_PANT_MEASUREMENTS);

  // Customer & dates
  const [bdDigits, setBdDigits] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [orderDate, setOrderDate] = useState(formatDate());
  const [deliveryDate, setDeliveryDate] = useState('');
  const [ribbon, setRibbon] = useState(state.settings.ribbonValues[0] || '3');

  // Money
  const [discountValue, setDiscountValue] = useState('');
  const [advance, setAdvance] = useState<number>(0);
  const [savedNameNotice, setSavedNameNotice] = useState<string>('');
  const [isDirty, setIsDirty] = useState(false);
  const [formError, setFormError] = useState<string>('');
  const [cancelModalOpen, setCancelModalOpen] = useState(false);

  // Mobile navigation tab: 'Items' | 'Customer' | 'Measure' | 'Money'
  const [mobileTab, setMobileTab] = useState<'Items' | 'Customer' | 'Measure' | 'Money'>('Items');

  // Existing payments if editing
  const existingPayments = useMemo(() => existingOrder?.payments || [], [existingOrder]);
  const receivedLater = useMemo(
    () => existingPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0),
    [existingPayments]
  );

  // Load existing order or draft
  useEffect(() => {
    if (existingOrder) {
      setItems(
        existingOrder.items.map((it) => ({
          ...it,
          rowType: (it as any).rowType || 'Uniform',
        }))
      );
      setShirt(existingOrder.shirtMeasurements || INITIAL_SHIRT_MEASUREMENTS);
      setPant(existingOrder.pantMeasurements || INITIAL_PANT_MEASUREMENTS);
      setBdDigits(getBdDigits(existingOrder.customerBdNumber));
      setCustomerName(existingOrder.customerName || '');
      setPhone(existingOrder.customerPhone || '');
      setOrderDate(existingOrder.orderDate || formatDate());
      setDeliveryDate(existingOrder.deliveryDate || '');
      setRibbon(existingOrder.ribbon || state.settings.ribbonValues[0] || '3');
      setDiscountValue(existingOrder.discountValue || '');
      setAdvance(existingOrder.advance || 0);
    } else if (existingDraft) {
      if (existingDraft.officerItems) setItems(existingDraft.officerItems);
      if (existingDraft.shirtMeasurements) setShirt(existingDraft.shirtMeasurements);
      if (existingDraft.pantMeasurements) setPant(existingDraft.pantMeasurements);
      if (existingDraft.customerBdNumber) setBdDigits(getBdDigits(existingDraft.customerBdNumber));
      if (existingDraft.customerName) setCustomerName(existingDraft.customerName);
      if (existingDraft.customerPhone) setPhone(existingDraft.customerPhone);
      if (existingDraft.orderDate) setOrderDate(existingDraft.orderDate);
      if (existingDraft.deliveryDate) setDeliveryDate(existingDraft.deliveryDate);
      if (existingDraft.ribbon) setRibbon(existingDraft.ribbon);
      if (existingDraft.discountValue) setDiscountValue(existingDraft.discountValue);
      if (typeof existingDraft.advance === 'number') setAdvance(existingDraft.advance);
    }
  }, [existingOrder, existingDraft]);

  // Auto-fill customer from state.customers when BD digits change
  const handleBdChange = (val: string) => {
    const cleanDigits = val.replace(/\D/g, '');
    setBdDigits(cleanDigits);
    setIsDirty(true);

    if (cleanDigits.length >= 2) {
      const normalized = `BD/${cleanDigits}`;
      const found = state.customers.find(
        (c) => c.category === 'Officer' && normalizeBdNumber(c.bdNumber) === normalized
      );
      if (found) {
        setCustomerName(found.name);
        if (found.phone) setPhone(found.phone);
        setSavedNameNotice(`Filled from the saved customer: ${found.name}`);

        const prevM = getLatestMeasurementsForCustomer(normalized, 'Officer', state.officerOrders, state.airmanOrders);
        if (prevM && prevM.found) {
          if (prevM.shirt) setShirt(prevM.shirt);
          if (prevM.pant) setPant(prevM.pant);
        }
      } else {
        setSavedNameNotice('');
      }
    } else {
      setSavedNameNotice('');
    }
  };

  // Calculations
  const calculatedTotal = useMemo(() => {
    return items.reduce((sum, it) => sum + (Number(it.lineTotal) || 0), 0);
  }, [items]);

  const discountResult = useMemo(() => {
    return calculateDiscount(calculatedTotal, discountValue, 'percentage');
  }, [calculatedTotal, discountValue]);

  const discountAmount = discountResult.amount;

  const calculatedDue = useMemo(() => {
    const afterDiscount = Math.max(0, calculatedTotal - discountAmount);
    return Math.max(0, afterDiscount - (Number(advance) || 0) - receivedLater);
  }, [calculatedTotal, discountAmount, advance, receivedLater]);

  const paidAmount = calculatedTotal - calculatedDue;
  const paidPct = calculatedTotal > 0 ? Math.min(100, Math.round((paidAmount / calculatedTotal) * 100)) : 0;

  // Add Item to list
  const handleAddItem = (itemName?: string) => {
    const targetName = itemName || selectedItemName || state.settings.items[0]?.name || 'Battle Uniform';
    const foundSetting = state.settings.items.find((i) => i.name === targetName);
    const unitPrice = foundSetting?.price || 800;
    const qty = Math.max(1, newItemQty);

    const newItem: OfficerOrderItem = {
      id: `item-${Date.now()}-${Math.random()}`,
      name: targetName,
      quantity: qty,
      price: unitPrice,
      lineTotal: unitPrice * qty,
      rowType: newItemRowType,
    };

    setItems((prev) => [...prev, newItem]);
    setIsDirty(true);
    setSelectedItemName('');
    setNewItemQty(1);
    setItemDropdownOpen(false);
  };

  const handleUpdateItemQty = (id: string, delta: number) => {
    setItems((prev) =>
      prev.map((it) => {
        if (it.id === id) {
          const newQty = Math.max(1, it.quantity + delta);
          return {
            ...it,
            quantity: newQty,
            lineTotal: it.price * newQty,
          };
        }
        return it;
      })
    );
    setIsDirty(true);
  };

  const handleRemoveItem = (id: string) => {
    if (items.length <= 1) return;
    setItems((prev) => prev.filter((it) => it.id !== id));
    setIsDirty(true);
  };

  // Submit
  const handleSave = () => {
    if (!bdDigits.trim()) {
      setFormError('Please enter a BD Number');
      return;
    }
    if (!customerName.trim()) {
      setFormError('Please enter Customer Name');
      return;
    }
    if (items.length === 0) {
      setFormError('Please add at least one item');
      return;
    }

    const orderNum = isEdit && existingOrder ? existingOrder.orderNumber : calculatedNextOrderNumber;
    const normalizedBd = `BD/${bdDigits.trim()}`;

    const newOrder: OfficerOrder = {
      id: existingOrder ? existingOrder.id : `officer-${Date.now()}`,
      orderNumber: orderNum,
      category: 'Officer',
      customerBdNumber: normalizedBd,
      customerName: customerName.trim(),
      customerPhone: phone.trim(),
      orderDate,
      deliveryDate: deliveryDate || formatDate(),
      ribbon,
      status: existingOrder ? existingOrder.status : 'Pending',
      items,
      shirtMeasurements: shirt,
      pantMeasurements: pant,
      totalAmount: calculatedTotal,
      discountValue: discountValue || '',
      discountType: discountValue.includes('%') ? 'percentage' : 'taka',
      discountAmount,
      advance: Number(advance) || 0,
      payments: existingOrder ? existingOrder.payments : [],
      due: calculatedDue,
      createdAt: existingOrder?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    saveOfficerOrder(newOrder);

    if (draftId) {
      deleteDraft(draftId);
    }
    localStorage.removeItem(LOCAL_DRAFT_KEY);

    onNavigate('orders');
  };

  return (
    <div className="w-full max-w-[1280px] mx-auto pb-24 font-sans">
      {/* =========================================================================
          DESKTOP FORM (Exact Loop 1 & 2 layout)
         ========================================================================= */}
      <div className="hidden md:block">
        {/* Header */}
        <div className="flex justify-between items-end py-5">
          <div>
            <h1 className="text-[40px] font-semibold tracking-[-0.03em] text-[#1d1d1f] leading-[1.1]">
              {isEdit ? `Edit order #${orderNumber}` : 'New order'}
            </h1>
            <div className="text-[#6e6e73] text-[16px] mt-1.5">
              Officer order #{calculatedNextOrderNumber}. Items, measurements and payment in one place.
            </div>
          </div>
          <button
            onClick={() => onNavigate('orders')}
            className="darzi-btn darzi-btn-gh"
          >
            Cancel
          </button>
        </div>

        {formError && (
          <div className="mb-4 p-3 bg-[#fce9e9] border border-[#e5484d] text-[#c62828] text-xs font-semibold rounded-[12px]">
            {formError}
          </div>
        )}

        {/* 2-Column Grid Split: Left Content, Right Dark Summary Card */}
        <div className="grid grid-cols-[1fr_360px] gap-5 items-start">
          <div className="grid gap-5">
            {/* 1. Items Panel (with row type & quantity features requested by user) */}
            <div className="darzi-pn">
              <b className="font-semibold text-[21px] text-[#1d1d1f]">Items</b>

              {/* Add item control bar */}
              <div className="flex gap-2.5 items-end my-3">
                <div className="flex-1 relative">
                  <div className="text-[11px] text-[#6e6e73] mb-1">Item</div>
                  <button
                    type="button"
                    onClick={() => setItemDropdownOpen(!itemDropdownOpen)}
                    className="darzi-in fl text-[#6e6e73] justify-between cursor-pointer"
                  >
                    <span className="text-[#1d1d1f] font-medium truncate">
                      {selectedItemName || 'Select an item...'}
                    </span>
                    <span className="text-xs text-[#6e6e73]">
                      {state.settings.items.length} items
                    </span>
                  </button>

                  {/* Dropdown Menu */}
                  {itemDropdownOpen && (
                    <div className="absolute top-14 left-0 right-0 z-30 bg-white rounded-[16px] p-2 shadow-[0_8px_32px_rgba(0,0,0,0.12)] border border-[#e0e0e0] max-h-60 overflow-y-auto">
                      <input
                        type="text"
                        placeholder="Search items..."
                        value={itemSearchTerm}
                        onChange={(e) => setItemSearchTerm(e.target.value)}
                        className="w-full h-8 px-3 text-xs bg-[#f5f5f7] rounded-lg mb-2 border-none outline-none text-[#1d1d1f]"
                      />
                      {state.settings.items
                        .filter((i) => i.name.toLowerCase().includes(itemSearchTerm.toLowerCase()))
                        .map((setting) => (
                          <div
                            key={setting.name}
                            onClick={() => {
                              setSelectedItemName(setting.name);
                              setItemDropdownOpen(false);
                            }}
                            className="flex justify-between items-center px-3 py-2 rounded-lg text-xs hover:bg-[#f5f5f7] cursor-pointer"
                          >
                            <span className="font-medium text-[#1d1d1f]">{setting.name}</span>
                            <span className="text-[#6e6e73]">৳{setting.price}</span>
                          </div>
                        ))}
                    </div>
                  )}
                </div>

                {/* Row Type Feature */}
                <div className="w-[120px]">
                  <div className="text-[11px] text-[#6e6e73] mb-1">Row Type</div>
                  <select
                    value={newItemRowType}
                    onChange={(e) => setNewItemRowType(e.target.value)}
                    className="darzi-in fl text-xs bg-white text-[#1d1d1f]"
                  >
                    <option value="Uniform">Uniform</option>
                    <option value="Shirt">Shirt</option>
                    <option value="Pant">Pant</option>
                    <option value="Service">Service</option>
                    <option value="Custom">Custom</option>
                  </select>
                </div>

                {/* Quantity */}
                <div className="w-[80px]">
                  <div className="text-[11px] text-[#6e6e73] mb-1">Quantity</div>
                  <input
                    type="number"
                    min="1"
                    value={newItemQty}
                    onChange={(e) => setNewItemQty(Math.max(1, Number(e.target.value)))}
                    className="darzi-in fl text-center font-medium text-[#1d1d1f]"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => handleAddItem()}
                  className="darzi-btn darzi-btn-tb h-10 px-4"
                >
                  <Plus className="w-4 h-4" />
                  Add item
                </button>
              </div>

              {/* Added Items Tray */}
              <div className="darzi-tray p-1.5 mt-3">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className="grid grid-cols-[1fr_80px_70px_90px_40px] items-center h-[52px] bg-white rounded-[12px] px-3.5 mb-1.5 last:mb-0 text-xs shadow-xs"
                  >
                    <div className="font-semibold text-[#1d1d1f] min-w-0 pr-2">
                      <div className="truncate">{item.name}</div>
                      <div className="text-[11px] text-[#6e6e73] font-normal">
                        ৳{item.price} each · {(item as any).rowType || 'Uniform'}
                      </div>
                    </div>

                    {/* Stepper buttons */}
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleUpdateItemQty(item.id, -1)}
                        className="w-5 h-5 rounded-full bg-[#f5f5f7] flex items-center justify-center font-bold text-[#6e6e73] hover:text-[#1d1d1f]"
                      >
                        −
                      </button>
                      <span className="w-5 text-center font-semibold text-[#1d1d1f]">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleUpdateItemQty(item.id, 1)}
                        className="w-5 h-5 rounded-full bg-[#f5f5f7] flex items-center justify-center font-bold text-[#6e6e73] hover:text-[#1d1d1f]"
                      >
                        +
                      </button>
                    </div>

                    <div className="text-[#6e6e73] text-center">× {item.quantity}</div>

                    <div className="font-semibold text-[#1d1d1f] text-right tabular-nums">
                      ৳{item.lineTotal.toLocaleString()}
                    </div>

                    <div className="flex justify-end">
                      <button
                        type="button"
                        onClick={() => handleRemoveItem(item.id)}
                        disabled={items.length <= 1}
                        className="w-7 h-7 rounded-full bg-[#f5f5f7] hover:bg-[#fce9e9] text-[#6e6e73] hover:text-[#c62828] flex items-center justify-center transition-colors disabled:opacity-40"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 2. Customer and Dates Panel */}
            <div className="darzi-pn">
              <b className="font-semibold text-[21px] text-[#1d1d1f]">Customer and dates</b>
              <div className="grid grid-cols-3 gap-3 mt-3">
                <div>
                  <div className="text-[11px] text-[#6e6e73] mb-1">BD Number</div>
                  <input
                    type="text"
                    placeholder="e.g. 12408"
                    value={bdDigits}
                    onChange={(e) => handleBdChange(e.target.value)}
                    className="darzi-in fl text-[#1d1d1f] font-medium"
                  />
                </div>
                <div>
                  <div className="text-[11px] text-[#6e6e73] mb-1">Customer Name</div>
                  <input
                    type="text"
                    placeholder="e.g. F/L Tanvir Ahmed"
                    value={customerName}
                    onChange={(e) => {
                      setCustomerName(e.target.value);
                      setIsDirty(true);
                    }}
                    className="darzi-in fl text-[#1d1d1f] font-medium"
                  />
                </div>
                <div>
                  <div className="text-[11px] text-[#6e6e73] mb-1">Phone</div>
                  <input
                    type="text"
                    placeholder="01712-xxxxxx"
                    value={phone}
                    onChange={(e) => {
                      setPhone(e.target.value);
                      setIsDirty(true);
                    }}
                    className="darzi-in fl text-[#1d1d1f]"
                  />
                </div>
                <div>
                  <div className="text-[11px] text-[#6e6e73] mb-1">Order Date</div>
                  <input
                    type="date"
                    value={orderDate}
                    onChange={(e) => {
                      setOrderDate(e.target.value);
                      setIsDirty(true);
                    }}
                    className="darzi-in fl text-[#1d1d1f]"
                  />
                </div>
                <div>
                  <div className="text-[11px] text-[#6e6e73] mb-1">Delivery Date</div>
                  <input
                    type="date"
                    value={deliveryDate}
                    onChange={(e) => {
                      setDeliveryDate(e.target.value);
                      setIsDirty(true);
                    }}
                    className="darzi-in fl text-[#1d1d1f]"
                  />
                </div>
                <div>
                  <div className="text-[11px] text-[#6e6e73] mb-1">Ribbon</div>
                  <select
                    value={ribbon}
                    onChange={(e) => {
                      setRibbon(e.target.value);
                      setIsDirty(true);
                    }}
                    className="darzi-in fl text-[#1d1d1f] bg-white"
                  >
                    {state.settings.ribbonValues.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              {savedNameNotice && (
                <div className="text-[11px] text-[#1e7b43] mt-2 flex items-center gap-1 font-medium">
                  <Check className="w-3.5 h-3.5" />
                  {savedNameNotice}
                </div>
              )}
            </div>

            {/* 3. Measurements Panel */}
            <div className="darzi-pn">
              <b className="font-semibold text-[21px] text-[#1d1d1f]">Measurements</b>
              <div className="grid grid-cols-2 gap-3 mt-3">
                {/* Shirt Tray */}
                <div className="darzi-tray p-4">
                  <div className="font-semibold text-[#1d1d1f] text-sm mb-2.5">Shirt</div>
                  <div className="grid grid-cols-3 gap-2.5">
                    {Object.entries(shirt).slice(0, 6).map(([key, val]) => (
                      <div key={key}>
                        <div className="text-[11px] text-[#6e6e73] mb-1 capitalize">{key}</div>
                        <input
                          type="text"
                          value={val || ''}
                          onChange={(e) => {
                            setShirt((prev) => ({ ...prev, [key]: e.target.value }));
                            setIsDirty(true);
                          }}
                          className="darzi-in fl text-center font-medium"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Pant Tray */}
                <div className="darzi-tray p-4">
                  <div className="font-semibold text-[#1d1d1f] text-sm mb-2.5">Pant</div>
                  <div className="grid grid-cols-3 gap-2.5">
                    {Object.entries(pant).slice(0, 6).map(([key, val]) => (
                      <div key={key}>
                        <div className="text-[11px] text-[#6e6e73] mb-1 capitalize">{key}</div>
                        <input
                          type="text"
                          value={val || ''}
                          onChange={(e) => {
                            setPant((prev) => ({ ...prev, [key]: e.target.value }));
                            setIsDirty(true);
                          }}
                          className="darzi-in fl text-center font-medium"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Dark Summary Card with Specular Sheen */}
          <div className="darzi-dark p-6 sticky top-20 rounded-[28px]">
            <div className="flex justify-between items-baseline">
              <span className="text-[#ccc] text-sm">Total amount</span>
              <b className="text-[24px] font-semibold text-white tabular-nums">
                ৳{calculatedTotal.toLocaleString()}
              </b>
            </div>
            <div className="text-[#ccc] text-[11px] my-1 mb-4">
              Automatic. Price × quantity, added up.
            </div>

            {/* Discount */}
            <div className="text-[#ccc] text-xs font-semibold mb-1">Discount</div>
            <input
              type="text"
              placeholder="10% or a taka amount"
              value={discountValue}
              onChange={(e) => {
                setDiscountValue(e.target.value);
                setIsDirty(true);
              }}
              className="w-full h-11 px-3.5 rounded-[12px] bg-white/8 border border-white/12 text-white placeholder:text-[#999] text-xs outline-none focus:border-white/30 mb-3"
            />

            {/* Advance */}
            <div className="text-[#ccc] text-xs font-semibold mb-1">Advance</div>
            <input
              type="number"
              placeholder="0"
              value={advance || ''}
              onChange={(e) => {
                setAdvance(Number(e.target.value));
                setIsDirty(true);
              }}
              className="w-full h-11 px-3.5 rounded-[12px] bg-white/8 border border-white/12 text-white placeholder:text-[#999] text-xs outline-none focus:border-white/30 mb-2"
            />

            {/* Received later if editing */}
            {receivedLater > 0 && (
              <div className="bg-white/8 rounded-[12px] p-2.5 px-3 flex justify-between items-center text-xs text-[#ccc] my-2">
                <span>Received later</span>
                <b className="text-white">৳{receivedLater.toLocaleString()}</b>
              </div>
            )}

            {/* Due Big Display */}
            <div className="flex justify-between items-baseline mt-5 mb-1.5 text-[#ccc]">
              <span className="text-sm font-semibold">Due</span>
              <span className="text-[11px]">Total − discount − advance</span>
            </div>
            <div className="text-[64px] font-semibold tracking-[-0.04em] text-[#ff6b6b] leading-none my-2 tabular-nums">
              ৳{calculatedDue.toLocaleString()}
            </div>

            {/* Progress Bar */}
            <div className="darzi-bar my-3.5 bg-white/15">
              <i style={{ width: `${paidPct}%`, background: '#ffffff' }} />
            </div>
            <div className="text-[#ccc] text-[11px] mb-4 tabular-nums">
              {paidPct}% paid
            </div>

            {/* Save Button */}
            <button
              type="button"
              onClick={handleSave}
              className="darzi-btn w-full"
            >
              {isEdit ? 'Update order' : 'Save order'}
            </button>
            <div className="text-[#ccc] text-[11px] text-center mt-2.5">
              Needs a customer name, BD number and one item.
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          MOBILE FORM (Exact Loop 1 PDF page 7 / HTML lines 5-9)
         ========================================================================= */}
      <div className="md:hidden">
        {/* Mobile Header Bar */}
        <div className="h-14 flex items-center justify-center relative border-b border-[#e8e8ed] bg-[#f5f5f7]">
          <button
            onClick={() => onNavigate('orders')}
            className="absolute left-4 text-[#0066cc] text-[17px] font-medium"
          >
            Cancel
          </button>
          <b className="font-semibold text-[17px] text-[#1d1d1f]">
            {isEdit ? `Edit order #${orderNumber}` : 'New order'}
          </b>
        </div>

        <div className="p-4 text-center">
          {/* Customer chip */}
          <div className="darzi-chip inline-flex h-12 font-semibold text-sm max-w-full truncate">
            <span className="darzi-ico w-8 h-8 rounded-[9px] mr-1 text-[11px]">#</span>
            <span className="truncate">
              {customerName ? `${customerName} · BD/${bdDigits}` : 'Enter customer details below'}
            </span>
          </div>

          {/* Large Total */}
          <div className="text-[76px] font-semibold tracking-[-0.04em] text-[#1d1d1f] my-3 leading-none tabular-nums">
            <span className="text-[#6e6e73] text-[36px] align-top mr-1 font-normal">৳</span>
            {calculatedTotal.toLocaleString()}
          </div>
          <div className="text-[#6e6e73] text-[15px]">Total · Price × quantity, added up</div>

          {/* Tags */}
          <div className="flex justify-center gap-2 my-3 mb-4">
            <span className="darzi-tag bg-[#fce9e9] text-[#c62828]">
              Due ৳{calculatedDue.toLocaleString()}
            </span>
            {isDirty && (
              <span className="darzi-tag bg-[rgba(240,86,31,0.1)] text-[#c2410c]">
                Unsaved changes
              </span>
            )}
          </div>

          {/* Section Segment Tabs: Items | Customer | Measure | Money */}
          <div className="darzi-seg justify-between p-1.5 mb-3 bg-white">
            <button
              onClick={() => setMobileTab('Items')}
              className={mobileTab === 'Items' ? 'on' : ''}
            >
              Items
            </button>
            <button
              onClick={() => setMobileTab('Customer')}
              className={mobileTab === 'Customer' ? 'on' : ''}
            >
              Customer
            </button>
            <button
              onClick={() => setMobileTab('Measure')}
              className={mobileTab === 'Measure' ? 'on' : ''}
            >
              Measure
            </button>
            <button
              onClick={() => setMobileTab('Money')}
              className={mobileTab === 'Money' ? 'on' : ''}
            >
              Money
            </button>
          </div>

          {/* Selected Tab Content */}
          {mobileTab === 'Items' && (
            <div className="darzi-pn rounded-[32px] p-3 px-5 text-left">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="flex justify-between items-center py-3.5 border-b border-[#f0f0f0] last:border-0"
                >
                  <div>
                    <div className="font-semibold text-[17px] text-[#1d1d1f]">{item.name}</div>
                    <div className="text-xs text-[#6e6e73]">৳{item.price} each · {(item as any).rowType || 'Uniform'}</div>
                  </div>
                  <div className="darzi-seg bg-[#f5f5f7] p-1">
                    <button
                      onClick={() => handleUpdateItemQty(item.id, -1)}
                      className="px-2 py-0 text-base"
                    >
                      −
                    </button>
                    <span className="px-1 text-sm font-semibold">{item.quantity}</span>
                    <button
                      onClick={() => handleUpdateItemQty(item.id, 1)}
                      className="px-2 py-0 text-base"
                    >
                      +
                    </button>
                  </div>
                  <b className="font-semibold text-[17px] text-[#1d1d1f] tabular-nums">
                    ৳{item.lineTotal}
                  </b>
                </div>
              ))}

              {/* Add item control on mobile */}
              <div className="flex gap-2 pt-3">
                <select
                  value={selectedItemName}
                  onChange={(e) => setSelectedItemName(e.target.value)}
                  className="darzi-in rounded-full flex-1 text-xs"
                >
                  <option value="">Select item to add...</option>
                  {state.settings.items.map((it) => (
                    <option key={it.name} value={it.name}>
                      {it.name} (৳{it.price})
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => handleAddItem()}
                  className="darzi-btn darzi-btn-tb h-11"
                >
                  Add item
                </button>
              </div>
            </div>
          )}

          {mobileTab === 'Customer' && (
            <div className="darzi-pn rounded-[32px] p-4 text-left space-y-3">
              <div>
                <label className="text-xs text-[#6e6e73]">BD Number</label>
                <input
                  type="text"
                  placeholder="e.g. 12408"
                  value={bdDigits}
                  onChange={(e) => handleBdChange(e.target.value)}
                  className="darzi-in mt-1 font-semibold"
                />
              </div>
              <div>
                <label className="text-xs text-[#6e6e73]">Customer Name</label>
                <input
                  type="text"
                  placeholder="Customer Name"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="darzi-in mt-1 font-semibold"
                />
              </div>
              <div>
                <label className="text-xs text-[#6e6e73]">Phone</label>
                <input
                  type="text"
                  placeholder="Phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="darzi-in mt-1"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs text-[#6e6e73]">Order Date</label>
                  <input
                    type="date"
                    value={orderDate}
                    onChange={(e) => setOrderDate(e.target.value)}
                    className="darzi-in mt-1 text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#6e6e73]">Delivery Date</label>
                  <input
                    type="date"
                    value={deliveryDate}
                    onChange={(e) => setDeliveryDate(e.target.value)}
                    className="darzi-in mt-1 text-xs"
                  />
                </div>
              </div>
              {savedNameNotice && (
                <div className="text-xs text-[#1e7b43] font-medium">{savedNameNotice}</div>
              )}
            </div>
          )}

          {mobileTab === 'Measure' && (
            <div className="darzi-pn rounded-[32px] p-4 text-left space-y-4">
              <div>
                <b className="text-sm text-[#1d1d1f] block mb-2">Shirt Measurements</b>
                <div className="grid grid-cols-3 gap-2">
                  {Object.entries(shirt).slice(0, 6).map(([k, v]) => (
                    <div key={k}>
                      <span className="text-[11px] text-[#6e6e73] capitalize">{k}</span>
                      <input
                        type="text"
                        value={v || ''}
                        onChange={(e) => setShirt((prev) => ({ ...prev, [k]: e.target.value }))}
                        className="darzi-in fl text-center font-medium mt-0.5"
                      />
                    </div>
                  ))}
                </div>
              </div>
              <div className="pt-3 border-t border-[#f0f0f0]">
                <b className="text-sm text-[#1d1d1f] block mb-2">Pant Measurements</b>
                <div className="grid grid-cols-3 gap-2">
                  {Object.entries(pant).slice(0, 6).map(([k, v]) => (
                    <div key={k}>
                      <span className="text-[11px] text-[#6e6e73] capitalize">{k}</span>
                      <input
                        type="text"
                        value={v || ''}
                        onChange={(e) => setPant((prev) => ({ ...prev, [k]: e.target.value }))}
                        className="darzi-in fl text-center font-medium mt-0.5"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {mobileTab === 'Money' && (
            <div className="flex gap-3 text-left">
              <div className="darzi-pn flex-1 rounded-[28px] p-4">
                <b className="text-sm text-[#1d1d1f]">Discount</b>
                <input
                  type="text"
                  placeholder="10% or ৳"
                  value={discountValue}
                  onChange={(e) => setDiscountValue(e.target.value)}
                  className="darzi-in mt-2 text-xs"
                />
              </div>
              <div className="darzi-pn flex-1 rounded-[28px] p-4">
                <b className="text-sm text-[#1d1d1f]">Advance</b>
                <input
                  type="number"
                  placeholder="0"
                  value={advance || ''}
                  onChange={(e) => setAdvance(Number(e.target.value))}
                  className="darzi-in mt-2 text-xs"
                />
                {receivedLater > 0 && (
                  <div className="darzi-tray p-2 mt-2 flex justify-between text-xs">
                    <span className="text-[#6e6e73]">Later</span>
                    <b>৳{receivedLater}</b>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Sticky Glass Bottom Bar */}
          <div className="fixed left-3 right-3 bottom-4 z-40 darzi-glass rounded-full p-2 h-[76px] flex items-center shadow-[0_8px_32px_rgba(0,0,0,0.15)]">
            <button
              onClick={handleSave}
              className="darzi-btn w-full h-[58px] text-[18px]"
            >
              {isEdit ? 'Update order' : 'Save order'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
